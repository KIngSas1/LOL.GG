package dev.stargg.util;

import dev.stargg.StarGG;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/** Loads the user's original Ww.json into the embedded Echo profile manager once it is ready. */
public final class EchoProfileBootstrap {
    private static boolean loaded;
    private static int attempts;

    private EchoProfileBootstrap() {
    }

    public static boolean isLoaded() {
        return loaded;
    }

    public static void tick() {
        if (loaded) {
            return;
        }
        if (++attempts > 1200) {
            loaded = true;
            StarGG.LOGGER.error("Could not load Ww.json: embedded Echo profile manager did not become ready");
            return;
        }

        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                loader = EchoProfileBootstrap.class.getClassLoader();
            }
            Class<?> echoMain = Class.forName("hack.echo.o", false, loader);
            Field configField = echoMain.getField("featureConfig");
            Object configManager = configField.get(null);
            if (configManager == null) {
                return;
            }

            // Echo first loads its own default profile during resource reload. Do not race that load.
            Field loadingField = configManager.getClass().getField("loading");
            if (loadingField.getBoolean(configManager)) {
                return;
            }

            Field directoryField = configManager.getClass().getDeclaredField("profileDir");
            directoryField.setAccessible(true);
            Object directoryValue = directoryField.get(configManager);
            if (!(directoryValue instanceof File profileDirectory)) {
                throw new IllegalStateException("Echo profile directory has an unexpected type");
            }

            Files.createDirectories(profileDirectory.toPath());
            Path profileFile = profileDirectory.toPath().resolve("Ww.json");
            if (!Files.exists(profileFile)) {
                try (InputStream input = EchoProfileBootstrap.class.getResourceAsStream("/echo/Ww.json")) {
                    if (input == null) {
                        throw new IllegalStateException("Bundled echo/Ww.json resource is missing");
                    }
                    Files.copy(input, profileFile, StandardCopyOption.REPLACE_EXISTING);
                }
            }

            Method loadProfile = configManager.getClass().getMethod("loadProfile", String.class);
            Object result = loadProfile.invoke(configManager, "Ww");
            if (Boolean.TRUE.equals(result)) {
                // In Echo, Click GUI.enabled means the screen is open. The saved value in this
                // profile is true because the profile was saved while its GUI was open; close it
                // after restoring the profile so STAR.GG starts in-game normally. Its keybind
                // and every Click GUI setting remain loaded.
                EchoModuleBridge.closeOriginalClickGui();
                loaded = true;
                StarGG.LOGGER.info("Loaded the supplied Ww.json profile for the embedded Echo modules");
            } else {
                loaded = true;
                StarGG.LOGGER.error("Echo rejected Ww.json profile at {}", profileFile);
            }
        } catch (ClassNotFoundException ignored) {
            // Nested mods are initialized by Fabric before client ticks; retry briefly if needed.
        } catch (ReflectiveOperationException | java.io.IOException | RuntimeException exception) {
            loaded = true;
            StarGG.LOGGER.error("Failed to install or load the supplied Ww.json profile", exception);
        }
    }
}
