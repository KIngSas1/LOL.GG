package dev.stargg.util;

import dev.stargg.StarGG;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Text, icon and rounded-shape helpers for the click GUI only (the HUD keeps using {@link Draw}).
 *
 * <p>Everything here is resolution aware: fonts ({@code font/ui_<scale>.json}), icons and rounded corners
 * ({@code textures/gui/ui/*_<pixels>.png}) exist once per GUI scale, so each texel lands on exactly one screen
 * pixel. That is what keeps them crisp instead of pixelated. Scales above {@link #MAX_SCALE} use the largest set.
 */
public final class Ui {

    public static final int TEXT_HEIGHT = 9;
    /** Cap height of the client font in GUI units; the baseline always sits 7 units below the text origin. */
    public static final int CAP_HEIGHT = 7;
    /** Cap height (rounded) of the larger title font, used for the logo wordmark. The baseline is still 7 below the origin. */
    public static final int TITLE_CAP_HEIGHT = 9;
    public static final int MAX_SCALE = 6;

    // If a Minecraft update changes Style#withFont, fix it here (older versions took an Identifier directly).
    private static final Style[] REGULAR = new Style[MAX_SCALE + 1];
    private static final Style[] BOLD = new Style[MAX_SCALE + 1];
    private static final Style[] TITLE = new Style[MAX_SCALE + 1];
    private static final Identifier[][] CORNERS = new Identifier[6][MAX_SCALE + 1];

    static {
        for (int s = 1; s <= MAX_SCALE; s++) {
            REGULAR[s] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(StarGG.MOD_ID, "ui_" + s)));
            BOLD[s] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(StarGG.MOD_ID, "ui_bold_" + s)));
            TITLE[s] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(StarGG.MOD_ID, "ui_title_" + s)));
            for (int r = 1; r <= 5; r++) {
                CORNERS[r][s] = Identifier.of(StarGG.MOD_ID, "textures/gui/ui/corner_" + r + "_" + s + ".png");
            }
        }
    }

    /** Icons, each with its fixed size in GUI units. */
    public enum Tex {
        LOGO("logo", 12),
        SEARCH("search", 10),
        DOTS("dots", 12),
        GEAR("gear", 10),
        CHEVRON_RIGHT("chevron_right", 6),
        CHEVRON_UP("chevron_up", 8),
        CHEVRON_DOWN("chevron_down", 8),
        CAT_HUD("cat_hud", 10),
        CAT_COMBAT("cat_combat", 10),
        CAT_MOVEMENT("cat_movement", 10),
        CAT_VISUAL("cat_visual", 10),
        CAT_UTILITY("cat_utility", 10),
        CAT_CLIENT("cat_client", 10);

        public final int size;
        private final Identifier[] byScale = new Identifier[MAX_SCALE + 1];

        Tex(String file, int size) {
            this.size = size;
            for (int s = 1; s <= MAX_SCALE; s++) {
                byScale[s] = Identifier.of(StarGG.MOD_ID, "textures/gui/ui/" + file + "_" + (size * s) + ".png");
            }
        }
    }

    private Ui() {
    }

    private static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    /** The current GUI scale factor, clamped to the range the textures/fonts were generated for. */
    public static int scale() {
        int s = (int) Math.round(mc().getWindow().getScaleFactor());
        return Math.max(1, Math.min(MAX_SCALE, s));
    }

    private static Text styled(String text, boolean bold) {
        int s = scale();
        return Text.literal(text).setStyle(bold ? BOLD[s] : REGULAR[s]);
    }

    private static Text titled(String text) {
        return Text.literal(text).setStyle(TITLE[scale()]);
    }

    // ------------------------------------------------------------------ text

    public static int width(String text) {
        return mc().textRenderer.getWidth(styled(text, false));
    }

    public static int widthBold(String text) {
        return mc().textRenderer.getWidth(styled(text, true));
    }

    /** Regular-weight text in the client font for the current GUI scale (also used by the HUD). */
    public static Text regular(String text) {
        return styled(text, false);
    }

    public static void text(DrawContext ctx, String text, int x, int y, int color) {
        ctx.drawText(mc().textRenderer, styled(text, false), x, y, color, false);
    }

    public static void textBold(DrawContext ctx, String text, int x, int y, int color) {
        ctx.drawText(mc().textRenderer, styled(text, true), x, y, color, false);
    }

    public static void textBold(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
        ctx.drawText(mc().textRenderer, styled(text, true), x, y, color, shadow);
    }

    // ------------------------------------------------------- title (large bold) text

    public static int widthTitle(String text) {
        return mc().textRenderer.getWidth(titled(text));
    }

    public static void textTitle(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
        ctx.drawText(mc().textRenderer, titled(text), x, y, color, shadow);
    }

    /** Y of the title-font text origin that centers its capital letters in a row. */
    public static int middleYTitle(int rowY, int rowH) {
        return rowY + (rowH - TITLE_CAP_HEIGHT) / 2 + (TITLE_CAP_HEIGHT - CAP_HEIGHT);
    }

    /** Y of the text origin that puts the capital letters exactly on the middle line of a row. */
    public static int middleY(int rowY, int rowH) {
        return rowY + (rowH - CAP_HEIGHT) / 2;
    }

    /** Draws text vertically centered inside a row that starts at rowY and is rowH tall. */
    public static void textMiddle(DrawContext ctx, String text, int x, int rowY, int rowH, int color) {
        text(ctx, text, x, middleY(rowY, rowH), color);
    }

    /** Draws text so that it ends at rightX. */
    public static void textRight(DrawContext ctx, String text, int rightX, int rowY, int rowH, int color) {
        textMiddle(ctx, text, rightX - width(text), rowY, rowH, color);
    }

    public static void textCentered(DrawContext ctx, String text, int x, int rowY, int w, int rowH, int color) {
        textMiddle(ctx, text, x + (w - width(text)) / 2, rowY, rowH, color);
    }

    public static String trim(String text, int maxWidth) {
        if (width(text) <= maxWidth) {
            return text;
        }
        String cut = text;
        while (!cut.isEmpty() && width(cut + "..") > maxWidth) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut + "..";
    }

    // ----------------------------------------------------------------- shapes

    /** Draws an icon at its natural size, tinted with the given ARGB color. */
    public static void icon(DrawContext ctx, Tex tex, int x, int y, int color) {
        int px = tex.size * scale();
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex.byScale[scale()], x, y, 0f, 0f, tex.size, tex.size, px, px, px, px, color);
    }

    /**
     * Anti-aliased rounded rectangle (radius 1 to 5 GUI units). A radius of half the size gives a pill or
     * a circle. The straight parts are plain fills; only the four corners are textures.
     */
    public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.min(Math.min(r, 5), Math.min(w, h) / 2);
        if (r <= 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        int s = scale();
        int c = r * s;
        Identifier corner = CORNERS[r][s];
        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x, y, 0f, 0f, r, r, c, c, 2 * c, 2 * c, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x + w - r, y, (float) c, 0f, r, r, c, c, 2 * c, 2 * c, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x, y + h - r, 0f, (float) c, r, r, c, c, 2 * c, 2 * c, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x + w - r, y + h - r, (float) c, (float) c, r, r, c, c, 2 * c, 2 * c, color);
    }
}
