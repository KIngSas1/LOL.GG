package dev.stargg.util;

import net.minecraft.entity.player.PlayerEntity;

/**
 * Tracks how far the local player has fallen since the highest point of the current airtime.
 * Updated once per client tick by the module manager so combat modules can share it.
 */
public final class FallTracker {

    private static boolean airborne;
    private static double peakY;
    private static double fallen;

    private FallTracker() {
    }

    public static void update(PlayerEntity player) {
        if (player == null) {
            airborne = false;
            fallen = 0.0;
            return;
        }
        if (player.isOnGround() || player.isTouchingWater() || player.isClimbing()
                || player.hasVehicle() || player.getAbilities().flying) {
            airborne = false;
            fallen = 0.0;
            peakY = player.getY();
            return;
        }
        if (!airborne) {
            airborne = true;
            peakY = player.getY();
        } else if (player.getY() > peakY) {
            peakY = player.getY();
        }
        fallen = Math.max(0.0, peakY - player.getY());
    }

    /** Blocks fallen since the peak of the current jump / launch (0 while grounded). */
    public static double distance() {
        return fallen;
    }
}
