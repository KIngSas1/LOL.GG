package dev.stargg.module.visual;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.util.Icon;

/** Removes the camera shake when you take damage (see {@code GameRendererMixin}). */
public final class NoHurtCam extends Module {

    private static NoHurtCam instance;

    public NoHurtCam() {
        super("No Hurt Cam", "Disables the camera tilt when you get hurt", Category.VISUAL);
        icon(Icon.HURT_CAM);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }
}
