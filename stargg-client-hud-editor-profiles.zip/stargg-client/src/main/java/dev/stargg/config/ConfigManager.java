package dev.stargg.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.stargg.StarGG;
import dev.stargg.module.Module;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Saves module state to {@code .minecraft/config/stargg/config.json} and keeps
 * named profile snapshots in {@code .../profiles/<name>.json}.
 */
public final class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final long AUTOSAVE_INTERVAL_MS = 3000;

    /** Built-in profile: loading it resets everything to the defaults; it cannot be overwritten. */
    public static final String DEFAULT_PROFILE = "default";

    private static volatile boolean dirty;

    /** Click GUI panel positions: category title -> {x, y}. */
    private final Map<String, int[]> panelPositions = new HashMap<>();

    private final Path directory = FabricLoader.getInstance().getConfigDir().resolve("stargg");
    private final Path mainFile = directory.resolve("config.json");
    private final Path profileDirectory = directory.resolve("profiles");
    private long lastSave;

    private String activeProfile = DEFAULT_PROFILE;
    private boolean autoSaveProfile;

    /** Summary of a saved profile for the profiles screen. */
    public record ProfileInfo(String name, long modifiedMillis, int enabledModules) {
    }

    /** Anything that changes a saved value calls this; the file is written shortly after. */
    public static void markDirty() {
        dirty = true;
    }

    public void tick() {
        if (dirty && System.currentTimeMillis() - lastSave > AUTOSAVE_INTERVAL_MS) {
            save();
        }
    }

    // ------------------------------------------------------------ main config

    /** Keeps settings made before the rename: moves config/<old id>/ to config/stargg/ once. */
    private void migrateOldConfig() {
        Path old = FabricLoader.getInstance().getConfigDir().resolve("legit" + "client");
        if (Files.isDirectory(old) && !Files.exists(directory)) {
            try {
                Files.move(old, directory);
            } catch (IOException e) {
                StarGG.LOGGER.warn("Could not move the old config folder {}", old, e);
            }
        }
    }

    public void load() {
        migrateOldConfig();
        if (!Files.exists(mainFile)) {
            return;
        }
        try {
            JsonObject root = readJson(mainFile);
            apply(root, true);
            if (root.has("profile") && root.get("profile").isJsonPrimitive()) {
                activeProfile = root.get("profile").getAsString();
            }
            if (root.has("autoSaveProfile") && root.get("autoSaveProfile").isJsonPrimitive()) {
                autoSaveProfile = root.get("autoSaveProfile").getAsBoolean();
            }
            if (!listProfiles().contains(activeProfile)) {
                activeProfile = DEFAULT_PROFILE;
            }
        } catch (Exception e) {
            StarGG.LOGGER.error("Could not read {}", mainFile, e);
        }
    }

    public void save() {
        dirty = false;
        lastSave = System.currentTimeMillis();
        try {
            JsonObject root = snapshot();
            root.addProperty("profile", activeProfile);
            root.addProperty("autoSaveProfile", autoSaveProfile);
            writeJson(mainFile, root);
            if (autoSaveProfile && !DEFAULT_PROFILE.equalsIgnoreCase(activeProfile) && profileExists(activeProfile)) {
                writeJson(profileFile(activeProfile), snapshot());
            }
        } catch (IOException e) {
            StarGG.LOGGER.error("Could not write {}", mainFile, e);
        }
    }

    // --------------------------------------------------------------- profiles

    public static final int MAX_NAME_LENGTH = 24;

    public String getActiveProfile() {
        return activeProfile;
    }

    public boolean isAutoSaveProfile() {
        return autoSaveProfile;
    }

    public void setAutoSaveProfile(boolean value) {
        autoSaveProfile = value;
        markDirty();
    }

    /** A profile name is 1-24 letters, digits, spaces, '_' or '-' (it becomes the file name). */
    public static boolean isValidName(String name) {
        return name != null && !name.isBlank() && name.length() <= MAX_NAME_LENGTH && name.equals(name.trim())
                && name.matches("[a-zA-Z0-9_\\- ]+");
    }

    private Path profileFile(String name) {
        return profileDirectory.resolve(sanitize(name) + ".json");
    }

    public boolean profileExists(String name) {
        for (String existing : listProfiles()) {
            if (existing.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    /** The saved name that matches {@code name} ignoring case, or {@code name} itself. */
    private String canonical(String name) {
        for (String existing : listProfiles()) {
            if (existing.equalsIgnoreCase(name)) {
                return existing;
            }
        }
        return name;
    }

    public List<String> listProfiles() {
        List<String> names = new ArrayList<>();
        if (Files.isDirectory(profileDirectory)) {
            try (Stream<Path> files = Files.list(profileDirectory)) {
                files.map(p -> p.getFileName().toString())
                        .filter(n -> n.endsWith(".json"))
                        .map(n -> n.substring(0, n.length() - 5))
                        .sorted(String.CASE_INSENSITIVE_ORDER)
                        .forEach(names::add);
            } catch (IOException e) {
                StarGG.LOGGER.error("Could not list profiles", e);
            }
        }
        names.remove(DEFAULT_PROFILE);
        names.add(0, DEFAULT_PROFILE); // always first; it is the built-in factory reset
        return names;
    }

    public List<ProfileInfo> profileInfos() {
        List<ProfileInfo> infos = new ArrayList<>();
        for (String name : listProfiles()) {
            if (DEFAULT_PROFILE.equals(name)) {
                infos.add(new ProfileInfo(name, 0L, 0));
                continue;
            }
            long modified = 0L;
            int enabled = 0;
            try {
                Path file = profileFile(name);
                modified = Files.getLastModifiedTime(file).toMillis();
                JsonObject modules = readJson(file).getAsJsonObject("modules");
                if (modules != null) {
                    for (var entry : modules.entrySet()) {
                        JsonObject module = entry.getValue().isJsonObject() ? entry.getValue().getAsJsonObject() : null;
                        if (module != null && module.has("enabled") && module.get("enabled").getAsBoolean()) {
                            enabled++;
                        }
                    }
                }
            } catch (Exception ignored) {
                // an unreadable profile is still listed, just without details
            }
            infos.add(new ProfileInfo(name, modified, enabled));
        }
        return infos;
    }

    /** Saves the current settings as a profile (creating or overwriting it) and makes it the active one. */
    public boolean saveProfile(String name) {
        if (DEFAULT_PROFILE.equalsIgnoreCase(name) || !isValidName(name)) {
            return false; // the default profile is always the untouched defaults
        }
        try {
            String target = canonical(name);
            writeJson(profileFile(target), snapshot());
            activeProfile = target;
            markDirty();
            return true;
        } catch (IOException e) {
            StarGG.LOGGER.error("Could not save profile {}", name, e);
            return false;
        }
    }

    /** Resets every module (state, binds, settings, HUD positions) to the fresh-install defaults. */
    public void resetToDefaults() {
        for (Module module : StarGG.modules().all()) {
            module.resetToDefaults();
        }
        markDirty();
    }

    /** Loads a profile. Everything it does not mention goes back to its default, so the result is exactly the profile. */
    public boolean loadProfile(String name) {
        if (DEFAULT_PROFILE.equalsIgnoreCase(name)) {
            resetToDefaults();
            activeProfile = DEFAULT_PROFILE;
            return true;
        }
        if (!profileExists(name)) {
            return false;
        }
        String target = canonical(name);
        try {
            JsonObject json = readJson(profileFile(target));
            resetToDefaults();
            apply(json, false);
            activeProfile = target;
            markDirty();
            return true;
        } catch (Exception e) {
            StarGG.LOGGER.error("Could not load profile {}", name, e);
            return false;
        }
    }

    /** Saves the current settings under a new name. Fails if the name is invalid or already used. */
    public boolean createProfile(String name) {
        if (!isValidName(name) || DEFAULT_PROFILE.equalsIgnoreCase(name) || profileExists(name)) {
            return false;
        }
        return saveProfile(name);
    }

    public boolean renameProfile(String from, String to) {
        if (DEFAULT_PROFILE.equalsIgnoreCase(from) || !profileExists(from)
                || !isValidName(to) || DEFAULT_PROFILE.equalsIgnoreCase(to)) {
            return false;
        }
        String source = canonical(from);
        if (!source.equalsIgnoreCase(to) && profileExists(to)) {
            return false;
        }
        try {
            Path target = profileFile(to);
            Files.move(profileFile(source), target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            if (activeProfile.equals(source)) {
                activeProfile = to;
                markDirty();
            }
            return true;
        } catch (IOException e) {
            StarGG.LOGGER.error("Could not rename profile {}", from, e);
            return false;
        }
    }

    public boolean duplicateProfile(String from, String to) {
        if (!isValidName(to) || DEFAULT_PROFILE.equalsIgnoreCase(to) || profileExists(to) || !profileExists(from)) {
            return false;
        }
        try {
            Files.copy(profileFile(canonical(from)), profileFile(to));
            return true;
        } catch (IOException e) {
            StarGG.LOGGER.error("Could not duplicate profile {}", from, e);
            return false;
        }
    }

    /** Deletes a profile. If it was the active one the current settings stay, they just belong to "default" again. */
    public boolean deleteProfile(String name) {
        if (DEFAULT_PROFILE.equalsIgnoreCase(name) || !profileExists(name)) {
            return false;
        }
        String target = canonical(name);
        try {
            Files.deleteIfExists(profileFile(target));
            if (activeProfile.equals(target)) {
                activeProfile = DEFAULT_PROFILE;
                markDirty();
            }
            return true;
        } catch (IOException e) {
            StarGG.LOGGER.error("Could not delete profile {}", name, e);
            return false;
        }
    }

    /** The current settings as one line of JSON, for sharing (copy to clipboard). */
    public String exportCurrent() {
        JsonObject root = new JsonObject();
        root.add("modules", snapshot().get("modules"));
        return new Gson().toJson(root);
    }

    /** The saved contents of a profile as one line of JSON, or null if it does not exist. */
    public String exportProfile(String name) {
        if (DEFAULT_PROFILE.equalsIgnoreCase(name) || !profileExists(name)) {
            return null;
        }
        try {
            JsonObject root = new JsonObject();
            root.add("modules", readJson(profileFile(canonical(name))).get("modules"));
            return new Gson().toJson(root);
        } catch (Exception e) {
            return null;
        }
    }

    /** Creates a profile from shared JSON text (see {@link #exportCurrent()}). Does not load it. */
    public boolean importProfile(String name, String text) {
        if (!isValidName(name) || DEFAULT_PROFILE.equalsIgnoreCase(name) || profileExists(name) || text == null) {
            return false;
        }
        try {
            JsonElement parsed = JsonParser.parseString(text.trim());
            if (!parsed.isJsonObject() || !parsed.getAsJsonObject().has("modules")
                    || !parsed.getAsJsonObject().get("modules").isJsonObject()) {
                return false;
            }
            writeJson(profileFile(name), parsed.getAsJsonObject());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** True if the current settings differ from what the active profile has saved (always false for "default"). */
    public boolean isModified() {
        if (DEFAULT_PROFILE.equalsIgnoreCase(activeProfile) || !profileExists(activeProfile)) {
            return false;
        }
        try {
            JsonElement saved = readJson(profileFile(activeProfile)).get("modules");
            return saved == null || !saved.equals(snapshot().get("modules"));
        } catch (Exception e) {
            return false;
        }
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\- ]", "_");
    }

    // -------------------------------------------------------------- GUI state

    public int[] getPanelPosition(String title) {
        return panelPositions.get(title);
    }

    public void setPanelPosition(String title, int x, int y) {
        panelPositions.put(title, new int[]{x, y});
        markDirty();
    }

    // --------------------------------------------------------------- internals

    private JsonObject snapshot() {
        JsonObject root = new JsonObject();

        JsonObject modules = new JsonObject();
        for (Module module : StarGG.modules().all()) {
            modules.add(module.getName(), module.toJson());
        }
        root.add("modules", modules);

        JsonObject gui = new JsonObject();
        panelPositions.forEach((title, pos) -> {
            JsonObject entry = new JsonObject();
            entry.addProperty("x", pos[0]);
            entry.addProperty("y", pos[1]);
            gui.add(title, entry);
        });
        root.add("gui", gui);
        return root;
    }

    private void apply(JsonObject root, boolean includeGui) {
        if (root.has("modules") && root.get("modules").isJsonObject()) {
            JsonObject modules = root.getAsJsonObject("modules");
            for (Module module : StarGG.modules().all()) {
                JsonElement entry = modules.get(module.getName());
                if (entry != null && entry.isJsonObject()) {
                    try {
                        module.fromJson(entry.getAsJsonObject());
                    } catch (RuntimeException e) {
                        StarGG.LOGGER.warn("Ignoring bad config for module {}", module.getName(), e);
                    }
                }
            }
        }
        if (includeGui && root.has("gui") && root.get("gui").isJsonObject()) {
            root.getAsJsonObject("gui").entrySet().forEach(e -> {
                if (e.getValue().isJsonObject()) {
                    JsonObject pos = e.getValue().getAsJsonObject();
                    if (pos.has("x") && pos.has("y")) {
                        panelPositions.put(e.getKey(), new int[]{pos.get("x").getAsInt(), pos.get("y").getAsInt()});
                    }
                }
            });
        }
    }

    private static JsonObject readJson(Path file) throws IOException {
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            return JsonParser.parseReader(reader).getAsJsonObject();
        }
    }

    private static void writeJson(Path file, JsonObject json) throws IOException {
        Files.createDirectories(file.getParent());
        try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            GSON.toJson(json, writer);
        }
    }
}
