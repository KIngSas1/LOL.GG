package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.module.Module;
import dev.legitclient.setting.ActionSetting;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.setting.ColorSetting;
import dev.legitclient.setting.ModeSetting;
import dev.legitclient.setting.NumberSetting;
import dev.legitclient.setting.Setting;
import dev.legitclient.util.Draw;
import dev.legitclient.util.Ui;
import net.minecraft.client.gui.DrawContext;

/**
 * One row inside an expanded module. A widget remembers where it was drawn last
 * frame, which is what mouse clicks are tested against.
 *
 * <p>To support a new kind of setting: add a Setting subclass, a widget subclass
 * and one line in {@link #create(Setting)}.
 */
public abstract class SettingWidget {

    /** The widget currently capturing the keyboard (the bind button while listening). */
    private static SettingWidget focused;

    /** Height of the first line of a row (label + value). */
    protected static final int LINE = 18;

    protected int x;
    protected int y;
    protected int w;

    public static SettingWidget create(Setting<?> setting) {
        if (setting instanceof BooleanSetting s) {
            return new BooleanWidget(s);
        }
        if (setting instanceof NumberSetting s) {
            return new NumberWidget(s);
        }
        if (setting instanceof ModeSetting s) {
            return new ModeWidget(s);
        }
        if (setting instanceof ColorSetting s) {
            return new ColorWidget(s);
        }
        if (setting instanceof ActionSetting s) {
            return new ActionWidget(s);
        }
        throw new IllegalArgumentException("No widget for setting type " + setting.getClass().getSimpleName());
    }

    public static SettingWidget bind(Module module) {
        return new BindWidget(module);
    }

    public static SettingWidget bindMode(Module module) {
        return new BindModeWidget(module);
    }

    // ---------------------------------------------------------------- focus

    protected static void focus(SettingWidget widget) {
        releaseFocus();
        focused = widget;
    }

    public static void releaseFocus() {
        if (focused != null) {
            SettingWidget old = focused;
            focused = null;
            old.onFocusLost();
        }
    }

    public static SettingWidget getFocused() {
        return focused;
    }

    protected void onFocusLost() {
    }

    // ------------------------------------------------------------- contract

    public abstract int height();

    public boolean isVisible() {
        return true;
    }

    protected abstract void renderContent(DrawContext context, int mouseX, int mouseY);

    public final void render(DrawContext context, int x, int y, int w, int mouseX, int mouseY) {
        this.x = x;
        this.y = y;
        this.w = w;
        renderContent(context, mouseX, mouseY);
    }

    public final boolean hit(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, x, y, w, height());
    }

    public void click(double mouseX, double mouseY, int button) {
    }

    public void drag(double mouseX) {
    }

    public void release() {
    }

    /** Only called on the focused widget. @return true if the key was consumed. */
    public boolean keyPressed(int key) {
        return false;
    }

    // --------------------------------------------------------------- helpers

    protected final boolean hovered(double mouseX, double mouseY) {
        return hit(mouseX, mouseY);
    }

    protected final void paintRow(DrawContext context, boolean hovered) {
        Draw.rect(context, x, y, w, height(), Theme.bg(hovered ? Theme.SETTING_HOVER : Theme.SETTING_ROW));
    }

    protected final void label(DrawContext context, String text, int color) {
        Ui.textMiddle(context, text, x + Theme.PADDING, y, LINE, color);
    }

    protected final void rightText(DrawContext context, String text, int color) {
        int available = w - Theme.PADDING * 2 - 44;
        String shown = Ui.trim(text, Math.max(available, 30));
        Ui.textRight(context, shown, x + w - Theme.PADDING, y, LINE, color);
    }
}
