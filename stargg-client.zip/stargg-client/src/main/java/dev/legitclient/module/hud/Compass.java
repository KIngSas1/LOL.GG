package dev.legitclient.module.hud;

import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.util.Icon;
import net.minecraft.util.math.MathHelper;

import java.util.List;

public final class Compass extends TextHudModule {

    private static final String[] DIRECTIONS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    private final BooleanSetting degrees = add(new BooleanSetting("Show degrees", true));

    public Compass() {
        super("Compass", "Direction you are facing", 4, 64);
        icon(Icon.COMPASS);
    }

    @Override
    protected List<String> buildLines() {
        if (mc.player == null) {
            return List.of();
        }
        // Minecraft yaw: 0 = south, so shift by 180 to get 0 = north.
        float heading = MathHelper.wrapDegrees(mc.player.getYaw() + 180f);
        if (heading < 0) {
            heading += 360f;
        }
        String direction = DIRECTIONS[Math.round(heading / 45f) % 8];
        return List.of(degrees.on()
                ? "Facing: " + direction + " (" + Math.round(heading) + ")"
                : "Facing: " + direction);
    }
}
