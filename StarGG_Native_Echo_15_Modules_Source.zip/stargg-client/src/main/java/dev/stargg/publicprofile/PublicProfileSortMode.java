package dev.stargg.publicprofile;

/** How the public profile list is ordered. */
public enum PublicProfileSortMode {
    RATED("Top Rated"),
    DOWNLOADED("Most Downloaded"),
    NEWEST("Newest");

    private final String displayName;

    PublicProfileSortMode(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}
