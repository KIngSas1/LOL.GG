package dev.stargg.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Moves the camera toward a target once per rendered frame the way a real mouse would:
 * frame-rate independent easing, an optional ease-in when a target is acquired, and movement
 * snapped to whole "mouse counts" for the current sensitivity (leftover movement carries over).
 * Rotation goes through {@code changeLookDirection}, exactly like vanilla mouse input.
 */
public final class MouseAim {

    private long lastNanos;
    private long startNanos;
    private double remainderYaw;
    private double remainderPitch;

    /** Call when there is no target so the next acquisition eases in again. */
    public void reset() {
        lastNanos = 0L;
        startNanos = 0L;
        remainderYaw = 0.0;
        remainderPitch = 0.0;
    }

    /**
     * @param maxYaw    max yaw degrees per 20 Hz tick-equivalent
     * @param maxPitch  max pitch degrees per tick-equivalent
     * @param smoothing 1 = move straight to the target, higher = slower approach
     * @param rampMs    time to reach full speed after acquiring a target (0 = instantly)
     * @param quantize  snap movement to mouse counts for the current sensitivity
     */
    public void step(MinecraftClient mc, float targetYaw, float targetPitch,
                     float maxYaw, float maxPitch, float smoothing, float rampMs, boolean quantize) {
        PlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        long now = System.nanoTime();
        if (lastNanos == 0L || now - lastNanos > 250_000_000L) {
            lastNanos = now;
            startNanos = now;
            return;
        }
        double ticks = Math.min((now - lastNanos) / 1.0E9, 0.1) * 20.0;
        lastNanos = now;

        double yawDelta = MathHelper.wrapDegrees(targetYaw - player.getYaw());
        double pitchDelta = targetPitch - player.getPitch();

        double follow = 1.0 - Math.pow(1.0 - 1.0 / Math.max(1.0, smoothing), ticks);
        double ramp = 1.0;
        if (rampMs > 0.0F) {
            double t = MathHelper.clamp((now - startNanos) / 1.0E6 / rampMs, 0.0, 1.0);
            ramp = t * t * (3.0 - 2.0 * t);
        }
        double stepYaw = MathHelper.clamp(yawDelta * follow, -maxYaw * ticks, maxYaw * ticks) * ramp;
        double stepPitch = MathHelper.clamp(pitchDelta * follow, -maxPitch * ticks, maxPitch * ticks) * ramp;

        if (!quantize) {
            player.changeLookDirection(stepYaw / 0.15, stepPitch / 0.15);
            return;
        }

        // vanilla: cursor delta * (sens*0.6+0.2)^3 * 8, then * 0.15 degrees
        double sensitivity = mc.options.getMouseSensitivity().getValue();
        double base = sensitivity * 0.6 + 0.2;
        double gain = base * base * base * 8.0;
        double unit = gain * 0.15;

        remainderYaw += stepYaw;
        remainderPitch += stepPitch;
        long countsYaw = (long) (remainderYaw / unit);
        long countsPitch = (long) (remainderPitch / unit);
        remainderYaw -= countsYaw * unit;
        remainderPitch -= countsPitch * unit;
        if (countsYaw != 0L || countsPitch != 0L) {
            player.changeLookDirection(countsYaw * gain, countsPitch * gain);
        }
    }
}
