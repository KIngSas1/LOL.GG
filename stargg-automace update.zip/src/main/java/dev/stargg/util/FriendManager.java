package dev.stargg.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent friend list used by imported combat modules. */
public final class FriendManager {

    private static final FriendManager INSTANCE = new FriendManager();
    private final Map<UUID, Friend> friends = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("stargg").resolve("friends.json");

    private FriendManager() {
        load();
    }

    public static FriendManager getInstance() {
        return INSTANCE;
    }

    public void addFriend(String name, UUID uuid) {
        if (name == null || name.isBlank() || uuid == null) return;
        friends.put(uuid, new Friend(name, uuid));
        save();
    }

    public void removeFriend(UUID uuid) {
        if (uuid != null && friends.remove(uuid) != null) save();
    }

    public void removeFriend(String name) {
        if (name == null || name.isBlank()) return;
        friends.values().stream().filter(friend -> friend.name().equalsIgnoreCase(name))
                .findFirst().ifPresent(friend -> removeFriend(friend.uuid()));
    }

    public boolean isFriend(UUID uuid) {
        return uuid != null && friends.containsKey(uuid);
    }

    public boolean isFriend(String name) {
        return name != null && !name.isBlank() && friends.values().stream()
                .anyMatch(friend -> friend.name().equalsIgnoreCase(name));
    }

    public Friend getFriend(UUID uuid) {
        return uuid == null ? null : friends.get(uuid);
    }

    public List<Friend> getFriends() {
        return new ArrayList<>(friends.values());
    }

    public void clearFriends() {
        friends.clear();
        save();
    }

    public void updateFriendNote(UUID uuid, String note) {
        Friend friend = getFriend(uuid);
        if (friend == null) return;
        friends.put(uuid, new Friend(friend.name(), friend.uuid(), friend.addedTime(), note));
        save();
    }

    private void save() {
        try {
            Files.createDirectories(file.getParent());
            JsonObject root = new JsonObject();
            JsonArray array = new JsonArray();
            for (Friend friend : friends.values()) {
                JsonObject item = new JsonObject();
                item.addProperty("name", friend.name());
                item.addProperty("uuid", friend.uuid().toString());
                item.addProperty("addedTime", friend.addedTime());
                item.addProperty("note", friend.note());
                array.add(item);
            }
            root.add("friends", array);
            Files.writeString(file, gson.toJson(root));
        } catch (IOException ignored) {
            // A failed friends-file write must not crash the game client.
        }
    }

    private void load() {
        if (!Files.isRegularFile(file)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            JsonArray array = root.has("friends") && root.get("friends").isJsonArray()
                    ? root.getAsJsonArray("friends") : new JsonArray();
            for (JsonElement element : array) {
                if (!element.isJsonObject()) continue;
                JsonObject item = element.getAsJsonObject();
                String name = item.has("name") ? item.get("name").getAsString() : "";
                UUID uuid = UUID.fromString(item.get("uuid").getAsString());
                long added = item.has("addedTime") ? item.get("addedTime").getAsLong() : System.currentTimeMillis();
                String note = item.has("note") ? item.get("note").getAsString() : "";
                if (!name.isBlank()) friends.put(uuid, new Friend(name, uuid, added, note));
            }
        } catch (Exception ignored) {
            // Ignore a malformed or partially written friend file; the client remains usable.
        }
    }
}
