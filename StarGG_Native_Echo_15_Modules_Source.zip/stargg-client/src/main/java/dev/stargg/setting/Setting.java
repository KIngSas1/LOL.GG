package dev.stargg.setting;

import com.google.gson.JsonElement;
import dev.stargg.config.ConfigManager;

import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Base class for every module option. A setting holds a value, knows how to
 * save/load itself and can hide itself in the GUI depending on other settings.
 */
public abstract class Setting<T> {

    private final String name;
    private final T defaultValue;
    protected T value;
    private BooleanSupplier visibility = () -> true;
    private Consumer<T> changeListener;

    protected Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public T get() {
        return value;
    }

    public void set(T newValue) {
        if (!Objects.equals(value, newValue)) {
            value = newValue;
            if (changeListener != null) {
                changeListener.accept(newValue);
            }
            ConfigManager.markDirty();
        }
    }

    /** Installs a listener used by settings backed by an external/original implementation. */
    public final void setChangeListener(Consumer<T> listener) {
        this.changeListener = listener;
    }

    /** Updates a mirrored value without sending it back to its external owner. */
    public final void setSilently(T newValue) {
        value = newValue;
    }

    public void reset() {
        set(defaultValue);
    }

    /** Only show this setting in the GUI while the condition is true. */
    public void showWhen(BooleanSupplier condition) {
        this.visibility = condition;
    }

    public boolean isVisible() {
        return visibility.getAsBoolean();
    }

    /** @return JSON to persist, or {@code null} if this setting is not saved. */
    public abstract JsonElement save();

    public abstract void load(JsonElement json);
}
