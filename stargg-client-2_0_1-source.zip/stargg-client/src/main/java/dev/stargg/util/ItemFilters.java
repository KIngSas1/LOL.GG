package dev.stargg.util;

import dev.stargg.setting.MultiSelectSetting;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

import java.util.Set;

/** Shared item-category matching for modules that expose Chat-V4-style item allow lists. */
public final class ItemFilters {

    private ItemFilters() {
    }

    public static boolean matches(ItemStack stack, MultiSelectSetting filter) {
        Set<String> selected = filter.getSelected();
        if (selected.isEmpty() || selected.contains("Any")) {
            return true;
        }
        if (stack == null || stack.isEmpty()) {
            return selected.contains("Hand");
        }

        String path = Registries.ITEM.getId(stack.getItem()).getPath().toLowerCase();
        boolean sword = path.endsWith("_sword") || path.equals("sword");
        boolean axe = path.endsWith("_axe") && !path.endsWith("_pickaxe");
        boolean pickaxe = path.endsWith("_pickaxe");
        boolean shovel = path.endsWith("_shovel");
        boolean hoe = path.endsWith("_hoe");
        boolean spear = path.endsWith("_spear");
        boolean tool = sword || axe || pickaxe || shovel || hoe || spear || path.equals("trident");

        return selected.contains("Swords") && sword
                || selected.contains("Axes") && axe
                || selected.contains("Pickaxes") && pickaxe
                || selected.contains("Shovels") && shovel
                || selected.contains("Hoes") && hoe
                || selected.contains("Tools") && tool
                || selected.contains("Mace") && path.equals("mace")
                || selected.contains("Trident") && path.equals("trident")
                || selected.contains("Spear") && spear
                || selected.contains("Ender Pearl") && path.equals("ender_pearl")
                || selected.contains("Wind Charge") && path.equals("wind_charge");
    }
}
