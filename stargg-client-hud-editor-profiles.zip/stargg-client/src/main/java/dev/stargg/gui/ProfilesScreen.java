package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.config.ConfigManager;
import dev.stargg.module.client.ProfilesModule;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Profiles: a list of saved setting snapshots with the active one marked, an "unsaved changes" indicator,
 * and actions to create, load, save (overwrite), rename, duplicate, delete, copy to the clipboard and import
 * from the clipboard. Double-click a profile to load it.
 */
public final class ProfilesScreen extends Screen {

    private static final int PANEL_W = 264;
    private static final int HEADER_H = 26;
    private static final int ACTIVE_H = 24;
    private static final int INPUT_H = 32;
    private static final int ROW_H = 28;
    private static final int ACTIONS_H = 60;
    private static final int STATUS_H = 18;
    private static final int PAD = 10;
    private static final int BUTTON_H = 22;
    private static final int WARNING = 0xFFE0A030;
    private static final int ERROR = 0xFFE05A5A;

    private record Btn(int x, int y, int w, int h, boolean enabled, Runnable action) {
    }

    private final List<Btn> buttons = new ArrayList<>();
    private final List<Btn> pending = new ArrayList<>();

    private List<ConfigManager.ProfileInfo> infos = List.of();
    private String selected;
    private int scroll;
    private boolean modified;
    private long lastRefresh;

    private String input = "";
    private boolean inputFocused;
    private boolean renaming;

    private String status = "";
    private boolean statusError;
    private long statusUntil;
    private String armedKey = "";
    private long armedUntil;

    // layout of the last frame, used for hit testing
    private int panelX;
    private int panelY;
    private int panelH;
    private int visibleRows = 3;
    private int fieldX;
    private int fieldY;
    private int fieldW;
    private int listY;
    private int closeX;

    public ProfilesScreen() {
        super(Text.literal("Profiles"));
        selected = StarGG.config().getActiveProfile();
        refresh();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private ConfigManager config() {
        return StarGG.config();
    }

    private void refresh() {
        infos = config().profileInfos();
        modified = config().isModified();
        lastRefresh = System.currentTimeMillis();
        boolean found = false;
        for (ConfigManager.ProfileInfo info : infos) {
            if (info.name().equals(selected)) {
                found = true;
                break;
            }
        }
        if (!found) {
            selected = config().getActiveProfile();
        }
        scroll = Math.max(0, Math.min(scroll, Math.max(0, infos.size() - visibleRows)));
    }

    private void flash(String message, boolean error) {
        status = message;
        statusError = error;
        statusUntil = System.currentTimeMillis() + 3000;
    }

    private boolean isDefault(String name) {
        return ConfigManager.DEFAULT_PROFILE.equalsIgnoreCase(name);
    }

    /** First call arms the action for three seconds, the second call within that time confirms it. */
    private boolean confirm(String key) {
        long now = System.currentTimeMillis();
        if (key.equals(armedKey) && now < armedUntil) {
            armedKey = "";
            return true;
        }
        armedKey = key;
        armedUntil = now + 3000;
        return false;
    }

    private boolean armed(String key) {
        return key.equals(armedKey) && System.currentTimeMillis() < armedUntil;
    }

    // --------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (System.currentTimeMillis() - lastRefresh > 700) {
            refresh();
        }
        pending.clear();

        int fixed = HEADER_H + ACTIVE_H + INPUT_H + ACTIONS_H + STATUS_H;
        visibleRows = Math.max(2, Math.min(7, (height - 16 - fixed) / ROW_H));
        panelH = fixed + visibleRows * ROW_H;
        int w = Math.min(PANEL_W, width - 8);
        panelX = (width - w) / 2;
        panelY = Math.max(2, (height - panelH) / 2);
        int x = panelX;
        int y = panelY;

        Ui.roundRect(context, x, y, w, panelH, 5, Theme.bg(Theme.ROW));
        renderHeader(context, mouseX, mouseY, x, y, w);
        y += HEADER_H;
        renderActive(context, mouseX, mouseY, x, y, w);
        y += ACTIVE_H;
        renderInput(context, mouseX, mouseY, x, y, w);
        y += INPUT_H;
        listY = y;
        renderList(context, mouseX, mouseY, x, y, w);
        y += visibleRows * ROW_H;
        renderActions(context, mouseX, mouseY, x, y, w);
        y += ACTIONS_H;
        renderStatus(context, x, y, w);

        buttons.clear();
        buttons.addAll(pending);
    }

    private void renderHeader(DrawContext context, int mouseX, int mouseY, int x, int y, int w) {
        Ui.roundRect(context, x, y, w, HEADER_H, 5, Theme.bg(Theme.HEADER));
        Draw.rect(context, x, y + HEADER_H - 5, w, 5, Theme.bg(Theme.HEADER));
        Ui.icon(context, Ui.Tex.LOGO, x + PAD, y + (HEADER_H - Ui.Tex.LOGO.size) / 2, Theme.TEXT_BRIGHT);
        Ui.textBold(context, "Profiles", x + PAD + 17, Ui.middleY(y, HEADER_H), Theme.TEXT_BRIGHT);
        closeX = x + w - 26;
        boolean hover = Draw.inside(mouseX, mouseY, closeX, y, 26, HEADER_H);
        Ui.textCentered(context, "x", closeX, y, 26, HEADER_H, hover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
    }

    private void renderActive(DrawContext context, int mouseX, int mouseY, int x, int y, int w) {
        String active = config().getActiveProfile();
        Ui.textMiddle(context, "Active", x + PAD, y, ACTIVE_H, Theme.TEXT_FAINT);
        int nameX = x + PAD + Ui.width("Active") + 8;
        String name = Ui.trim(active, 90);
        Ui.textBold(context, name, nameX, Ui.middleY(y, ACTIVE_H), Theme.accent());
        int after = nameX + Ui.widthBold(name) + 6;
        if (modified) {
            badge(context, "UNSAVED", after, y + 5, WARNING);
        }

        // auto-save switch on the right
        boolean auto = config().isAutoSaveProfile();
        boolean canAuto = !isDefault(active);
        String label = "Auto-save";
        int switchX = x + w - PAD - 18;
        int labelX = switchX - 6 - Ui.width(label);
        int labelColor = canAuto ? Theme.TEXT_DIM : Theme.TEXT_FAINT;
        Ui.textMiddle(context, label, labelX, y, ACTIVE_H, labelColor);
        int sy = y + (ACTIVE_H - 10) / 2;
        Ui.roundRect(context, switchX, sy, 18, 10, 5, auto && canAuto ? Theme.accent() : Theme.TRACK);
        Ui.roundRect(context, auto && canAuto ? switchX + 10 : switchX + 2, sy + 2, 6, 6, 3, auto && canAuto ? Theme.onAccent() : Theme.TEXT_DIM);
        int hitX = labelX - 4;
        pending.add(new Btn(hitX, y, x + w - hitX, ACTIVE_H, canAuto, () -> {
            config().setAutoSaveProfile(!config().isAutoSaveProfile());
            flash(config().isAutoSaveProfile() ? "Auto-save on: changes are written to " + config().getActiveProfile() : "Auto-save off", false);
        }));
    }

    private void badge(DrawContext context, String text, int x, int y, int color) {
        int w = Ui.width(text) + 8;
        Ui.roundRect(context, x, y, w, 14, 3, Draw.withAlpha(color, 0x38));
        Ui.textCentered(context, text, x, y, w, 14, color);
    }

    private void renderInput(DrawContext context, int mouseX, int mouseY, int x, int y, int w) {
        int buttonW = 66;
        fieldX = x + PAD;
        fieldY = y + 5;
        fieldW = w - PAD * 2 - buttonW - 6;
        int fieldH = 22;
        Ui.roundRect(context, fieldX, fieldY, fieldW, fieldH, 3, Theme.bg(Theme.SETTING_ROW));
        if (inputFocused) {
            Draw.rect(context, fieldX + 3, fieldY + fieldH - 1, fieldW - 6, 1, Theme.accent());
        }
        if (input.isEmpty() && !inputFocused) {
            Ui.textMiddle(context, renaming ? "New name..." : "New profile name...", fieldX + 7, fieldY, fieldH, Theme.TEXT_FAINT);
        } else {
            String shown = Ui.trim(input, fieldW - 14);
            Ui.textMiddle(context, shown, fieldX + 7, fieldY, fieldH, Theme.TEXT_BRIGHT);
            if (inputFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                Draw.rect(context, fieldX + 7 + Ui.width(shown) + 1, fieldY + 5, 1, fieldH - 10, Theme.TEXT_BRIGHT);
            }
        }
        int bx = x + w - PAD - buttonW;
        button(context, mouseX, mouseY, renaming ? "Rename" : "Create", bx, fieldY, buttonW, fieldH, true, true, this::submitInput);
    }

    private void renderList(DrawContext context, int mouseX, int mouseY, int x, int y, int w) {
        int listW = w - PAD * 2;
        int listX = x + PAD;
        Ui.roundRect(context, listX, y, listW, visibleRows * ROW_H, 4, Theme.bg(Theme.SETTING_ROW));

        String active = config().getActiveProfile();
        int last = Math.min(infos.size(), scroll + visibleRows);
        for (int i = scroll; i < last; i++) {
            ConfigManager.ProfileInfo info = infos.get(i);
            int rowY = y + (i - scroll) * ROW_H;
            boolean isSelected = info.name().equals(selected);
            boolean hovered = Draw.inside(mouseX, mouseY, listX, rowY, listW, ROW_H);
            if (isSelected) {
                Draw.rect(context, listX + 2, rowY + 1, listW - 4, ROW_H - 2, Draw.withAlpha(Theme.accent(), 0x30));
                Draw.rect(context, listX + 2, rowY + 4, 2, ROW_H - 8, Theme.accent());
            } else if (hovered) {
                Draw.rect(context, listX + 2, rowY + 1, listW - 4, ROW_H - 2, Theme.bg(Theme.ROW_HOVER));
            }
            boolean isActive = info.name().equals(active);
            String name = Ui.trim(info.name(), listW - 90);
            int textX = listX + 10;
            Ui.text(context, name, textX, rowY + 5, isSelected ? Theme.TEXT_BRIGHT : Theme.TEXT);
            if (isActive) {
                badge(context, modified ? "UNSAVED" : "ACTIVE", textX + Ui.width(name) + 6, rowY + 3, modified ? WARNING : Theme.accent());
            }
            Ui.text(context, meta(info), textX, rowY + 16, Theme.TEXT_FAINT);
        }

        if (infos.size() > visibleRows) {
            int trackH = visibleRows * ROW_H - 8;
            int barH = Math.max(12, trackH * visibleRows / infos.size());
            int barY = y + 4 + (trackH - barH) * scroll / Math.max(1, infos.size() - visibleRows);
            Draw.rect(context, listX + listW - 4, barY, 2, barH, Theme.TEXT_FAINT);
        }
    }

    private String meta(ConfigManager.ProfileInfo info) {
        if (isDefault(info.name())) {
            return "Built-in factory settings";
        }
        String modules = info.enabledModules() + (info.enabledModules() == 1 ? " module on" : " modules on");
        return modules + "  -  " + ago(info.modifiedMillis());
    }

    private static String ago(long millis) {
        if (millis <= 0) {
            return "unknown";
        }
        long seconds = Math.max(0, (System.currentTimeMillis() - millis) / 1000);
        if (seconds < 60) {
            return "just now";
        }
        if (seconds < 3600) {
            return (seconds / 60) + "m ago";
        }
        if (seconds < 86400) {
            return (seconds / 3600) + "h ago";
        }
        return (seconds / 86400) + "d ago";
    }

    private void renderActions(DrawContext context, int mouseX, int mouseY, int x, int y, int w) {
        boolean builtIn = isDefault(selected);
        int inner = w - PAD * 2;
        int gap = 4;
        int rowY = y + 6;

        String saveLabel = armed("save") ? "Sure?" : "Save";
        String deleteLabel = armed("delete") ? "Sure?" : "Delete";
        int four = (inner - gap * 3) / 4;
        int cx = x + PAD;
        button(context, mouseX, mouseY, "Load", cx, rowY, four, BUTTON_H, false, true, this::loadSelected);
        cx += four + gap;
        button(context, mouseX, mouseY, saveLabel, cx, rowY, four, BUTTON_H, armed("save"), !builtIn, this::saveSelected);
        cx += four + gap;
        button(context, mouseX, mouseY, "Rename", cx, rowY, four, BUTTON_H, renaming, !builtIn, this::startRename);
        cx += four + gap;
        button(context, mouseX, mouseY, deleteLabel, cx, rowY, inner - (four + gap) * 3, BUTTON_H, armed("delete"), !builtIn, this::deleteSelected);

        rowY += BUTTON_H + gap;
        int three = (inner - gap * 2) / 3;
        cx = x + PAD;
        button(context, mouseX, mouseY, "Duplicate", cx, rowY, three, BUTTON_H, false, !builtIn, this::duplicateSelected);
        cx += three + gap;
        button(context, mouseX, mouseY, "Copy", cx, rowY, three, BUTTON_H, false, true, this::copySelected);
        cx += three + gap;
        button(context, mouseX, mouseY, "Paste", cx, rowY, inner - (three + gap) * 2, BUTTON_H, false, true, this::pasteProfile);
    }

    private void button(DrawContext context, int mouseX, int mouseY, String label, int x, int y, int w, int h,
                        boolean active, boolean enabled, Runnable action) {
        boolean hovered = enabled && Draw.inside(mouseX, mouseY, x, y, w, h);
        int fill = active ? Theme.accent() : (hovered ? Theme.ROW_HOVER : Theme.BADGE);
        int text = !enabled ? Theme.TEXT_FAINT : (active ? Theme.onAccent() : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT));
        Ui.roundRect(context, x, y, w, h, 3, fill);
        Ui.textCentered(context, label, x, y, w, h, text);
        pending.add(new Btn(x, y, w, h, enabled, action));
    }

    private void renderStatus(DrawContext context, int x, int y, int w) {
        if (System.currentTimeMillis() > statusUntil || status.isEmpty()) {
            Ui.textCentered(context, "Double-click a profile to load it", x, y, w, STATUS_H, Theme.TEXT_FAINT);
            return;
        }
        Ui.textCentered(context, Ui.trim(status, w - PAD * 2), x, y, w, STATUS_H, statusError ? ERROR : Theme.TEXT);
    }

    // ----------------------------------------------------------------- actions

    private void submitInput() {
        String name = input.trim();
        if (renaming) {
            if (name.isEmpty()) {
                flash("Type the new name first", true);
            } else if (!name.equals(selected)) {
                if (!ConfigManager.isValidName(name)) {
                    flash("Use letters, numbers, spaces, - and _ (max " + ConfigManager.MAX_NAME_LENGTH + ")", true);
                    return;
                }
                if (config().renameProfile(selected, name)) {
                    flash("Renamed to " + name, false);
                    selected = name;
                    stopEditing();
                } else {
                    flash("That name is already used", true);
                }
            } else {
                stopEditing();
            }
            refresh();
            return;
        }

        if (name.isEmpty()) {
            name = uniqueName("profile");
        }
        if (!ConfigManager.isValidName(name)) {
            flash("Use letters, numbers, spaces, - and _ (max " + ConfigManager.MAX_NAME_LENGTH + ")", true);
        } else if (config().createProfile(name)) {
            selected = name;
            flash("Saved current settings as " + name, false);
            stopEditing();
        } else {
            flash("That name is already used", true);
        }
        refresh();
    }

    private void stopEditing() {
        input = "";
        inputFocused = false;
        renaming = false;
    }

    private String uniqueName(String base) {
        int number = 1;
        while (config().profileExists(base + "-" + number)) {
            number++;
        }
        return base + "-" + number;
    }

    private void loadSelected() {
        if (config().loadProfile(selected)) {
            flash("Loaded " + selected, false);
        } else {
            flash("Could not load " + selected, true);
        }
        refresh();
    }

    private void saveSelected() {
        if (isDefault(selected)) {
            return;
        }
        // overwriting a profile that is not the active one is easy to do by accident, so it asks first
        if (!selected.equals(config().getActiveProfile()) && !confirm("save")) {
            flash("Click Save again to overwrite " + selected + " with your current settings", false);
            return;
        }
        if (config().saveProfile(selected)) {
            flash("Saved " + selected, false);
        } else {
            flash("Could not save " + selected, true);
        }
        refresh();
    }

    private void startRename() {
        if (isDefault(selected)) {
            return;
        }
        if (renaming) {
            stopEditing();
            return;
        }
        renaming = true;
        inputFocused = true;
        input = selected;
    }

    private void deleteSelected() {
        if (isDefault(selected)) {
            return;
        }
        if (!confirm("delete")) {
            flash("Click Delete again to remove " + selected, false);
            return;
        }
        String name = selected;
        if (config().deleteProfile(name)) {
            flash("Deleted " + name, false);
            selected = config().getActiveProfile();
        } else {
            flash("Could not delete " + name, true);
        }
        refresh();
    }

    private void duplicateSelected() {
        if (isDefault(selected)) {
            return;
        }
        String copy = uniqueName(selected.length() > 18 ? selected.substring(0, 18) : selected);
        if (config().duplicateProfile(selected, copy)) {
            selected = copy;
            flash("Created " + copy, false);
        } else {
            flash("Could not duplicate " + selected, true);
        }
        refresh();
    }

    private void copySelected() {
        String json = isDefault(selected) ? config().exportCurrent() : config().exportProfile(selected);
        if (json == null) {
            flash("Nothing to copy", true);
            return;
        }
        MinecraftClient.getInstance().keyboard.setClipboard(json);
        flash(isDefault(selected) ? "Copied your current settings to the clipboard" : "Copied " + selected + " to the clipboard", false);
    }

    private void pasteProfile() {
        String text = MinecraftClient.getInstance().keyboard.getClipboard();
        String name = ConfigManager.isValidName(input.trim()) && !renaming ? input.trim() : uniqueName("imported");
        if (config().importProfile(name, text)) {
            selected = name;
            stopEditing();
            flash("Imported " + name + " - press Load to use it", false);
        } else if (config().profileExists(name)) {
            flash("That name is already used", true);
        } else {
            flash("The clipboard does not hold a StarGG profile", true);
        }
        refresh();
    }

    // ------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        for (Btn btn : buttons) {
            if (Draw.inside(mouseX, mouseY, btn.x(), btn.y(), btn.w(), btn.h())) {
                if (button == 0 && btn.enabled()) {
                    btn.action().run();
                }
                return true;
            }
        }

        if (Draw.inside(mouseX, mouseY, closeX, panelY, 26, HEADER_H)) {
            close();
            return true;
        }

        inputFocused = button == 0 && Draw.inside(mouseX, mouseY, fieldX, fieldY, fieldW, 22);
        if (inputFocused) {
            return true;
        }

        int listX = panelX + PAD;
        int listW = Math.min(PANEL_W, width - 8) - PAD * 2;
        if (button == 0 && Draw.inside(mouseX, mouseY, listX, listY, listW, visibleRows * ROW_H)) {
            int index = scroll + ((int) mouseY - listY) / ROW_H;
            if (index >= 0 && index < infos.size()) {
                String name = infos.get(index).name();
                selected = name;
                if (doubled) {
                    loadSelected();
                }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(scroll - (int) Math.signum(verticalAmount), Math.max(0, infos.size() - visibleRows)));
        return true;
    }

    @Override
    public boolean charTyped(CharInput charInput) {
        if (!inputFocused) {
            return super.charTyped(charInput);
        }
        int codePoint = charInput.codepoint();
        if (codePoint < 128 && input.length() < ConfigManager.MAX_NAME_LENGTH) {
            String typed = new String(Character.toChars(codePoint));
            if (typed.matches("[a-zA-Z0-9_\\- ]")) {
                input += typed;
            }
        }
        return true;
    }

    private static boolean controlDown() {
        long window = MinecraftClient.getInstance().getWindow().getHandle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SUPER) == GLFW.GLFW_PRESS;
    }

    @Override
    public boolean keyPressed(KeyInput keyInput) {
        int key = keyInput.key();
        if (inputFocused) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                stopEditing();
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                submitInput();
            } else if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!input.isEmpty()) {
                    input = input.substring(0, input.length() - 1);
                }
            } else if (key == GLFW.GLFW_KEY_V && controlDown()) {
                String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                if (clip != null) {
                    for (char c : clip.toCharArray()) {
                        if (input.length() < ConfigManager.MAX_NAME_LENGTH && String.valueOf(c).matches("[a-zA-Z0-9_\\- ]")) {
                            input += c;
                        }
                    }
                }
            }
            return true; // typing must not trigger anything else
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyInput);
    }

    @Override
    public void removed() {
        StarGG.modules().get(ProfilesModule.class).setEnabled(false);
        StarGG.config().save();
    }
}
