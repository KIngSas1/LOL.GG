package dev.legitclient.util;

import dev.legitclient.LegitClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Text and icon helpers for the click GUI only (the HUD keeps using {@link Draw}).
 *
 * <p>Text uses the Poppins font from {@code assets/legitclient/font/}. If the font file is missing
 * or fails to load, the font definition falls back to Minecraft's default font.
 * Icons are the white 32x32 PNGs in {@code textures/gui/ui/}, tinted at draw time.
 */
public final class Ui {

    public static final int TEXT_HEIGHT = 9;

    // If a Minecraft update changes Style#withFont, fix it here (older versions took an Identifier directly).
    private static final Style REGULAR = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(LegitClient.MOD_ID, "ui")));
    private static final Style BOLD = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(LegitClient.MOD_ID, "ui_bold")));

    private static final int TEX_SIZE = 32;

    public enum Tex {
        LOGO("logo"),
        SEARCH("search"),
        CLOSE("close"),
        DOTS("dots"),
        GEAR("gear"),
        CHEVRON_RIGHT("chevron_right"),
        CHEVRON_UP("chevron_up"),
        CHEVRON_DOWN("chevron_down"),
        CAT_HUD("cat_hud"),
        CAT_VISUAL("cat_visual"),
        CAT_UTILITY("cat_utility"),
        CAT_CLIENT("cat_client");

        private final Identifier id;

        Tex(String file) {
            this.id = Identifier.of(LegitClient.MOD_ID, "textures/gui/ui/" + file + ".png");
        }
    }

    private Ui() {
    }

    private static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    private static Text styled(String text, boolean bold) {
        return Text.literal(text).setStyle(bold ? BOLD : REGULAR);
    }

    public static int width(String text) {
        return mc().textRenderer.getWidth(styled(text, false));
    }

    public static int widthBold(String text) {
        return mc().textRenderer.getWidth(styled(text, true));
    }

    public static void text(DrawContext ctx, String text, int x, int y, int color) {
        ctx.drawText(mc().textRenderer, styled(text, false), x, y, color, false);
    }

    public static void textBold(DrawContext ctx, String text, int x, int y, int color) {
        ctx.drawText(mc().textRenderer, styled(text, true), x, y, color, false);
    }

    /** Draws text vertically centered inside a row that starts at rowY and is rowH tall. */
    public static void textMiddle(DrawContext ctx, String text, int x, int rowY, int rowH, int color) {
        text(ctx, text, x, rowY + (rowH - TEXT_HEIGHT) / 2, color);
    }

    /** Draws text so that it ends at rightX. */
    public static void textRight(DrawContext ctx, String text, int rightX, int rowY, int rowH, int color) {
        textMiddle(ctx, text, rightX - width(text), rowY, rowH, color);
    }

    public static void textCentered(DrawContext ctx, String text, int x, int rowY, int w, int rowH, int color) {
        textMiddle(ctx, text, x + (w - width(text)) / 2, rowY, rowH, color);
    }

    public static String trim(String text, int maxWidth) {
        if (width(text) <= maxWidth) {
            return text;
        }
        String cut = text;
        while (!cut.isEmpty() && width(cut + "..") > maxWidth) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut + "..";
    }

    /** Draws a (square) icon tinted with the given ARGB color. */
    public static void icon(DrawContext ctx, Tex tex, int x, int y, int size, int color) {
        // The only tinted-texture call in the GUI; if a Minecraft update changes it, fix it here.
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex.id, x, y, 0f, 0f, size, size, TEX_SIZE, TEX_SIZE, TEX_SIZE, TEX_SIZE, color);
    }
}
