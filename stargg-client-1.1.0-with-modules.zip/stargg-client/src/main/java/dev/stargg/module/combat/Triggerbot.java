package dev.stargg.module.combat;

import dev.stargg.StarGG;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/** Automatically attacks a valid entity while it remains under the crosshair. */
public final class Triggerbot extends Module {

    private final NumberSetting targetDelay = add(new NumberSetting("Target delay", 35, 0, 500, 5));
    private final NumberSetting extraDelay = add(new NumberSetting("Extra delay", 0, 0, 10, 1));
    private final BooleanSetting requireMouseDown = add(new BooleanSetting("Require mouse down", false));
    private final BooleanSetting shieldCheck = add(new BooleanSetting("Shield check", false));
    private final BooleanSetting airCrits = add(new BooleanSetting("Air crits", false));

    private int hoveredEntityId = -1;
    private long hoveredSince;
    private long lastAttackAt;

    public Triggerbot() {
        super("Triggerbot", "Automatically attacks the entity under your crosshair", Category.COMBAT);
        icon(Icon.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            resetHover();
            return;
        }
        if (requireMouseDown.on() && !mc.options.attackKey.isPressed()) {
            resetHover();
            return;
        }
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) {
            resetHover();
            return;
        }

        Entity entity = hit.getEntity();
        if (!(entity instanceof LivingEntity target) || !target.isAlive() || target == mc.player) {
            resetHover();
            return;
        }
        if (target instanceof PlayerEntity playerTarget && playerTarget.isBlocking()) {
            ShieldBreaker shieldBreaker = StarGG.modules().get(ShieldBreaker.class);
            if (shieldCheck.on() || (shieldBreaker != null && shieldBreaker.isEnabled())) {
                resetHover();
                return;
            }
        }
        if (airCrits.on() && (mc.player.isOnGround() || mc.player.fallDistance <= 0.0F)) {
            resetHover();
            return;
        }

        long now = System.currentTimeMillis();
        if (hoveredEntityId != target.getId()) {
            hoveredEntityId = target.getId();
            hoveredSince = now;
            return;
        }
        if (now - hoveredSince < targetDelay.getInt()) {
            return;
        }
        if (now - lastAttackAt < extraDelay.getInt() * 50L) {
            return;
        }
        if (mc.player.getAttackCooldownProgress(0.5F) < 1.0F) {
            return;
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        lastAttackAt = now;
        hoveredSince = now;
    }

    @Override
    protected void onDisable() {
        resetHover();
    }

    private void resetHover() {
        hoveredEntityId = -1;
        hoveredSince = 0L;
    }
}
