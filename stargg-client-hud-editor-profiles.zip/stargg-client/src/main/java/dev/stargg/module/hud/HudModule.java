package dev.stargg.module.hud;

import com.google.gson.JsonObject;
import dev.stargg.config.ConfigManager;
import dev.stargg.gui.Theme;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ColorSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

/**
 * Base class for on-screen HUD elements. Subclasses only describe their size
 * and how to draw themselves; placement, clamping, saving the position and
 * dragging in the HUD editor are handled here.
 *
 * <p>Positions are stored <b>anchored</b>: the element remembers which third of the screen it sits in
 * (left / center / right and top / center / bottom) and its distance from that edge. A module list that
 * hugs the right edge therefore still hugs it after the window or the GUI scale changes.
 *
 * <p>Default positions: a negative value is a margin from the right / bottom edge
 * (e.g. {@code -4} = 4px from the edge).
 */
public abstract class HudModule extends Module {

    public static final int ANCHOR_START = 0;
    public static final int ANCHOR_CENTER = 1;
    public static final int ANCHOR_END = 2;

    private static final int PADDING = 3;
    private static final int MIN_WIDTH = 30;
    private static final int MIN_HEIGHT = 10;

    protected final BooleanSetting shadow;
    protected final BooleanSetting background;
    protected final ColorSetting color;

    private final int defaultX;
    private final int defaultY;

    // anchored position: anchor (0 start, 1 center, 2 end) + offset from that anchor
    private int anchorX;
    private int anchorY;
    private int offsetX;
    private int offsetY;
    private boolean placed;

    // resolved on-screen rectangle of the last frame
    private int x;
    private int y;
    private int width;
    private int height;

    protected HudModule(String name, String description, int defaultX, int defaultY) {
        this(name, description, defaultX, defaultY, false);
    }

    protected HudModule(String name, String description, int defaultX, int defaultY, boolean backgroundByDefault) {
        super(name, description, Category.HUD);
        this.defaultX = defaultX;
        this.defaultY = defaultY;
        this.shadow = add(new BooleanSetting("Text shadow", false));
        this.background = add(new BooleanSetting("Background", backgroundByDefault));
        this.color = add(new ColorSetting("Color", "White"));
    }

    // -------------------------------------------------------- subclass contract

    /** Called first on every frame — gather the data you are going to draw. */
    protected void prepare() {
    }

    /** Width of the content in pixels (without padding). */
    protected abstract int contentWidth();

    /** Height of the content in pixels (without padding). */
    protected abstract int contentHeight();

    /** Draw the content with its top-left corner at (x, y). */
    protected abstract void draw(DrawContext context, int x, int y);

    // ----------------------------------------------------------------- helpers

    protected final int textColor() {
        return color.argb();
    }

    protected final void text(DrawContext context, String text, int x, int y) {
        Draw.text(context, text, x, y, textColor(), shadow.on());
    }

    /** Padding between the element's box and its content. */
    protected final int padding() {
        return PADDING;
    }

    // --------------------------------------------------------------- rendering

    public final void renderHud(DrawContext context, int screenWidth, int screenHeight) {
        prepare();
        int w = Math.max(MIN_WIDTH, contentWidth()) + PADDING * 2;
        int h = Math.max(MIN_HEIGHT, contentHeight()) + PADDING * 2;

        if (!placed) {
            applyDefaultPosition();
        }
        x = Math.max(0, Math.min(resolve(anchorX, offsetX, w, screenWidth), screenWidth - w));
        y = Math.max(0, Math.min(resolve(anchorY, offsetY, h, screenHeight), screenHeight - h));
        width = w;
        height = h;

        if (background.on()) {
            Ui.roundRect(context, x, y, w, h, 3, Theme.bg(Theme.HEADER));
        }
        draw(context, x + PADDING, y + PADDING);
    }

    private static int resolve(int anchor, int offset, int size, int screen) {
        return switch (anchor) {
            case ANCHOR_START -> offset;
            case ANCHOR_CENTER -> (screen - size) / 2 + offset;
            default -> screen - size - offset;
        };
    }

    private static int anchorFor(int position, int size, int screen) {
        int center = position + size / 2;
        if (center < screen / 3) {
            return ANCHOR_START;
        }
        return center > screen * 2 / 3 ? ANCHOR_END : ANCHOR_CENTER;
    }

    private static int offsetFor(int anchor, int position, int size, int screen) {
        return switch (anchor) {
            case ANCHOR_START -> position;
            case ANCHOR_CENTER -> position - (screen - size) / 2;
            default -> screen - size - position;
        };
    }

    private void applyDefaultPosition() {
        anchorX = defaultX >= 0 ? ANCHOR_START : ANCHOR_END;
        offsetX = Math.abs(defaultX);
        anchorY = defaultY >= 0 ? ANCHOR_START : ANCHOR_END;
        offsetY = Math.abs(defaultY);
        // not marked as placed: an element that was never moved is not written to the config / profiles
    }

    // ---------------------------------------------------- positioning (HUD editor)

    public final boolean contains(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, x, y, width, height);
    }

    /** Moves the element so its top-left corner is at (newX, newY) on a screen of the given size. */
    public final void moveTo(int newX, int newY, int screenWidth, int screenHeight) {
        newX = Math.max(0, Math.min(newX, screenWidth - width));
        newY = Math.max(0, Math.min(newY, screenHeight - height));
        anchorX = anchorFor(newX, width, screenWidth);
        anchorY = anchorFor(newY, height, screenHeight);
        offsetX = offsetFor(anchorX, newX, width, screenWidth);
        offsetY = offsetFor(anchorY, newY, height, screenHeight);
        x = newX;
        y = newY;
        placed = true;
        ConfigManager.markDirty();
    }

    /** Puts just this element back to its default place. */
    public final void resetPosition() {
        placed = false;
        ConfigManager.markDirty();
    }

    public final int getX() {
        return x;
    }

    public final int getY() {
        return y;
    }

    public final int getWidth() {
        return width;
    }

    public final int getHeight() {
        return height;
    }

    // ------------------------------------------------------------- persistence

    @Override
    protected void writeExtra(JsonObject json) {
        if (placed) {
            json.addProperty("ax", anchorX);
            json.addProperty("ay", anchorY);
            json.addProperty("ox", offsetX);
            json.addProperty("oy", offsetY);
        }
    }

    @Override
    protected void resetExtra() {
        placed = false;
    }

    @Override
    protected void readExtra(JsonObject json) {
        if (json.has("ax") && json.has("ay") && json.has("ox") && json.has("oy")) {
            anchorX = clampAnchor(json.get("ax").getAsInt());
            anchorY = clampAnchor(json.get("ay").getAsInt());
            offsetX = json.get("ox").getAsInt();
            offsetY = json.get("oy").getAsInt();
            placed = true;
        } else if (json.has("x") && json.has("y")) {
            // config written before anchored positions: absolute top-left coordinates
            anchorX = ANCHOR_START;
            anchorY = ANCHOR_START;
            offsetX = json.get("x").getAsInt();
            offsetY = json.get("y").getAsInt();
            placed = true;
        }
    }

    private static int clampAnchor(int anchor) {
        return Math.max(ANCHOR_START, Math.min(ANCHOR_END, anchor));
    }
}
