package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.ItemFilters;
import dev.stargg.util.TargetFilters;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Native StarGG port of Chat V4's Simple/Adaptive AimAssist and its targeting options. */
public final class AimAssist extends Module {

    private static final String[] TARGET_OPTIONS = {
            "Players", "Mobs", "Peaceful", "Neutral", "Ignore naked", "Ignore invisible", "Ignore behind walls"
    };
    private static final String[] ITEM_OPTIONS = {
            "Swords", "Axes", "Pickaxes", "Shovels", "Hoes", "Tools", "Mace", "Trident", "Ender Pearl", "Wind Charge", "Hand"
    };

    private final ModeSetting mode = add(new ModeSetting("Mode", "Simple", "Simple", "Adaptive"));
    private final MultiSelectSetting targetFilter = add(new MultiSelectSetting("Target settings", TARGET_OPTIONS, "Players"));
    private final BooleanSetting requireMouseDown = add(new BooleanSetting("Require mouse down", true));
    private final BooleanSetting strafeIncrease = add(new BooleanSetting("Strafe increase", false));
    private final BooleanSetting checkBlockBreak = add(new BooleanSetting("Check block break", false));
    private final BooleanSetting breakBlocksWhitelist = add(new BooleanSetting("Break blocks whitelist", false));
    private final MultiSelectSetting blockBreakItems = add(new MultiSelectSetting(
            "Block-break items", new String[]{"Pickaxes", "Shovels"}, "Pickaxes", "Shovels"));
    private final BooleanSetting aimVertically = add(new BooleanSetting("Aim vertically", false));
    private final NumberSetting verticalSpeed = add(new NumberSetting("Vertical speed", 5.0, 1.0, 10.0, 0.5));
    private final NumberSetting horizontalSpeed = add(new NumberSetting("Horizontal speed", 5.0, 1.0, 10.0, 0.5));
    private final NumberSetting maxAngle = add(new NumberSetting("Max angle", 180.0, 1.0, 360.0, 1.0));
    private final NumberSetting distance = add(new NumberSetting("Distance", 5.0, 1.0, 8.0, 0.1));
    private final BooleanSetting limitToItems = add(new BooleanSetting("Limit to items", false));
    private final MultiSelectSetting allowedItems = add(new MultiSelectSetting("Allowed items", ITEM_OPTIONS, "Swords"));
    private final ModeSetting targetArea = add(new ModeSetting("Target area", "Center", "Center", "Closest"));
    private final ModeSetting targetMode = add(new ModeSetting("Target mode", "Yaw", "Yaw", "Distance", "Armor", "Threat", "Health"));

    public AimAssist() {
        super("Aim Assist", "Smoothly aims toward the best filtered target", Category.COMBAT);
        icon(Icon.AIM_ASSIST);
        verticalSpeed.showWhen(aimVertically::on);
        breakBlocksWhitelist.showWhen(checkBlockBreak::on);
        blockBreakItems.showWhen(() -> checkBlockBreak.on() && breakBlocksWhitelist.on());
        allowedItems.showWhen(limitToItems::on);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            return;
        }
        if (requireMouseDown.on() && !mc.options.attackKey.isPressed()) {
            return;
        }
        if (checkBlockBreak.on() && mc.crosshairTarget instanceof BlockHitResult
                && (!breakBlocksWhitelist.on() || ItemFilters.matches(mc.player.getMainHandStack(), blockBreakItems))) {
            return;
        }
        if (limitToItems.on() && !ItemFilters.matches(mc.player.getMainHandStack(), allowedItems)) {
            return;
        }

        LivingEntity target = findTarget();
        if (target == null) {
            return;
        }

        Vec3d aimPoint = targetPoint(target);
        Vec3d difference = aimPoint.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(difference.x * difference.x + difference.z * difference.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(difference.z, difference.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(difference.y, horizontal));
        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();

        double speedScale = 1.0;
        if (mode.is("Adaptive")) {
            double angularError = Math.hypot(yawDelta, aimVertically.on() ? pitchDelta : 0.0);
            speedScale = MathHelper.clamp(0.55 + angularError / 45.0, 0.65, 1.8);
        }
        if (strafeIncrease.on()) {
            Vec3d velocity = mc.player.getVelocity();
            Vec3d toTarget = new Vec3d(difference.x, 0.0, difference.z).normalize();
            double lateral = Math.abs(toTarget.x * velocity.z - toTarget.z * velocity.x);
            if (lateral > 0.08) {
                speedScale *= 1.35;
            }
        }

        float yawStep = (float) (horizontalSpeed.getDouble() * speedScale);
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yawDelta, -yawStep, yawStep));
        if (aimVertically.on()) {
            float pitchStep = (float) (verticalSpeed.getDouble() * speedScale);
            mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(pitchDelta, -pitchStep, pitchStep), -90.0F, 90.0F));
        }
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        double range = distance.getDouble();
        for (Entity entity : mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(range),
                candidate -> candidate instanceof LivingEntity && candidate.isAlive())) {
            if (!(entity instanceof LivingEntity living)
                    || !TargetFilters.matches(living, targetFilter, MinecraftClient.getInstance())
                    || mc.player.distanceTo(living) > range) {
                continue;
            }

            Vec3d point = targetPoint(living);
            Vec3d delta = point.subtract(mc.player.getEyePos());
            double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
            float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
            float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
            double yawError = Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
            double pitchError = aimVertically.on() ? Math.abs(pitch - mc.player.getPitch()) : 0.0;
            double angle = Math.hypot(yawError, pitchError);
            if (angle > maxAngle.getDouble() / 2.0) {
                continue;
            }

            double score = switch (targetMode.get()) {
                case "Distance" -> mc.player.squaredDistanceTo(living);
                case "Armor" -> -armorPieces(living);
                case "Threat" -> -(living.getHealth() + armorPieces(living) * 2.0);
                case "Health" -> living.getHealth();
                default -> angle;
            };
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private Vec3d targetPoint(LivingEntity target) {
        Box box = target.getBoundingBox();
        if (targetArea.is("Closest")) {
            return new Vec3d(
                    MathHelper.clamp(mc.player.getX(), box.minX, box.maxX),
                    MathHelper.clamp(mc.player.getEyeY(), box.minY, box.maxY),
                    MathHelper.clamp(mc.player.getZ(), box.minZ, box.maxZ));
        }
        return box.getCenter();
    }

    private int armorPieces(LivingEntity entity) {
        if (!(entity instanceof PlayerEntity player)) {
            return 0;
        }
        int count = 0;
        if (!player.getEquippedStack(EquipmentSlot.HEAD).isEmpty()) count++;
        if (!player.getEquippedStack(EquipmentSlot.CHEST).isEmpty()) count++;
        if (!player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()) count++;
        if (!player.getEquippedStack(EquipmentSlot.FEET).isEmpty()) count++;
        return count;
    }
}
