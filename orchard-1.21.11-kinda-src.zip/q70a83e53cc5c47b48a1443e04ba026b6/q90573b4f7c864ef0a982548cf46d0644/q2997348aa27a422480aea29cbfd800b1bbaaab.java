package q70a83e53cc5c47b48a1443e04ba026b6.q90573b4f7c864ef0a982548cf46d0644;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_3965;

@Environment(EnvType.CLIENT)
record q2997348aa27a422480aea29cbfd800b1bbaaab(class_2338 eB, class_3965 eC) {
   private final class_3965 a;
   private final class_2338 b;

   public class_2338 a() {
      return this.b;
   }

   public class_3965 b() {
      return this.a;
   }

   private q2997348aa27a422480aea29cbfd800b1bbaaab(class_2338 var1, class_3965 var2) {
      this.b = var1;
      this.a = var2;
   }
}
