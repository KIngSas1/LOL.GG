package dev.stargg.util;

import dev.stargg.setting.MultiSelectSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.function.Predicate;

/** Shared helpers for the combat modules: target selection, aiming maths and hotbar lookups. */
public final class CombatUtil {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public static final String[] TARGET_OPTIONS = {
            "Players", "Mobs", "Peaceful", "Neutral", "Ignore naked", "Ignore invisible", "Ignore behind walls"
    };

    public static final String[] WEAPON_OPTIONS = {
            "Any", "Swords", "Axes", "Pickaxes", "Shovels", "Hoes", "Tools", "Mace", "Trident", "Spear", "Hand"
    };

    private CombatUtil() {
    }

    // ---------------------------------------------------------------- targets

    public static boolean isValidTarget(Entity entity, MultiSelectSetting filters, boolean ignoreFriends) {
        if (!(entity instanceof LivingEntity living)) {
            return false;
        }
        if (!TargetFilters.matches(living, filters, mc)) {
            return false;
        }
        return !(ignoreFriends && living instanceof PlayerEntity player
                && FriendManager.getInstance().isFriend(player.getUuid()));
    }

    /** Valid targets whose hitbox is within {@code range} of the player's eyes. */
    public static List<LivingEntity> targetsInRange(double range, MultiSelectSetting filters, boolean ignoreFriends) {
        if (mc.world == null || mc.player == null) {
            return List.of();
        }
        Box area = mc.player.getBoundingBox().expand(range + 1.0);
        return mc.world.getEntitiesByClass(LivingEntity.class, area,
                entity -> isValidTarget(entity, filters, ignoreFriends)
                        && mc.player.getEyePos().distanceTo(nearestPoint(entity)) <= range);
    }

    /**
     * Picks one target. {@code priority} is "Distance", "Health" or "Crosshair"; candidates outside the
     * {@code fov} cone (full angle in degrees) are skipped.
     */
    public static LivingEntity best(List<LivingEntity> candidates, String priority, double fov) {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity entity : candidates) {
            double angle = angleTo(entity.getBoundingBox().getCenter());
            if (angle > fov / 2.0) {
                continue;
            }
            double score = switch (priority) {
                case "Health" -> entity.getHealth() + entity.getAbsorptionAmount();
                case "Crosshair" -> angle;
                default -> mc.player.getEyePos().distanceTo(nearestPoint(entity));
            };
            if (score < bestScore) {
                bestScore = score;
                best = entity;
            }
        }
        return best;
    }

    /** Closest point of the entity's hitbox to the player's eyes. */
    public static Vec3d nearestPoint(Entity entity) {
        Vec3d eye = mc.player.getEyePos();
        Box box = entity.getBoundingBox();
        return new Vec3d(
                MathHelper.clamp(eye.x, box.minX, box.maxX),
                MathHelper.clamp(eye.y, box.minY, box.maxY),
                MathHelper.clamp(eye.z, box.minZ, box.maxZ));
    }

    /** "Head", "Body", "Feet" or "Nearest". */
    public static Vec3d aimPoint(LivingEntity entity, String mode) {
        return switch (mode) {
            case "Head" -> entity.getEyePos();
            case "Feet" -> entity.getEntityPos().add(0.0, 0.2, 0.0);
            case "Nearest" -> nearestPoint(entity);
            default -> entity.getBoundingBox().getCenter();
        };
    }

    // --------------------------------------------------------------- rotation

    /** Angle in degrees between the player's view direction and the given point. */
    public static double angleTo(Vec3d point) {
        Vec3d toPoint = point.subtract(mc.player.getEyePos());
        double length = toPoint.length();
        if (length < 1.0E-6) {
            return 0.0;
        }
        double dot = MathHelper.clamp(mc.player.getRotationVec(1.0F).dotProduct(toPoint) / length, -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    /** {yaw, pitch} needed to look from the player's eyes at the point. */
    public static float[] rotationsTo(Vec3d point) {
        Vec3d delta = point.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        return new float[]{yaw, MathHelper.clamp(pitch, -90.0F, 90.0F)};
    }

    /**
     * Moves {@code yaw/pitch} toward the target. Each axis moves {@code 1/smoothing} of the remaining
     * distance per call, capped at the given max step (degrees).
     */
    public static float[] stepRotation(float yaw, float pitch, float targetYaw, float targetPitch,
                                       float maxYawStep, float maxPitchStep, float smoothing) {
        float divisor = Math.max(1.0F, smoothing);
        float yawDelta = MathHelper.wrapDegrees(targetYaw - yaw);
        float pitchDelta = targetPitch - pitch;
        float yawStep = MathHelper.clamp(yawDelta / divisor, -maxYawStep, maxYawStep);
        float pitchStep = MathHelper.clamp(pitchDelta / divisor, -maxPitchStep, maxPitchStep);
        return new float[]{yaw + yawStep, MathHelper.clamp(pitch + pitchStep, -90.0F, 90.0F)};
    }

    // ----------------------------------------------------------------- items

    public static int findHotbar(Predicate<ItemStack> filter) {
        for (int slot = 0; slot < 9; slot++) {
            if (filter.test(mc.player.getInventory().getStack(slot))) {
                return slot;
            }
        }
        return -1;
    }

    public static void selectSlot(int slot) {
        if (slot >= 0 && slot < 9) {
            mc.player.getInventory().setSelectedSlot(slot);
        }
    }

    public static boolean isMace(ItemStack stack) {
        return stack != null && stack.isOf(Items.MACE);
    }

    public static boolean isSpear(ItemStack stack) {
        return stack != null && !stack.isEmpty()
                && Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear");
    }

    /** Level of the enchantment whose registry id path equals {@code path} (e.g. "lunge"), or 0. */
    public static int enchantLevel(ItemStack stack, String path) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }
        ItemEnchantmentsComponent enchantments = stack.getEnchantments();
        for (RegistryEntry<Enchantment> entry : enchantments.getEnchantments()) {
            boolean match = entry.getKey().map(key -> key.getValue().getPath().equals(path)).orElse(false);
            if (match) {
                return enchantments.getLevel(entry);
            }
        }
        return 0;
    }
}
