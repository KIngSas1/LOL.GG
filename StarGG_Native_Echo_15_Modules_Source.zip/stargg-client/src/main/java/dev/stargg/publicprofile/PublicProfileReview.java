package dev.stargg.publicprofile;

/** One viewer's rating (like / dislike) of a public profile, with an optional message and an owner reply. */
public final class PublicProfileReview {

    public long id;
    public String author;
    public boolean liked;
    public String message = "";
    public long createdMillis;
    /** The profile version that was rated. */
    public long version;
    public String reply;
    public long replyMillis;
}
