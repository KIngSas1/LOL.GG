package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

/** Two small sliders for the minimum and maximum endpoints of a random setting. */
final class RandomRangeWidget extends SettingWidget {

    private final RandomRangeSetting setting;
    private int draggingEndpoint = -1;

    RandomRangeWidget(RandomRangeSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 48;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY) || draggingEndpoint != -1);
        label(context, setting.getName(), Theme.TEXT);
        drawEndpoint(context, "Min", setting.getMinimum(), setting.getMinAllowed(), setting.getMaxAllowed(), y + 19);
        drawEndpoint(context, "Max", setting.getMaximum(), setting.getMinAllowed(), setting.getMaxAllowed(), y + 34);
    }

    private void drawEndpoint(DrawContext context, String label, double value, double min, double max, int rowY) {
        Ui.textMiddle(context, label, x + Theme.PADDING, rowY - 2, 12, Theme.TEXT_DIM);
        Ui.text(context, setting.display(value), x + Theme.PADDING + 22, rowY, Theme.TEXT);
        int trackX = x + 65;
        int trackW = Math.max(8, w - Theme.PADDING - 65 - 8);
        int trackY = rowY + 4;
        double fraction = max <= min ? 0.0 : (value - min) / (max - min);
        int filled = (int) Math.round(trackW * fraction);
        Ui.roundRect(context, trackX, trackY, trackW, 3, 1, Theme.TRACK);
        if (filled > 1) {
            Ui.roundRect(context, trackX, trackY, filled, 3, 1, Theme.accent());
        }
        int knobX = trackX + Math.max(0, Math.min(trackW - 7, filled - 3));
        Ui.roundRect(context, knobX, trackY - 2, 7, 7, 3, 0xFFFFFFFF);
    }

    private void apply(double mouseX, int endpoint) {
        int trackX = x + 65;
        int trackW = Math.max(8, w - Theme.PADDING - 65 - 8);
        double fraction = Math.max(0.0, Math.min(1.0, (mouseX - trackX) / trackW));
        double value = setting.getMinAllowed() + fraction * (setting.getMaxAllowed() - setting.getMinAllowed());
        if (endpoint == 0) {
            setting.setMinimum(value);
        } else {
            setting.setMaximum(value);
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 1) {
            setting.reset();
            return;
        }
        if (button != 0) {
            return;
        }
        draggingEndpoint = mouseY < y + 33 ? 0 : 1;
        apply(mouseX, draggingEndpoint);
    }

    @Override
    public void drag(double mouseX) {
        if (draggingEndpoint != -1) {
            apply(mouseX, draggingEndpoint);
        }
    }

    @Override
    public void release() {
        draggingEndpoint = -1;
    }
}
