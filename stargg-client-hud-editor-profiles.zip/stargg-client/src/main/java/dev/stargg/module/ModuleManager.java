package dev.stargg.module;

import dev.stargg.StarGG;
import dev.stargg.module.client.ClickGuiModule;
import dev.stargg.module.client.HudEditorModule;
import dev.stargg.module.client.ProfilesModule;
import dev.stargg.module.combat.AimAssist;
import dev.stargg.module.combat.ShieldBreaker;
import dev.stargg.module.combat.Triggerbot;
import dev.stargg.module.combat.WTap;
import dev.stargg.module.hud.ArmorStatus;
import dev.stargg.module.hud.Clock;
import dev.stargg.module.hud.Compass;
import dev.stargg.module.hud.Coordinates;
import dev.stargg.module.hud.Cps;
import dev.stargg.module.hud.Fps;
import dev.stargg.module.hud.HudModule;
import dev.stargg.module.hud.Keystrokes;
import dev.stargg.module.hud.ModuleList;
import dev.stargg.module.hud.Ping;
import dev.stargg.module.hud.PotionEffects;
import dev.stargg.module.hud.Watermark;
import dev.stargg.module.utility.ToggleSprint;
import dev.stargg.module.movement.Sprint;
import dev.stargg.module.visual.Fullbright;
import dev.stargg.module.visual.NoHurtCam;
import dev.stargg.module.visual.WeatherChanger;
import dev.stargg.module.visual.Zoom;
import dev.stargg.util.ClickTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Owns every module: registration, key binds and the per-tick / per-frame dispatch. */
public final class ModuleManager {

    private final Map<Class<? extends Module>, Module> modules = new LinkedHashMap<>();

    /**
     * Register every module here. Order inside a category is the order shown in the GUI.
     * Adding a feature = one new line.
     */
    public void init() {
        // HUD
        register(new Watermark());
        register(new Fps());
        register(new Cps());
        register(new Ping());
        register(new Coordinates());
        register(new Compass());
        register(new Clock());
        register(new Keystrokes());
        register(new ArmorStatus());
        register(new PotionEffects());
        register(new ModuleList());

        // Combat
        register(new Triggerbot());
        register(new AimAssist());
        register(new ShieldBreaker());
        register(new WTap());

        // Movement
        register(new Sprint());

        // Visual
        register(new Fullbright());
        register(new Zoom());
        register(new NoHurtCam());
        register(new WeatherChanger());

        // Utility
        register(new ToggleSprint());

        // Client
        register(new ClickGuiModule());
        register(new HudEditorModule());
        register(new ProfilesModule());

        for (Module module : modules.values()) {
            module.applyDefaultState();
        }
    }

    private void register(Module module) {
        modules.put(module.getClass(), module);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        return (T) modules.get(type);
    }

    public Module byName(String name) {
        for (Module module : modules.values()) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }
        return null;
    }

    public List<Module> all() {
        return Collections.unmodifiableList(new ArrayList<>(modules.values()));
    }

    public List<Module> inCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module module : modules.values()) {
            if (module.getCategory() == category) {
                result.add(module);
            }
        }
        return result;
    }

    // --------------------------------------------------------------- dispatch

    /** Called once per client tick. */
    public void tick(MinecraftClient client) {
        pollKeyBinds(client);
        if (client.player == null || client.world == null) {
            return;
        }
        for (Module module : modules.values()) {
            if (module.isEnabled()) {
                guard(module, module::onTick);
            }
        }
    }

    /** Called from the client interaction mixin immediately before a local attack. */
    public void onAttack(net.minecraft.entity.Entity target) {
        for (Module module : modules.values()) {
            if (module.isEnabled()) {
                guard(module, () -> module.onAttack(target));
            }
        }
    }

    /** Called once per frame from the HUD layer. */
    public void renderHud(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClickTracker.update(client);
        if (client.options.hudHidden || client.player == null) {
            return;
        }
        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();
        for (Module module : modules.values()) {
            if (!module.isEnabled()) {
                continue;
            }
            if (module instanceof HudModule hud) {
                guard(module, () -> hud.renderHud(context, width, height));
            } else {
                guard(module, () -> module.onRender2D(context));
            }
        }
    }

    private boolean keyPollingBroken;

    private void pollKeyBinds(MinecraftClient client) {
        if (keyPollingBroken) {
            return;
        }
        try {
            pollKeyBindsUnsafe(client);
        } catch (Throwable t) {
            // e.g. a launcher whose GLFW layer lacks glfwGetKey: keep the game running, binds just stay off
            keyPollingBroken = true;
            StarGG.LOGGER.error("Key bind polling failed and was disabled", t);
        }
    }

    private void pollKeyBindsUnsafe(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        boolean inGame = client.currentScreen == null;

        for (Module module : modules.values()) {
            int key = module.getKey();
            if (key <= 0) {
                module.keyDown = false;
                continue;
            }
            boolean down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
            if (inGame) {
                if (module.getBindMode() == BindMode.HOLD) {
                    module.setEnabled(down);
                } else if (down && !module.keyDown) {
                    module.toggle();
                }
            } else if (module.getBindMode() == BindMode.HOLD && module.isEnabled()) {
                module.setEnabled(false);
            }
            module.keyDown = down;
        }
    }

    /** A crashing module is switched off instead of crashing the game. */
    private void guard(Module module, Runnable action) {
        try {
            action.run();
        } catch (Throwable t) {
            StarGG.LOGGER.error("Module '{}' failed and was disabled", module.getName(), t);
            module.setEnabled(false);
        }
    }
}
