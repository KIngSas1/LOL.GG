# STAR.GG (Fabric 1.21.11)

A client-side Fabric mod with a custom click GUI, HUD/visual modules, and configurable combat and movement helpers. It uses Fabric Loader and the client-side Minecraft API.

## Build the jar

Requirements: **JDK 21**.

```
./gradlew build          # Windows: gradlew.bat build
```

The jar is `build/libs/stargg-2.0.0.jar`. Put it in `.minecraft/mods` together with
**Fabric Loader** and **Fabric API** for 1.21.11.
To test from your IDE: `./gradlew runClient`.

Pushing the project to GitHub also builds the jar automatically (`.github/workflows/build.yml`).

> If Gradle can't resolve a version, open <https://fabricmc.net/develop>, pick 1.21.11 and copy the
> `yarn_mappings`, `loader_version`, `loom_version` and `fabric_version` lines into `gradle.properties`.

## Use it

* **Right Shift** opens the click GUI. The main panel (left) opens/closes one panel per category; the gear and *Profiles* jump to the theme/profile settings; the top search bar filters modules by name. Rebind it in the GUI: *Client > Click GUI > Bind*.
* Tap a module = toggle. Tap the **+/-** on its row (or right click) = open its settings.
* In the settings: **Bind** (click, then press a key; **Esc**, Backspace or a second click unbinds) and **Bind mode** (Toggle / Hold).
* Tap the arrow on a panel header (or right click it) to collapse it, drag the header to move the panel.
* Drag empty space (or use the mouse wheel) to scroll when panels are taller than the screen. **X** (top right) closes the GUI.
* While the GUI is open, drag any enabled **HUD element** to reposition it.
* Config is saved to `.minecraft/config/stargg/config.json`.
  The *Click GUI* module has Load / Save / New **profile** buttons (`.../profiles/*.json`).

## Mobile (MojoLauncher / PojavLauncher, LTW / OpenGL ES 3)

Normal Fabric mod; it only draws through Minecraft's own `DrawContext` (no raw OpenGL, no custom shaders),
so it does not depend on the renderer.

1. Put `stargg-2.0.0.jar` and **Fabric API** in the 1.21.11 Fabric profile's `mods` folder (Java 21).
2. In the MojoLauncher control editor add a button that sends **Right Shift** (or any key you bound the
   Click GUI to). Do the same for any module you want to toggle/hold by key (e.g. C for Zoom).
3. The GUI works with taps and drags: tap = toggle, tap **+/-** = settings, drag empty space = scroll,
   **X** (top right) = close. A GUI scale of 2-3 fits best.
4. CPS / Keystrokes read Minecraft's attack/use key state, so they work with touch controls.

## Modules

| Category | Modules |
|----------|---------|
| HUD | Watermark, FPS, CPS, Ping, Coordinates, Compass, Clock, Keystrokes, Armor Status, Potion Effects, Module List |
| Combat | Wind Charge Key |
| Movement | Sprint |
| Visual | Fullbright, Zoom (hold C), No Hurt Cam, Weather Changer |
| Utility | Toggle Sprint |
| Client | Click GUI (accent color, opacity, background dim, profiles) |

## Project layout

```
dev.stargg
├─ StarGG            entry point (events -> ModuleManager)
├─ module/                Module, Category, BindMode, ModuleManager   <- register modules here
│  ├─ hud/                HudModule, TextHudModule + HUD modules
│  ├─ movement/           Sprint
│  ├─ visual/ utility/ client/
├─ setting/               Boolean / Number / Mode / Color / Action settings
├─ config/                ConfigManager (JSON + profiles)
├─ gui/                   ClickGuiScreen (Frames), CentralGuiScreen + ModuleCard (Central), Panel, ModuleButton, Theme, widget/
│                         (icons: util/Icon + assets/stargg/textures/gui/icons)
├─ mixin/                 the only places that touch Minecraft internals
└─ util/                  Draw helpers, ClickTracker, KeyNames
```

## GUI styles: Frames and Central

The click GUI comes in two layouts. Pick one with **Client > Click GUI > GUI style** (saved with your config).
Switching while a GUI is open changes to the other one immediately (`ClickGuiModule.swapScreen()`).

* **Frames** (default): the draggable main panel plus one panel per category (`ClickGuiScreen`).
* **Central**: one dark window in the middle of the screen (`CentralGuiScreen` + `ModuleCard`):
  * **Title bar**: logo, the active profile and a close button.
  * **Button row**: **Home** (the modules), **Profiles**, **Search**, **HUD Editor**, and on the right the **gear**
    (jumps to Client > Click GUI settings, where *GUI style* is) and **reload** (loads the active profile again;
    asks for a second click while there are unsaved changes).
  * **Home**: *Favorites* and the categories as a text list on the left; the selected one's modules as cards on the
    right. A card shows the module icon, name, a summary of its first number / mode settings, the keybind chip,
    the on/off switch and a three-dots column. Click the card or switch to toggle, the dots (or right click) to open
    **all** of its settings plus Bind / Bind mode. Opened cards turn accent-colored and start with a **Favorite**
    switch; favorites appear in the Favorites tab and as small icon tiles under the list (click = toggle module).
    They are saved in the config / profiles.
  * **Profiles**: active profile, unsaved-changes state, Save, auto-save and a list to load from (select + *Load
    selected*, or double-click). *Profile manager* opens the full screen for create / rename / share.
  * The accent color follows *Client > Click GUI > Accent* (choose *Blue* for a blue look).

The nav icons (home, profiles, code, refresh, close) are drawn for this project; they live next to the other UI
icons in `assets/stargg/textures/gui/ui/` (one PNG per GUI scale) and are registered in `Ui.Tex`.

## Added movement modules

The extracted source archive used a separate `gg.vape.*` event/configuration framework and omitted much of that framework, so those classes could not be dropped into STAR.GG as-is. The port uses STAR.GG settings and tick dispatch instead. The adapted modules are configurable in the click GUI; they are not byte-for-byte copies of the source archive.

* **Sprint:** holds sprint while moving forward, with an option to skip sprinting while invisible.

## Icons

Icons are 32x32 PNGs in `src/main/resources/assets/stargg/textures/gui/icons/` (taken from the original
client's textures). Each icon has a bright file (`name.png`) and a dimmed one (`name_dim.png`, used while a
module is off). To add one: put both files there, add a constant to `util/Icon.java`, and call
`icon(Icon.YOUR_ICON)` in the module's constructor (modules without it show their category icon).
The mod-list icon is `assets/stargg/icon.png`.

## Adding a module

1. Create a class (pick a package, or add a new `Category` value for a new panel):

```java
public final class Example extends Module {

    private final BooleanSetting loud = add(new BooleanSetting("Loud", false));
    private final NumberSetting amount = add(new NumberSetting("Amount", 5, 1, 10, 1));
    private final ModeSetting style = add(new ModeSetting("Style", "A", "A", "B"));

    public Example() {
        super("Example", "What it does", Category.UTILITY);
        // defaultBind(GLFW.GLFW_KEY_H, BindMode.TOGGLE);  // optional default key
        // enabledByDefault();                              // optional
        amount.showWhen(loud::on);                          // optional: hide a setting
    }

    @Override protected void onEnable()  { }
    @Override protected void onDisable() { }
    @Override public void onTick()       { /* every tick while enabled */ }
}
```

2. Add one line in `ModuleManager.init()`: `register(new Example());`

That is all — the GUI row, settings widgets, key bind and config saving come for free.

**HUD element:** extend `TextHudModule` and return lines from `buildLines()` (see `Fps.java`, 15 lines),
or extend `HudModule` for custom drawing (see `Keystrokes.java`).

**Needs a vanilla hook?** Add a small mixin in `mixin/` and list it in
`stargg.mixins.json`. Keep the module logic in the module and only a flag/static getter in the mixin
(see `NoHurtCam` + `GameRendererMixin`).

## If something doesn't compile

This project was written without access to the 1.21.11 jars, so a few Minecraft method names may need a
one-line fix on your machine. The places that touch version-specific API are small:

* `util/Ui.java` – `Ui.draw` uses `DrawContext#getMatrices()` (`pushMatrix`/`scale`/`popMatrix`, the 1.21.6+ `Matrix3x2fStack`)
* `gui/ClickGuiScreen.java` – input signatures (`Click`, `KeyInput`)
* `StarGG.java` – `HudElementRegistry` (older Fabric API: `HudRenderCallback.EVENT`)
* `util/Draw.java` and `util/Icon.java` – `DrawContext` calls (`Icon.draw` is the only texture call)
* `mixin/*` – injectors use `require = 0`, so a target that no longer exists only logs a warning and that
  module does nothing instead of crashing the game.


## GUI assets

Icons and rounded corners in `textures/gui/ui/` are original, drawn for this project and pre-rendered per GUI scale (1-6) so they stay crisp. All text (GUI and HUD) is Proxima Nova Semibold. It is drawn from pre-rendered glyph sheets (`textures/gui/font/<ui|title>_<scale>.png` + `font/glyphs/<ui|title>_<scale>.json`, white RGBA, straight alpha) by `Ui.draw`, so there is no dark outline around letters on any renderer. Characters that are not on the sheets (CJK, emoji, ...) fall back to the TTF fonts (`assets/stargg/font/`, see `FONT-NOTICE.txt`).

## Textures

All icons now come from the supplied `textures.zip` (white, tintable, transparent PNGs).
* `textures/gui/ui/*_<px>.png` - search, dots, gear, chevrons and the six category icons, regenerated for GUI scales 1-6.
  The logo and rounded corners are unchanged (the new set has no equivalent).
* `textures/gui/icons/*.png` + `*_dim.png` - the 32x32 module icons (`Icon` enum). Nothing in the GUI draws these yet.

Keep new PNGs white with straight (non-premultiplied) alpha and no black matte under transparent pixels.

## HUD editor

Open it from the **Client** category (HUD Editor) or the main menu (MISC > HUD Editor). The click GUI no longer moves HUD elements.

* Drag elements; they snap to screen edges, the center and each other (guide lines show where). Hold **Shift** to drag without snapping.
* Arrow keys nudge the selected element (**Shift** = 10). **R** resets it, **G** toggles a grid, **L** toggles the element list.
* The element list switches any HUD element on or off.
* Positions are saved *anchored* (left/center/right and top/center/bottom + offset), so an element placed on the right edge stays there when the window or GUI scale changes. Older configs with absolute positions still load.

## Profiles

Open from the Client category (Profiles) or MISC > Profiles.

* Create (named), Load, Save (overwrite), Rename, Duplicate, Delete. Double-click a profile to load it.
* The active profile is marked, with an UNSAVED badge when your settings differ from it. Optional **Auto-save** writes changes to the active profile.
* **Copy** puts a profile (or your current settings) on the clipboard as JSON, **Paste** imports it as a new profile.
* Loading a profile first resets everything to defaults, so the result is exactly what the profile contains.

## Watermark and module list

Both use the new large title font (`font/ui_title_<scale>.json`) and the client logo. The version number is gone.
HUD text shadow now defaults to off for new configs (the shadow of a scaled font looks like a dark outline).

## Readable text on bright accents (Central GUI)

Opened module cards are filled with the accent color. For bright accents (White, Yellow, Green, Cyan, Orange, Pink) the card's name, summary, key chip, dots, icon and switch knob turn dark (`Theme.onAccent()` / `Theme.isLight`); on dark accents they stay white. The same helper is used by the Frames GUI and the profile/HUD-editor screens.

## Icon set

All icons come from `textures.zip`, including the Central navigation icons: Profiles = `newprofiles`, HUD Editor = `newedit`, Reload = `newsync`, Close = `newclose` (Home keeps the house icon, the zip has no equivalent, and the logo is unchanged). Every PNG in `gui/ui` and `gui/icons` has plain white (or dim gray) RGB under its transparent pixels, so there is no dark fringe when the GUI scale filters them.
