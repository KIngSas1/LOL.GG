package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.module.Module;
import dev.stargg.module.client.HudEditorModule;
import dev.stargg.module.hud.HudModule;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The HUD editor: a separate screen (opened from the Client category or the main menu) where HUD elements are
 * dragged around, snapped to the screen edges, the center and each other, nudged with the arrow keys and switched
 * on or off from a list. The click GUI itself no longer moves HUD elements.
 */
public final class HudEditorScreen extends Screen {

    private static final int SNAP_DISTANCE = 5;
    private static final int EDGE_MARGIN = 4;
    private static final int GRID = 8;
    private static final int STICK = 2;

    private static final int BUTTON_H = 18;
    private static final int TOOLBAR_PAD = 5;
    private static final int TOOLBAR_GAP = 4;

    private static final int LIST_W = 128;
    private static final int LIST_HEADER = 22;
    private static final int LIST_ROW = 18;

    private record Btn(int x, int y, int w, boolean enabled, Runnable action) {
    }

    /** Buttons of the last finished frame (hit testing) and of the frame being drawn. */
    private final List<Btn> buttons = new ArrayList<>();
    private final List<Btn> pending = new ArrayList<>();

    private HudModule selected;
    private HudModule dragging;
    private int dragOffsetX;
    private int dragOffsetY;
    private int guideX = -1;
    private int guideY = -1;

    private boolean snap = true;
    private boolean grid;
    private boolean listOpen = true;
    private int listX = 8;
    private int listY = 36;
    private boolean draggingList;
    private int listDragX;
    private int listDragY;

    private String status = "";
    private long statusUntil;
    private long confirmResetUntil;

    public HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static List<HudModule> hudModules() {
        List<HudModule> list = new ArrayList<>();
        for (Module module : StarGG.modules().all()) {
            if (module instanceof HudModule hud) {
                list.add(hud);
            }
        }
        return list;
    }

    private static boolean visible(HudModule hud) {
        return hud.isEnabled() && hud.getWidth() > 0;
    }

    private void flash(String message) {
        status = message;
        statusUntil = System.currentTimeMillis() + 2200;
    }

    // --------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        pending.clear();
        boolean inWorld = MinecraftClient.getInstance().world != null;

        if (inWorld) {
            if (grid) {
                renderGrid(context);
            }
            renderElements(context, mouseX, mouseY);
            renderGuides(context);
            if (listOpen) {
                renderList(context, mouseX, mouseY);
            }
        } else {
            String message = "Join a world to edit your HUD";
            Ui.textCentered(context, message, 0, height / 2 - 20, width, 12, Theme.TEXT);
        }
        renderToolbar(context, mouseX, mouseY, inWorld);
        renderStatus(context);
        buttons.clear();
        buttons.addAll(pending);
    }

    private void renderGrid(DrawContext context) {
        int line = 0x18FFFFFF;
        for (int gx = GRID; gx < width; gx += GRID) {
            Draw.rect(context, gx, 0, 1, height, line);
        }
        for (int gy = GRID; gy < height; gy += GRID) {
            Draw.rect(context, 0, gy, width, 1, line);
        }
    }

    private void renderElements(DrawContext context, int mouseX, int mouseY) {
        HudModule hovered = dragging == null && !overUi(mouseX, mouseY) ? pick(mouseX, mouseY) : null;
        for (HudModule hud : hudModules()) {
            if (!visible(hud)) {
                continue;
            }
            boolean isSelected = hud == selected;
            boolean isHovered = hud == hovered || hud == dragging;
            int alpha = isSelected ? 0xFF : (isHovered ? 0xC0 : 0x55);
            int color = Draw.withAlpha(Theme.accent(), alpha);
            if (isSelected || isHovered) {
                Draw.rect(context, hud.getX(), hud.getY(), hud.getWidth(), hud.getHeight(), Draw.withAlpha(Theme.accent(), isSelected ? 0x26 : 0x16));
            }
            Draw.outline(context, hud.getX(), hud.getY(), hud.getWidth(), hud.getHeight(), color);
            if (isSelected) {
                int s = 3;
                int x2 = hud.getX() + hud.getWidth() - s;
                int y2 = hud.getY() + hud.getHeight() - s;
                Draw.rect(context, hud.getX() - 1, hud.getY() - 1, s, s, Theme.accent());
                Draw.rect(context, x2 + 1, hud.getY() - 1, s, s, Theme.accent());
                Draw.rect(context, hud.getX() - 1, y2 + 1, s, s, Theme.accent());
                Draw.rect(context, x2 + 1, y2 + 1, s, s, Theme.accent());
            }
            if (isSelected || isHovered) {
                renderLabel(context, hud, isSelected);
            }
        }
    }

    private void renderLabel(DrawContext context, HudModule hud, boolean withPosition) {
        String text = withPosition ? hud.getName() + "   " + hud.getX() + ", " + hud.getY() : hud.getName();
        int w = Ui.width(text) + 10;
        int h = 14;
        int x = Math.max(2, Math.min(hud.getX(), width - w - 2));
        int y = hud.getY() - h - 3;
        if (y < 2) {
            y = hud.getY() + hud.getHeight() + 3;
        }
        Ui.roundRect(context, x, y, w, h, 3, Theme.bg(Theme.HEADER));
        Ui.textMiddle(context, text, x + 5, y, h, withPosition ? Theme.TEXT_BRIGHT : Theme.TEXT);
    }

    private void renderGuides(DrawContext context) {
        if (dragging == null) {
            return;
        }
        int color = Draw.withAlpha(Theme.accent(), 0xB0);
        if (guideX >= 0) {
            Draw.rect(context, guideX, 0, 1, height, color);
        }
        if (guideY >= 0) {
            Draw.rect(context, 0, guideY, width, 1, color);
        }
    }

    // ---- element list

    private int listHeight(int rows) {
        return LIST_HEADER + rows * LIST_ROW + 4;
    }

    private void renderList(DrawContext context, int mouseX, int mouseY) {
        List<HudModule> list = hudModules();
        int h = listHeight(list.size());
        listX = Math.max(0, Math.min(listX, width - LIST_W));
        listY = Math.max(0, Math.min(listY, height - h));

        Ui.roundRect(context, listX, listY, LIST_W, h, 4, Theme.bg(Theme.ROW));
        Ui.roundRect(context, listX, listY, LIST_W, LIST_HEADER, 4, Theme.bg(Theme.HEADER));
        Draw.rect(context, listX, listY + LIST_HEADER - 4, LIST_W, 4, Theme.bg(Theme.HEADER));
        Ui.icon(context, Ui.Tex.CAT_HUD, listX + Theme.PADDING, listY + (LIST_HEADER - 10) / 2, Theme.accent());
        Ui.textBold(context, "HUD Elements", listX + Theme.PADDING + 15, Ui.middleY(listY, LIST_HEADER), Theme.TEXT_BRIGHT);

        int rowY = listY + LIST_HEADER;
        for (HudModule hud : list) {
            boolean hovered = Draw.inside(mouseX, mouseY, listX, rowY, LIST_W, LIST_ROW);
            boolean on = hud.isEnabled();
            if (hud == selected) {
                Draw.rect(context, listX + 2, rowY, LIST_W - 4, LIST_ROW, Draw.withAlpha(Theme.accent(), 0x30));
            } else if (hovered) {
                Draw.rect(context, listX + 2, rowY, LIST_W - 4, LIST_ROW, Theme.bg(Theme.ROW_HOVER));
            }
            String name = Ui.trim(hud.getName(), LIST_W - Theme.PADDING * 2 - 26);
            Ui.textMiddle(context, name, listX + Theme.PADDING, rowY, LIST_ROW, on ? Theme.TEXT : Theme.TEXT_FAINT);
            drawSwitch(context, listX + LIST_W - Theme.PADDING - 18, rowY + (LIST_ROW - 10) / 2, on);
            rowY += LIST_ROW;
        }
    }

    private static void drawSwitch(DrawContext context, int x, int y, boolean on) {
        Ui.roundRect(context, x, y, 18, 10, 5, on ? Theme.accent() : Theme.TRACK);
        int knobX = on ? x + 10 : x + 2;
        Ui.roundRect(context, knobX, y + 2, 6, 6, 3, on ? Theme.onAccent() : Theme.TEXT_DIM);
    }

    // ---- toolbar

    private void renderToolbar(DrawContext context, int mouseX, int mouseY, boolean inWorld) {
        boolean resetArmed = System.currentTimeMillis() < confirmResetUntil;
        String[] labels = {"Snap", "Grid", "List", "Reset", resetArmed ? "Sure?" : "Reset all", "Done"};
        boolean[] active = {snap, grid, listOpen, false, resetArmed, false};
        boolean[] enabled = {inWorld, inWorld, inWorld, inWorld && selected != null, inWorld, true};
        Runnable[] actions = {
                () -> {
                    snap = !snap;
                    flash(snap ? "Snapping on" : "Snapping off");
                },
                () -> {
                    grid = !grid;
                    flash(grid ? "Grid on" : "Grid off");
                },
                () -> listOpen = !listOpen,
                this::resetSelected,
                this::resetAll,
                this::close
        };

        int total = TOOLBAR_PAD * 2 - TOOLBAR_GAP;
        int[] widths = new int[labels.length];
        for (int i = 0; i < labels.length; i++) {
            widths[i] = Ui.width(labels[i]) + 16;
            total += widths[i] + TOOLBAR_GAP;
        }
        int barH = BUTTON_H + TOOLBAR_PAD * 2;
        int barX = (width - total) / 2;
        int barY = height - barH - 8;
        Ui.roundRect(context, barX, barY, total, barH, 5, Theme.bg(Theme.HEADER));

        int cursor = barX + TOOLBAR_PAD;
        for (int i = 0; i < labels.length; i++) {
            int by = barY + TOOLBAR_PAD;
            boolean hovered = enabled[i] && Draw.inside(mouseX, mouseY, cursor, by, widths[i], BUTTON_H);
            int fill = active[i] ? Theme.accent() : (hovered ? Theme.ROW_HOVER : Theme.BADGE);
            int text = !enabled[i] ? Theme.TEXT_FAINT : (active[i] ? Theme.onAccent() : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT));
            Ui.roundRect(context, cursor, by, widths[i], BUTTON_H, 3, fill);
            Ui.textCentered(context, labels[i], cursor, by, widths[i], BUTTON_H, text);
            pending.add(new Btn(cursor, by, widths[i], enabled[i], actions[i]));
            cursor += widths[i] + TOOLBAR_GAP;
        }

        String hint = "Drag to move  -  Arrows nudge (Shift x10)  -  Hold Shift: no snap  -  R reset  -  G grid";
        Ui.textCentered(context, Ui.trim(hint, width - 16), 0, barY - 14, width, 12, Theme.TEXT_FAINT);
    }

    private void renderStatus(DrawContext context) {
        if (System.currentTimeMillis() > statusUntil || status.isEmpty()) {
            return;
        }
        int w = Ui.width(status) + 16;
        int x = (width - w) / 2;
        Ui.roundRect(context, x, 8, w, 18, 4, Theme.bg(Theme.HEADER));
        Ui.textCentered(context, status, x, 8, w, 18, Theme.TEXT_BRIGHT);
    }

    // ----------------------------------------------------------------- actions

    private void resetSelected() {
        if (selected != null) {
            selected.resetPosition();
            flash(selected.getName() + " reset");
        }
    }

    private void resetAll() {
        long now = System.currentTimeMillis();
        if (now > confirmResetUntil) {
            confirmResetUntil = now + 3000;
            return;
        }
        confirmResetUntil = 0;
        for (HudModule hud : hudModules()) {
            hud.resetPosition();
        }
        flash("All HUD positions reset");
    }

    // ------------------------------------------------------------------- input

    private boolean overUi(double mouseX, double mouseY) {
        for (Btn button : buttons) {
            if (Draw.inside(mouseX, mouseY, button.x(), button.y(), button.w(), BUTTON_H)) {
                return true;
            }
        }
        return listOpen && Draw.inside(mouseX, mouseY, listX, listY, LIST_W, listHeight(hudModules().size()));
    }

    /** The smallest visible element under the cursor, so small elements inside big ones can still be grabbed. */
    private HudModule pick(double mouseX, double mouseY) {
        HudModule best = null;
        for (HudModule hud : hudModules()) {
            if (visible(hud) && hud.contains(mouseX, mouseY)
                    && (best == null || hud.getWidth() * hud.getHeight() < best.getWidth() * best.getHeight())) {
                best = hud;
            }
        }
        return best;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        for (Btn btn : buttons) {
            if (Draw.inside(mouseX, mouseY, btn.x(), btn.y(), btn.w(), BUTTON_H)) {
                if (button == 0 && btn.enabled()) {
                    btn.action().run();
                }
                return true;
            }
        }

        if (listOpen && Draw.inside(mouseX, mouseY, listX, listY, LIST_W, listHeight(hudModules().size()))) {
            if (button == 0) {
                clickList(mouseX, mouseY);
            }
            return true;
        }

        if (MinecraftClient.getInstance().world == null) {
            return super.mouseClicked(click, doubled);
        }
        HudModule hit = pick(mouseX, mouseY);
        selected = hit;
        if (hit != null && button == 0) {
            dragging = hit;
            dragOffsetX = (int) mouseX - hit.getX();
            dragOffsetY = (int) mouseY - hit.getY();
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    private void clickList(double mouseX, double mouseY) {
        int relative = (int) mouseY - listY;
        if (relative < LIST_HEADER) {
            draggingList = true;
            listDragX = (int) mouseX - listX;
            listDragY = (int) mouseY - listY;
            return;
        }
        int index = (relative - LIST_HEADER) / LIST_ROW;
        List<HudModule> list = hudModules();
        if (index < 0 || index >= list.size()) {
            return;
        }
        HudModule hud = list.get(index);
        boolean onSwitch = mouseX >= listX + LIST_W - Theme.PADDING - 22;
        if (onSwitch || !hud.isEnabled()) {
            hud.toggle();
            flash(hud.getName() + (hud.isEnabled() ? " on" : " off"));
            selected = hud.isEnabled() ? hud : (selected == hud ? null : selected);
        } else {
            selected = hud;
        }
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (draggingList) {
            listX = (int) click.x() - listDragX;
            listY = (int) click.y() - listDragY;
            return true;
        }
        if (dragging != null) {
            moveWithSnap(dragging, (int) click.x() - dragOffsetX, (int) click.y() - dragOffsetY);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        draggingList = false;
        guideX = -1;
        guideY = -1;
        return super.mouseReleased(click);
    }

    private static boolean shiftDown() {
        long window = MinecraftClient.getInstance().getWindow().getHandle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    /** Moves the element, pulling it onto screen edges / center lines / other elements when it comes close. */
    private void moveWithSnap(HudModule hud, int rawX, int rawY) {
        int w = hud.getWidth();
        int h = hud.getHeight();
        int x = rawX;
        int y = rawY;
        guideX = -1;
        guideY = -1;

        if (snap && !shiftDown()) {
            List<Integer> targetsX = new ArrayList<>();
            List<Integer> targetsY = new ArrayList<>();
            targetsX.add(0);
            targetsX.add(EDGE_MARGIN);
            targetsX.add(width / 2);
            targetsX.add(width - EDGE_MARGIN);
            targetsX.add(width);
            targetsY.add(0);
            targetsY.add(EDGE_MARGIN);
            targetsY.add(height / 2);
            targetsY.add(height - EDGE_MARGIN);
            targetsY.add(height);
            for (HudModule other : hudModules()) {
                if (other == hud || !visible(other)) {
                    continue;
                }
                targetsX.add(other.getX());
                targetsX.add(other.getX() + other.getWidth() / 2);
                targetsX.add(other.getX() + other.getWidth());
                targetsX.add(other.getX() - STICK);
                targetsX.add(other.getX() + other.getWidth() + STICK);
                targetsY.add(other.getY());
                targetsY.add(other.getY() + other.getHeight() / 2);
                targetsY.add(other.getY() + other.getHeight());
                targetsY.add(other.getY() - STICK);
                targetsY.add(other.getY() + other.getHeight() + STICK);
            }
            int[] edgesX = {0, w / 2, w};
            int[] edgesY = {0, h / 2, h};

            int[] snapX = nearest(rawX, edgesX, targetsX);
            if (snapX != null) {
                x = rawX + snapX[0];
                guideX = snapX[1];
            } else if (grid) {
                x = Math.round(rawX / (float) GRID) * GRID;
            }
            int[] snapY = nearest(rawY, edgesY, targetsY);
            if (snapY != null) {
                y = rawY + snapY[0];
                guideY = snapY[1];
            } else if (grid) {
                y = Math.round(rawY / (float) GRID) * GRID;
            }
        }
        hud.moveTo(x, y, width, height);
    }

    /**
     * Finds the smallest shift that puts one of the element's edges onto one of the targets.
     *
     * @return {shift, target line} or null if nothing is within {@link #SNAP_DISTANCE}
     */
    private static int[] nearest(int position, int[] edges, List<Integer> targets) {
        int[] best = null;
        for (int edge : edges) {
            for (int target : targets) {
                int delta = target - (position + edge);
                if (Math.abs(delta) <= SNAP_DISTANCE && (best == null || Math.abs(delta) < Math.abs(best[0]))) {
                    best = new int[]{delta, target};
                }
            }
        }
        return best;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_G) {
            grid = !grid;
            flash(grid ? "Grid on" : "Grid off");
            return true;
        }
        if (key == GLFW.GLFW_KEY_L) {
            listOpen = !listOpen;
            return true;
        }
        if (selected != null && visible(selected)) {
            int step = shiftDown() ? 10 : 1;
            int dx = 0;
            int dy = 0;
            switch (key) {
                case GLFW.GLFW_KEY_LEFT -> dx = -step;
                case GLFW.GLFW_KEY_RIGHT -> dx = step;
                case GLFW.GLFW_KEY_UP -> dy = -step;
                case GLFW.GLFW_KEY_DOWN -> dy = step;
                case GLFW.GLFW_KEY_R -> {
                    resetSelected();
                    return true;
                }
                default -> {
                    return super.keyPressed(input);
                }
            }
            selected.moveTo(selected.getX() + dx, selected.getY() + dy, width, height);
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void removed() {
        dragging = null;
        draggingList = false;
        StarGG.modules().get(HudEditorModule.class).setEnabled(false);
        StarGG.config().save();
    }
}
