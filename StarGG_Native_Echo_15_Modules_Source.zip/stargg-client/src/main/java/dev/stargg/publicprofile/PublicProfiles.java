package dev.stargg.publicprofile;

/** Holds the active {@link PublicProfileService}. */
public final class PublicProfiles {

    private static PublicProfileService service;

    private PublicProfiles() {
    }

    public static synchronized PublicProfileService service() {
        if (service == null) {
            service = new LocalPublicProfileService();
        }
        return service;
    }

    /** Installs another backend (for example one that talks to your own server). */
    public static synchronized void setService(PublicProfileService replacement) {
        service = replacement;
    }
}
