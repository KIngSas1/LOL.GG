package dev.stargg.module.hud;

import dev.stargg.StarGG;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Icon;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Shows the names of all enabled modules (the classic "array list"). */
public final class ModuleList extends TextHudModule {

    private final BooleanSetting showHud = add(new BooleanSetting("Show HUD modules", false));
    private final ModeSetting sort = add(new ModeSetting("Sort", "Length", "Length", "Alphabetical"));

    public ModuleList() {
        super("Module List", "Lists the enabled modules", -4, 4);
        icon(Icon.LIST);
    }

    @Override
    protected boolean alignRight() {
        return true;
    }

    @Override
    protected List<String> buildLines() {
        List<String> names = new ArrayList<>();
        for (Module module : StarGG.modules().all()) {
            boolean hidden = module == this
                    || module.getCategory() == Category.CLIENT
                    || (module.getCategory() == Category.HUD && !showHud.on());
            if (module.isEnabled() && !hidden) {
                names.add(module.getName());
            }
        }
        if (sort.is("Length")) {
            names.sort(Comparator.comparingInt(Draw::width).reversed());
        } else {
            names.sort(String::compareToIgnoreCase);
        }
        return names;
    }
}
