package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.ColorSetting;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

final class ColorWidget extends SettingWidget {

    private static final int GAP = 2;

    private final ColorSetting setting;

    ColorWidget(ColorSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 26;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    private int swatchSize() {
        int count = ColorSetting.PRESETS.size();
        return (w - Theme.PADDING * 2 - GAP * (count - 1)) / count;
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT_DIM);
        rightText(context, setting.get(), Theme.TEXT);

        int size = swatchSize();
        int sx = x + Theme.PADDING;
        int sy = y + 14;
        List<ColorSetting.Preset> presets = ColorSetting.PRESETS;
        for (ColorSetting.Preset preset : presets) {
            Draw.rounded(context, sx, sy, size, size, 2, preset.argb());
            if (preset.name().equalsIgnoreCase(setting.get())) {
                Draw.outline(context, sx - 1, sy - 1, size + 2, size + 2, 0xFFFFFFFF);
            }
            sx += size + GAP;
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return;
        }
        int size = swatchSize();
        int index = (int) ((mouseX - (x + Theme.PADDING)) / (size + GAP));
        if (mouseY >= y + 13 && index >= 0 && index < ColorSetting.PRESETS.size()) {
            setting.set(ColorSetting.PRESETS.get(index).name());
        }
    }
}
