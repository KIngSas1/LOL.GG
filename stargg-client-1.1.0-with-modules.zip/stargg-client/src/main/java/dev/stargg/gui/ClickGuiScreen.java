package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.gui.widget.SettingWidget;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.module.client.ClickGuiModule;
import dev.stargg.module.hud.HudModule;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The click GUI: a main menu panel that opens one panel per category, a search bar, and
 * drag-and-drop editing of the enabled HUD elements while the screen is open.
 *
 * <p>All Minecraft input-event types ({@link Click}, {@link KeyInput}, {@link CharInput}) are confined
 * to this class; the panels and widgets only see plain coordinates, button numbers and GLFW key codes.
 */
public final class ClickGuiScreen extends Screen {

    private static final int PANEL_SPACING = 8;
    private static final int SEARCH_WIDTH = 150;
    private static final int SEARCH_HEIGHT = 22;
    private static final int SEARCH_MAX_LENGTH = 24;

    private final List<Panel> categoryPanels = new ArrayList<>();
    private final List<GuiPanel> panels = new ArrayList<>();
    private HudModule draggedHud;
    private int dragOffsetX;
    private int dragOffsetY;
    private int scroll;
    private boolean scrollingBackground;

    private String query = "";
    private boolean searchFocused;

    public ClickGuiScreen() {
        super(Text.literal("Click GUI"));
        int x = 10;
        for (Category category : Category.values()) {
            x += Theme.PANEL_WIDTH + PANEL_SPACING;
            categoryPanels.add(new Panel(category, x, 14));
        }
        panels.addAll(categoryPanels);
        panels.add(new MainPanel(categoryPanels, 10, 14, this::toggleProfileSettings));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    /**
     * Gear button / Profiles row: shows the Client panel with the Click GUI settings (theme, profiles) open;
     * pressing it again closes them (and the panel) again.
     */
    private void toggleProfileSettings() {
        for (Panel panel : categoryPanels) {
            if (panel.category() != Category.CLIENT) {
                continue;
            }
            if (panel.isShown() && panel.isExpanded(ClickGuiModule.class)) {
                panel.setExpanded(ClickGuiModule.class, false);
                panel.setShown(false);
            } else {
                query = "";
                applyFilter();
                panel.setShown(true);
                panel.setOpen(true);
                panel.setExpanded(ClickGuiModule.class, true);
            }
        }
    }

    // --------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        setScroll(scroll);
        renderHudOutlines(context);

        for (GuiPanel panel : panels) {
            panel.render(context, mouseX, mouseY);
        }
        renderSearchBar(context, mouseX, mouseY);
        renderTooltip(context, mouseX, mouseY);
    }

    // ---- search bar

    private int searchX() {
        return (width - SEARCH_WIDTH) / 2;
    }

    private boolean overSearch(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, searchX(), 8, SEARCH_WIDTH, SEARCH_HEIGHT);
    }

    private void renderSearchBar(DrawContext context, int mouseX, int mouseY) {
        int x = searchX();
        int y = 8;
        Ui.roundRect(context, x, y, SEARCH_WIDTH, SEARCH_HEIGHT, 3, Theme.bg(Theme.HEADER));
        Ui.icon(context, Ui.Tex.LOGO, x + 8, y + (SEARCH_HEIGHT - Ui.Tex.LOGO.size) / 2, Theme.accent());
        Draw.rect(context, x + 26, y + 6, 1, SEARCH_HEIGHT - 12, searchFocused ? Theme.accent() : Theme.TEXT_FAINT);

        String shown = Ui.trim(query, SEARCH_WIDTH - 62);
        Ui.textMiddle(context, shown, x + 32, y, SEARCH_HEIGHT, Theme.TEXT_BRIGHT);
        if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
            int caretX = x + 32 + Ui.width(shown) + 1;
            Draw.rect(context, caretX, y + 6, 1, SEARCH_HEIGHT - 12, Theme.TEXT_BRIGHT);
        }
        boolean hover = overSearch(mouseX, mouseY);
        Ui.icon(context, Ui.Tex.SEARCH, x + SEARCH_WIDTH - 20, y + (SEARCH_HEIGHT - Ui.Tex.SEARCH.size) / 2, hover || searchFocused ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
    }

    private void applyFilter() {
        categoryPanels.forEach(panel -> panel.setFilter(query));
        scroll = 0;
    }

    /** Scrolls all panels together; clamped so the lowest panel can just be reached. */
    private void setScroll(int value) {
        int lowest = 0;
        for (GuiPanel panel : panels) {
            lowest = Math.max(lowest, panel.bottom());
        }
        scroll = Math.max(0, Math.min(value, Math.max(0, lowest + 24 - height)));
        panels.forEach(panel -> panel.setScroll(scroll));
    }

    private void renderHudOutlines(DrawContext context) {
        if (MinecraftClient.getInstance().world == null) {
            return; // on the title screen there are no HUD elements to place
        }
        for (Module module : StarGG.modules().all()) {
            if (module instanceof HudModule hud && hud.isEnabled()) {
                int color = Draw.withAlpha(Theme.accent(), hud == draggedHud ? 0xFF : 0x90);
                Draw.outline(context, hud.getX(), hud.getY(), hud.getWidth(), hud.getHeight(), color);
                Ui.text(context, hud.getName(), hud.getX(), hud.getY() - 11, color);
            }
        }
    }

    private void renderTooltip(DrawContext context, int mouseX, int mouseY) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            Module hovered = panels.get(i).hoveredModule(mouseX, mouseY);
            if (hovered != null) {
                String text = hovered.getDescription();
                int w = Ui.width(text) + 12;
                int x = Math.min(mouseX + 10, width - w - 2);
                int y = Math.min(mouseY + 10, height - 20);
                Ui.roundRect(context, x, y, w, 16, 3, 0xF0151515);
                Ui.textMiddle(context, text, x + 6, y, 16, Theme.TEXT);
                return;
            }
        }
    }

    // ------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        SettingWidget.releaseFocus();

        if (button == 0 && overSearch(mouseX, mouseY)) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        // Topmost panel first; a clicked panel moves to the front.
        for (int i = panels.size() - 1; i >= 0; i--) {
            GuiPanel panel = panels.get(i);
            if (panel.mouseClicked(mouseX, mouseY, button)) {
                panels.remove(i);
                panels.add(panel);
                return true;
            }
        }

        if (button == 0) {
            for (Module module : StarGG.modules().all()) {
                if (module instanceof HudModule hud && hud.isEnabled() && hud.contains(mouseX, mouseY)) {
                    draggedHud = hud;
                    dragOffsetX = (int) mouseX - hud.getX();
                    dragOffsetY = (int) mouseY - hud.getY();
                    return true;
                }
            }
            scrollingBackground = true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (draggedHud != null) {
            draggedHud.moveTo((int) click.x() - dragOffsetX, (int) click.y() - dragOffsetY);
            return true;
        }
        if (scrollingBackground) {
            setScroll(scroll - (int) offsetY);
            return true;
        }
        for (GuiPanel panel : panels) {
            panel.mouseDragged(click.x(), click.y());
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        draggedHud = null;
        scrollingBackground = false;
        panels.forEach(GuiPanel::mouseReleased);
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        setScroll(scroll - (int) (verticalAmount * 20));
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (!searchFocused) {
            return super.charTyped(input);
        }
        int codePoint = input.codepoint();
        if (!Character.isISOControl(codePoint) && query.length() < SEARCH_MAX_LENGTH) {
            query += new String(Character.toChars(codePoint));
            applyFilter();
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        SettingWidget focused = SettingWidget.getFocused();
        if (focused != null && focused.keyPressed(key)) {
            return true;
        }

        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) {
                    query = query.substring(0, query.length() - 1);
                    applyFilter();
                }
            } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                query = "";
                applyFilter();
                searchFocused = false;
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
            }
            return true; // typing must not trigger the GUI's close key
        }

        ClickGuiModule module = StarGG.modules().get(ClickGuiModule.class);
        if (key == GLFW.GLFW_KEY_ESCAPE || (module.getKey() > 0 && key == module.getKey())) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void removed() {
        SettingWidget.releaseFocus();
        draggedHud = null;
        searchFocused = false;
        StarGG.modules().get(ClickGuiModule.class).setEnabled(false);
        StarGG.config().save();
    }
}
