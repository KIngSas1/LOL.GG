package dev.stargg.module.client;

import dev.stargg.StarGG;
import dev.stargg.config.ConfigManager;
import dev.stargg.gui.ClickGuiScreen;
import dev.stargg.module.BindMode;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.ActionSetting;
import dev.stargg.setting.ColorSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Opens the click GUI and holds the client-wide settings (theme and config profiles). */
public final class ClickGuiModule extends Module {

    private static ClickGuiModule instance;

    private final ColorSetting accentColor = add(new ColorSetting("Accent", "Teal"));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 92, 50, 100, 1));

    private final ModeSetting profile = add(new ModeSetting("Profile", "default", "default").transientValue());
    private final ActionSetting loadProfile = add(new ActionSetting("Load profile", this::loadSelectedProfile));
    private final ActionSetting saveProfile = add(new ActionSetting("Save profile", this::saveSelectedProfile));
    private final ActionSetting newProfile = add(new ActionSetting("New profile", this::createProfile));

    private ClickGuiScreen screen;

    public ClickGuiModule() {
        super("Click GUI", "Opens this menu and changes its look", Category.CLIENT);
        icon(Icon.CLICK_GUI);
        defaultBind(GLFW.GLFW_KEY_RIGHT_SHIFT, BindMode.TOGGLE);
        instance = this;
    }

    // ------------------------------------------------------------ static look-up

    public static int accent() {
        return instance == null ? 0xFF0E9E85 : instance.accentColor.argb();
    }

    public static int panelAlpha() {
        return instance == null ? 235 : (int) Math.round(instance.opacity.getDouble() / 100.0 * 255.0);
    }

    /** Name of the profile currently selected in the settings (shown in the GUI). */
    public static String profileName() {
        return instance == null ? "default" : instance.profile.get();
    }

    // -------------------------------------------------------------- behaviour

    @Override
    public boolean isToggleable() {
        return false;
    }

    @Override
    protected boolean savesEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        refreshProfiles();
        if (screen == null) {
            screen = new ClickGuiScreen();
        }
        if (mc.currentScreen != screen) {
            mc.setScreen(screen);
        }
    }

    // ---------------------------------------------------------------- profiles

    private void refreshProfiles() {
        profile.setModes(StarGG.config().listProfiles());
    }

    private void loadSelectedProfile() {
        StarGG.config().loadProfile(profile.get());
    }

    private void saveSelectedProfile() {
        StarGG.config().saveProfile(profile.get());
        refreshProfiles();
    }

    private void createProfile() {
        ConfigManager config = StarGG.config();
        List<String> existing = config.listProfiles();
        int number = 1;
        while (existing.contains("profile-" + number)) {
            number++;
        }
        String name = "profile-" + number;
        config.saveProfile(name);
        refreshProfiles();
        profile.set(name);
    }
}
