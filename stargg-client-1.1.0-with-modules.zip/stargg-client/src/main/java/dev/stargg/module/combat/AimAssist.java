package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Smoothly turns the view toward the best visible living target. */
public final class AimAssist extends Module {

    private final BooleanSetting requireMouseDown = add(new BooleanSetting("Require mouse down", true));
    private final BooleanSetting aimVertically = add(new BooleanSetting("Aim vertically", false));
    private final BooleanSetting playersOnly = add(new BooleanSetting("Players only", true));
    private final NumberSetting horizontalSpeed = add(new NumberSetting("Horizontal speed", 5.0, 1.0, 10.0, 0.5));
    private final NumberSetting verticalSpeed = add(new NumberSetting("Vertical speed", 3.0, 1.0, 10.0, 0.5));
    private final NumberSetting maxAngle = add(new NumberSetting("Max angle", 70.0, 5.0, 180.0, 1.0));
    private final NumberSetting distance = add(new NumberSetting("Distance", 5.0, 1.0, 8.0, 0.5));

    public AimAssist() {
        super("Aim Assist", "Smoothly aims toward the closest valid target", Category.COMBAT);
        icon(Icon.COMBAT);
        verticalSpeed.showWhen(aimVertically::on);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            return;
        }
        if (requireMouseDown.on() && !mc.options.attackKey.isPressed()) {
            return;
        }

        LivingEntity target = findTarget();
        if (target == null) {
            return;
        }

        Vec3d difference = target.getEyePos().subtract(mc.player.getEyePos());
        double horizontalDistance = Math.sqrt(difference.x * difference.x + difference.z * difference.z);
        float targetYaw = (float) (Math.atan2(difference.z, difference.x) * (180.0 / Math.PI)) - 90.0F;
        float targetPitch = (float) (-(Math.atan2(difference.y, horizontalDistance) * (180.0 / Math.PI)));

        float yawDelta = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDelta = targetPitch - mc.player.getPitch();
        mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yawDelta, -horizontalSpeed.getFloat(), horizontalSpeed.getFloat()));
        if (aimVertically.on()) {
            mc.player.setPitch(mc.player.getPitch() + MathHelper.clamp(pitchDelta, -verticalSpeed.getFloat(), verticalSpeed.getFloat()));
        }
    }

    private LivingEntity findTarget() {
        LivingEntity best = null;
        double bestAngle = Double.MAX_VALUE;
        double range = distance.getDouble();
        for (Entity entity : mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(range), candidate -> candidate instanceof LivingEntity && candidate.isAlive())) {
            if (!(entity instanceof LivingEntity living) || living == mc.player || !living.isAlive()) {
                continue;
            }
            if (playersOnly.on() && !(living instanceof PlayerEntity)) {
                continue;
            }
            if (mc.player.distanceTo(living) > range || !mc.player.canSee(living)) {
                continue;
            }

            Vec3d difference = living.getEyePos().subtract(mc.player.getEyePos());
            double horizontalDistance = Math.sqrt(difference.x * difference.x + difference.z * difference.z);
            float targetYaw = (float) (Math.atan2(difference.z, difference.x) * (180.0 / Math.PI)) - 90.0F;
            float targetPitch = (float) (-(Math.atan2(difference.y, horizontalDistance) * (180.0 / Math.PI)));
            double yaw = Math.abs(MathHelper.wrapDegrees(targetYaw - mc.player.getYaw()));
            double pitch = aimVertically.on() ? Math.abs(targetPitch - mc.player.getPitch()) : 0.0;
            double angle = Math.sqrt(yaw * yaw + pitch * pitch);
            if (angle <= maxAngle.getDouble() && angle < bestAngle) {
                bestAngle = angle;
                best = living;
            }
        }
        return best;
    }
}
