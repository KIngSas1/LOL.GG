package dev.stargg.gui;

import dev.stargg.module.Module;
import net.minecraft.client.gui.DrawContext;

/** Anything draggable the click GUI shows: the main menu panel and the category panels. */
interface GuiPanel {

    void render(DrawContext context, int mouseX, int mouseY);

    /** @return true if the click was inside this panel (so nothing below it gets it). */
    boolean mouseClicked(double mouseX, double mouseY, int button);

    void mouseDragged(double mouseX, double mouseY);

    void mouseReleased();

    void setScroll(int scroll);

    /** Bottom edge in unscrolled coordinates (0 if hidden). */
    int bottom();

    default Module hoveredModule(double mouseX, double mouseY) {
        return null;
    }
}
