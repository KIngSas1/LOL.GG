package dev.stargg.mixin;

import dev.stargg.util.SilentRotationManager;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Applies module rotations to outgoing movement packets without moving the local camera. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {

    @Unique private float stargg$cameraYaw;
    @Unique private float stargg$cameraPitch;
    @Unique private boolean stargg$rotationApplied;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"), require = 0)
    private void stargg$applySilentRotation(CallbackInfo ci) {
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        stargg$rotationApplied = false;
        if (SilentRotationManager.isActive()) {
            stargg$cameraYaw = self.getYaw();
            stargg$cameraPitch = self.getPitch();
            self.setYaw(SilentRotationManager.yaw());
            self.setPitch(SilentRotationManager.pitch());
            stargg$rotationApplied = true;
        }
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"), require = 0)
    private void stargg$restoreCameraRotation(CallbackInfo ci) {
        if (stargg$rotationApplied) {
            ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
            self.setYaw(stargg$cameraYaw);
            self.setPitch(stargg$cameraPitch);
            stargg$rotationApplied = false;
        }
    }
}
