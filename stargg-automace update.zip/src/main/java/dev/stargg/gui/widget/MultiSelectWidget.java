package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

/** Compact vertical list of independently toggleable filter options. */
final class MultiSelectWidget extends SettingWidget {

    private static final int OPTION_H = 13;
    private final MultiSelectSetting setting;

    MultiSelectWidget(MultiSelectSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return LINE + setting.getOptions().size() * OPTION_H + 2;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT);

        int optionY = y + LINE;
        for (int i = 0; i < setting.getOptions().size(); i++) {
            String option = setting.getOptions().get(i);
            int cy = optionY + i * OPTION_H + 2;
            boolean selected = setting.has(option);
            boolean over = Draw.inside(mouseX, mouseY, x + Theme.PADDING, cy, w - Theme.PADDING * 2, OPTION_H);
            if (over) {
                Draw.rect(context, x + Theme.PADDING - 2, cy, w - Theme.PADDING * 2 + 4, OPTION_H, Theme.bg(Theme.SETTING_HOVER));
            }
            Ui.roundRect(context, x + Theme.PADDING, cy + 3, 7, 7, 2,
                    selected ? Theme.accent() : Theme.TRACK);
            if (selected) {
                Ui.text(context, "✓", x + Theme.PADDING + 1, cy + 1, Theme.onAccent());
            }
            Ui.textMiddle(context, Ui.trim(option, Math.max(24, w - Theme.PADDING * 2 - 13)),
                    x + Theme.PADDING + 13, cy, OPTION_H, selected ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 1) {
            setting.reset();
            return;
        }
        if (button != 0) {
            return;
        }
        if (mouseY < y + LINE + 2) {
            return;
        }
        int index = (int) ((mouseY - (y + LINE + 2)) / OPTION_H);
        if (index >= 0 && index < setting.getOptions().size()) {
            setting.toggle(setting.getOptions().get(index));
        }
    }
}
