package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.util.Draw;
import dev.legitclient.util.Ui;
import net.minecraft.client.gui.DrawContext;

/** A label with a smooth pill switch: the knob slides and the track fades to the accent color. */
final class BooleanWidget extends SettingWidget {

    private static final int PILL_W = 20;
    private static final int PILL_H = 10;
    private static final int KNOB = 8;

    private final BooleanSetting setting;
    private float animation = -1f;

    BooleanWidget(BooleanSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return LINE;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        float target = setting.on() ? 1f : 0f;
        animation = animation < 0f ? target : Theme.approach(animation, target);

        paintRow(context, hovered(mouseX, mouseY));
        int labelWidth = w - Theme.PADDING * 2 - PILL_W - 6;
        label(context, Ui.trim(setting.getName(), labelWidth), Draw.blend(Theme.TEXT, Theme.TEXT_BRIGHT, animation));

        int pillX = x + w - Theme.PADDING - PILL_W;
        int pillY = y + (LINE - PILL_H) / 2;
        Ui.roundRect(context, pillX, pillY, PILL_W, PILL_H, PILL_H / 2, Draw.blend(Theme.TRACK, Theme.accent(), animation));

        int travel = PILL_W - KNOB - 2;
        int knobX = pillX + 1 + Math.round(travel * animation);
        int knobColor = Draw.blend(0xFFFFFFFF, Theme.lightAccent() ? Theme.onAccent() : 0xFFFFFFFF, animation);
        Ui.roundRect(context, knobX, pillY + (PILL_H - KNOB) / 2, KNOB, KNOB, KNOB / 2, knobColor);
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setting.toggle();
        }
    }
}
