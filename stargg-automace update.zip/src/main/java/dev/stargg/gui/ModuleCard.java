package dev.stargg.gui;

import dev.stargg.gui.widget.SettingWidget;
import dev.stargg.module.Module;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.Setting;
import dev.stargg.util.Draw;
import dev.stargg.util.KeyNames;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;

/**
 * A module as a card of the Central GUI: icon tile, name, a short summary of its main settings, a keybind chip,
 * an on/off switch and a three-dots column that slides the full settings open.
 *
 * <p>Left click toggles the module, the dots (or right click) open the settings. The opened card is filled with
 * the accent color and lists a Favorite switch, every setting of the module and Bind / Bind mode, using the
 * same {@link SettingWidget}s as the Frames GUI.
 */
final class ModuleCard {

    static final int CARD_H = 36;
    static final int GAP = 6;

    // colors of the Central GUI cards
    static final int CARD = 0xFF19181B;
    static final int CARD_HOVER = 0xFF1F1E21;
    private static final int TILE = 0xFF212024;
    private static final int CHIP = 0xFF252428;
    private static final int RADIUS = 5;

    private static final int TILE_W = 34;
    private static final int DOTS_W = 22;
    private static final int NAME_W = 88;
    private static final int FAVORITE_H = 18;
    private static final int SWITCH_W = 20;
    private static final int SWITCH_H = 10;
    private static final int INSET = 4;
    private static final int MAX_SUMMARY_PARTS = 3;

    private final Module module;
    private final BooleanSupplier favorite;
    private final Runnable toggleFavorite;
    private final List<SettingWidget> widgets = new ArrayList<>();

    private boolean expanded;
    private float expandAnimation;
    private float enabledAnimation;
    private float hoverAnimation;

    private int x;
    private int y;
    private int w;

    ModuleCard(Module module, BooleanSupplier favorite, Runnable toggleFavorite) {
        this.module = module;
        this.favorite = favorite;
        this.toggleFavorite = toggleFavorite;
        for (Setting<?> setting : module.getSettings()) {
            widgets.add(SettingWidget.create(setting));
        }
        widgets.add(SettingWidget.bind(module));
        widgets.add(SettingWidget.bindMode(module));
    }

    Module getModule() {
        return module;
    }

    boolean matches(String filter) {
        return filter.isEmpty() || module.getName().toLowerCase(Locale.ROOT).contains(filter);
    }

    void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    boolean isExpanded() {
        return expanded;
    }

    // ---------------------------------------------------------------- layout

    private int settingsHeight() {
        int h = FAVORITE_H;
        for (SettingWidget widget : widgets) {
            if (widget.isVisible()) {
                h += widget.height();
            }
        }
        return h + INSET;
    }

    /** Current (animated) height of the card including the visible part of its settings. */
    int height() {
        return CARD_H + Math.round(settingsHeight() * expandAnimation);
    }

    boolean rowHovered(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, x, y, w, CARD_H);
    }

    private boolean toggleable() {
        return module.isToggleable();
    }

    /** "3 | Combo mode": the values of the first number / mode settings, shown after the name. */
    private String summary() {
        StringBuilder text = new StringBuilder();
        int parts = 0;
        for (Setting<?> setting : module.getSettings()) {
            if (parts >= MAX_SUMMARY_PARTS || !setting.isVisible()) {
                continue;
            }
            String part = null;
            if (setting instanceof NumberSetting number) {
                part = number.display();
            } else if (setting instanceof ModeSetting mode) {
                part = mode.get();
            }
            if (part != null && !part.isEmpty()) {
                if (parts > 0) {
                    text.append(" | ");
                }
                text.append(part);
                parts++;
            }
        }
        return text.toString();
    }

    // ------------------------------------------------------------- rendering

    void render(DrawContext context, int x, int y, int w, int mouseX, int mouseY) {
        this.x = x;
        this.y = y;
        this.w = w;

        boolean hovered = rowHovered(mouseX, mouseY);
        boolean toggleable = toggleable();
        enabledAnimation = Theme.approach(enabledAnimation, module.isEnabled() && toggleable ? 1f : 0f);
        expandAnimation = Theme.approach(expandAnimation, expanded ? 1f : 0f);
        hoverAnimation = Theme.approach(hoverAnimation, hovered ? 1f : 0f);

        int accent = Theme.accent();
        int onAccent = Theme.onAccent(); // text/icons on the accent-colored (opened) header: dark on bright accents
        boolean open = expandAnimation > 0.02f;
        int total = height();

        // body: a single rounded card; when opened it holds the settings below the header
        if (open) {
            Ui.roundRect(context, x, y, w, total, RADIUS, Theme.bg(CARD));
        }
        // header (full width), then the lighter icon tile on its left edge
        int headerColor = Draw.blend(Draw.blend(CARD, CARD_HOVER, hoverAnimation), accent, expandAnimation);
        shape(context, x, y, w, w, open, Theme.bg(headerColor), w);
        int tileColor = Draw.blend(Draw.blend(TILE, CARD_HOVER, hoverAnimation),
                shift(accent, 0.14f, 0.10f), expandAnimation);
        shape(context, x, y, w, TILE_W + RADIUS, open, Theme.bg(tileColor), TILE_W);

        // icon in the tile
        boolean bright = module.isEnabled() || expanded || hovered;
        int iconX = x + (TILE_W - 14) / 2;
        int iconY = y + (CARD_H - 14) / 2;
        if (expanded || expandAnimation > 0.02f) {
            // on the accent-colored header the icon turns dark when the accent is bright (white, yellow, ...)
            module.getIcon().drawTinted(context, iconX, iconY, 14, Draw.blend(0xFFFFFFFF, onAccent, expandAnimation));
        } else {
            module.getIcon().draw(context, iconX, iconY, 14, bright);
        }

        // name
        int nameX = x + TILE_W + 10;
        int nameColor = Draw.blend(Draw.blend(Theme.TEXT_DIM, Theme.TEXT, Math.max(hoverAnimation, enabledAnimation * 0.6f)),
                onAccent, expandAnimation);
        Ui.textMiddle(context, Ui.trim(module.getName(), NAME_W - 6), nameX, y, CARD_H, nameColor);

        // right side, from the edge inwards: dots column, switch, keybind chip
        int dotsX = x + w - DOTS_W;
        int right = dotsX - 4;
        int dotsColor = Draw.blend(Draw.blend(Theme.TEXT_DIM, Theme.TEXT_BRIGHT, hoverAnimation), onAccent, expandAnimation);
        Ui.icon(context, Ui.Tex.DOTS, dotsX + (DOTS_W - Ui.Tex.DOTS.size) / 2, y + (CARD_H - Ui.Tex.DOTS.size) / 2, dotsColor);

        if (toggleable) {
            int switchX = right - SWITCH_W - 2;
            renderSwitch(context, switchX, y + (CARD_H - SWITCH_H) / 2, accent, onAccent);
            right = switchX - 8;

            String key = module.getKey() > 0 ? KeyNames.of(module.getKey()) : null;
            int chipW = key == null ? 26 : Math.max(26, Ui.width(key) + 12);
            int chipH = 14;
            int chipX = right - chipW;
            if (chipX > nameX + NAME_W) {
                int chipColor = Draw.blend(CHIP, shift(accent, 0.2f, 0.14f), expandAnimation);
                Ui.roundRect(context, chipX, y + (CARD_H - chipH) / 2, chipW, chipH, 4, chipColor);
                if (key != null) {
                    Ui.textCentered(context, key, chipX, y + (CARD_H - chipH) / 2, chipW, chipH,
                            Draw.blend(Theme.TEXT_DIM, onAccent, expandAnimation));
                }
                right = chipX - 8;
            }
        }

        // summary of the main settings between the name and the chip
        int summaryX = nameX + NAME_W;
        int available = right - summaryX;
        if (available > 24) {
            String summary = summary();
            if (!summary.isEmpty()) {
                int color = Draw.blend(Theme.TEXT_FAINT, Draw.blend(accent, onAccent, 0.78f), expandAnimation);
                Ui.textMiddle(context, Ui.trim(summary, available), summaryX, y, CARD_H, color);
            }
        }

        // settings
        if (expandAnimation > 0.001f) {
            int top = y + CARD_H;
            context.enableScissor(x, top, x + w, y + total);
            int cx = x + INSET;
            int cw = w - INSET * 2;
            renderFavorite(context, cx, top, cw, mouseX, mouseY);
            int cursor = top + FAVORITE_H;
            for (SettingWidget widget : widgets) {
                if (widget.isVisible()) {
                    widget.render(context, cx, cursor, cw, mouseX, mouseY);
                    cursor += widget.height();
                }
            }
            context.disableScissor();
        }
    }

    /**
     * Draws the rounded header shape. While the card is open the bottom corners must be square (the settings
     * continue below), so the shape is drawn taller and clipped to the header height.
     */
    private void shape(DrawContext context, int x, int y, int w, int shapeW, boolean open, int color, int clipW) {
        int clip = Math.min(clipW, w);
        context.enableScissor(x, y, x + clip, y + CARD_H);
        Ui.roundRect(context, x, y, Math.min(shapeW, w), open ? CARD_H + RADIUS : CARD_H, RADIUS, color);
        context.disableScissor();
    }

    private void renderSwitch(DrawContext context, int sx, int sy, int accent, int onAccent) {
        int onColor = Draw.blend(accent, shiftTarget(), shiftAmount(0.35f, 0.28f) * expandAnimation);
        int offInner = Draw.blend(0xFF131214, shift(accent, 0.1f, 0.2f), expandAnimation);
        int outer = Draw.blend(0xFF3E3D42, onColor, enabledAnimation);
        int inner = Draw.blend(offInner, onColor, enabledAnimation);
        Ui.roundRect(context, sx, sy, SWITCH_W, SWITCH_H, SWITCH_H / 2, outer);
        Ui.roundRect(context, sx + 1, sy + 1, SWITCH_W - 2, SWITCH_H - 2, (SWITCH_H - 2) / 2, inner);
        int knob = 6;
        int travel = SWITCH_W - knob - 4;
        int knobX = sx + 2 + Math.round(travel * enabledAnimation);
        // the knob must stand out from the accent-colored "on" track: white on dark accents, dark on bright ones
        Ui.roundRect(context, knobX, sy + (SWITCH_H - knob) / 2, knob, knob, knob / 2,
                Draw.blend(0xFF56555B, onAccent, enabledAnimation));
    }

    /** Lightens a dark accent (or darkens a bright one) so details on the opened header stay visible. */
    private static int shift(int accent, float lighten, float darken) {
        return Theme.lightAccent() ? Draw.blend(accent, 0xFF000000, darken) : Draw.blend(accent, 0xFFFFFFFF, lighten);
    }

    private static int shiftTarget() {
        return Theme.lightAccent() ? 0xFF000000 : 0xFFFFFFFF;
    }

    private static float shiftAmount(float lighten, float darken) {
        return Theme.lightAccent() ? darken : lighten;
    }

    private void renderFavorite(DrawContext context, int fx, int fy, int fw, int mouseX, int mouseY) {
        boolean hovered = Draw.inside(mouseX, mouseY, fx, fy, fw, FAVORITE_H);
        Draw.rect(context, fx, fy, fw, FAVORITE_H, Theme.bg(hovered ? Theme.SETTING_HOVER : Theme.SETTING_ROW));
        boolean on = favorite.getAsBoolean();
        Ui.textMiddle(context, "Favorite", fx + Theme.PADDING, fy, FAVORITE_H, on ? Theme.TEXT_BRIGHT : Theme.TEXT);
        int pillW = 20;
        int pillH = 10;
        int pillX = fx + fw - Theme.PADDING - pillW;
        int pillY = fy + (FAVORITE_H - pillH) / 2;
        Ui.roundRect(context, pillX, pillY, pillW, pillH, pillH / 2, on ? Theme.accent() : Theme.TRACK);
        int knob = 8;
        Ui.roundRect(context, on ? pillX + pillW - knob - 1 : pillX + 1, pillY + 1, knob, knob, knob / 2,
                on ? (Theme.lightAccent() ? Theme.onAccent() : 0xFFFFFFFF) : 0xFFFFFFFF);
    }

    // ----------------------------------------------------------------- input

    /** @return true if the click landed on this card or one of its settings. */
    boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rowHovered(mouseX, mouseY)) {
            // Left click on the dots (or right click anywhere) expands: touch screens have no right click.
            boolean dots = mouseX >= x + w - DOTS_W;
            if (button == 1 || (button == 0 && (dots || (!module.isToggleable() && !module.opensOnClick())))) {
                expanded = !expanded;
            } else if (button == 0) {
                module.toggle();
            }
            return true;
        }
        if (expanded && expandAnimation > 0.99f) {
            int top = y + CARD_H;
            if (Draw.inside(mouseX, mouseY, x + INSET, top, w - INSET * 2, FAVORITE_H)) {
                if (button == 0) {
                    toggleFavorite.run();
                }
                return true;
            }
            for (SettingWidget widget : widgets) {
                if (widget.isVisible() && widget.hit(mouseX, mouseY)) {
                    widget.click(mouseX, mouseY, button);
                    return true;
                }
            }
        }
        return false;
    }

    void mouseDragged(double mouseX) {
        if (expanded) {
            widgets.forEach(widget -> widget.drag(mouseX));
        }
    }

    void mouseReleased() {
        widgets.forEach(SettingWidget::release);
    }
}
