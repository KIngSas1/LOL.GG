package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

/** Compact vertical list of independently toggleable filter options. */
final class MultiSelectWidget extends SettingWidget {

    private static final int OPTION_H = 17;
    private static final int CHECK_SIZE = 12;
    private static final int PAGE_SIZE = 12;
    private static final int PAGE_H = 17;
    private final MultiSelectSetting setting;
    private int page;
    /** 0 (unchecked) to 1 (checked) per option, so the box fills and the tick fades instead of snapping. */
    private float[] animation = new float[0];

    MultiSelectWidget(MultiSelectSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        int size = setting.getOptions().size();
        return LINE + Math.min(PAGE_SIZE, size) * OPTION_H + (size > PAGE_SIZE ? PAGE_H : 0) + 2;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT);

        int optionsTop = y + LINE;
        int boxX = x + Theme.PADDING;
        int optionCount = setting.getOptions().size();
        int pageCount = Math.max(1, (optionCount + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, pageCount - 1));
        int first = page * PAGE_SIZE;
        int last = Math.min(optionCount, first + PAGE_SIZE);
        for (int i = first; i < last; i++) {
            String option = setting.getOptions().get(i);
            int rowY = optionsTop + (i - first) * OPTION_H;
            int boxY = rowY + (OPTION_H - CHECK_SIZE) / 2;
            boolean selected = setting.has(option);
            boolean over = Draw.inside(mouseX, mouseY, x + Theme.PADDING - 2, rowY,
                    w - Theme.PADDING * 2 + 4, OPTION_H);

            if (animation.length != optionCount) {
                animation = new float[optionCount];
                for (int j = 0; j < animation.length; j++) {
                    animation[j] = setting.has(setting.getOptions().get(j)) ? 1f : 0f;
                }
            }
            animation[i] = Theme.approach(animation[i], selected ? 1f : 0f);
            float fill = animation[i];

            if (over) {
                Draw.rect(context, x + Theme.PADDING - 2, rowY,
                        w - Theme.PADDING * 2 + 4, OPTION_H, Theme.bg(Theme.SETTING_HOVER));
            }

            // Rounded box: the border color is drawn first, the fill is inset by 1px, so the corners stay clean.
            int border = Draw.blend(over ? Theme.TEXT_DIM : Theme.TEXT_FAINT, Theme.accent(), fill);
            Ui.roundRect(context, boxX, boxY, CHECK_SIZE, CHECK_SIZE, 3, border);
            Ui.roundRect(context, boxX + 1, boxY + 1, CHECK_SIZE - 2, CHECK_SIZE - 2, 2,
                    Draw.blend(Theme.TRACK, Theme.accent(), fill));
            if (fill > 0.05f) {
                Ui.check(context, boxX, boxY, CHECK_SIZE,
                        Draw.withAlpha(Theme.onAccent(), Math.round(255f * fill)));
            }

            int labelX = boxX + CHECK_SIZE + 5;
            int labelWidth = Math.max(24, w - Theme.PADDING * 2 - CHECK_SIZE - 5);
            Ui.textMiddle(context, Ui.trim(option, labelWidth), labelX, rowY, OPTION_H,
                    selected ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        }
        if (optionCount > PAGE_SIZE) {
            int pageY = optionsTop + (last - first) * OPTION_H;
            Draw.rect(context, x, pageY, w, PAGE_H, Theme.bg(Theme.SETTING_ROW));
            String pageLabel = "‹     " + (page + 1) + " / " + pageCount + "     ›";
            Ui.textCentered(context, pageLabel, x, pageY, w, PAGE_H, Theme.TEXT_DIM);
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 1) {
            setting.reset();
            return;
        }
        if (button != 0 || mouseY < y + LINE) {
            return;
        }
        int optionCount = setting.getOptions().size();
        int pageCount = Math.max(1, (optionCount + PAGE_SIZE - 1) / PAGE_SIZE);
        int visibleCount = Math.min(PAGE_SIZE, Math.max(0, optionCount - page * PAGE_SIZE));
        int pageY = y + LINE + visibleCount * OPTION_H;
        if (optionCount > PAGE_SIZE && mouseY >= pageY) {
            if (mouseX < x + w / 3.0) {
                page = Math.max(0, page - 1);
            } else if (mouseX > x + w * 2.0 / 3.0) {
                page = Math.min(pageCount - 1, page + 1);
            }
            return;
        }
        int index = (int) ((mouseY - (y + LINE)) / OPTION_H);
        int optionIndex = page * PAGE_SIZE + index;
        if (index >= 0 && index < visibleCount && optionIndex < optionCount) {
            setting.toggle(setting.getOptions().get(optionIndex));
        }
    }
}
