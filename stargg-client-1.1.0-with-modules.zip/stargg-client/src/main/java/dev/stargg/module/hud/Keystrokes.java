package dev.stargg.module.hud;

import dev.stargg.setting.BooleanSetting;
import dev.stargg.util.ClickTracker;
import dev.stargg.util.Draw;
import dev.stargg.util.Icon;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;

public final class Keystrokes extends HudModule {

    private static final int KEY = 18;
    private static final int GAP = 2;
    private static final int WIDTH = KEY * 3 + GAP * 2;

    private final BooleanSetting mouse = add(new BooleanSetting("Mouse buttons", true));
    private final BooleanSetting cps = add(new BooleanSetting("Show CPS", true));
    private final BooleanSetting space = add(new BooleanSetting("Spacebar", true));

    public Keystrokes() {
        super("Keystrokes", "Shows which movement keys and mouse buttons are pressed", 4, -4);
        icon(Icon.KEYSTROKES);
        enabledByDefault();
        cps.showWhen(mouse::on);
    }

    @Override
    protected int contentWidth() {
        return WIDTH;
    }

    @Override
    protected int contentHeight() {
        int rows = 2 * KEY + GAP;
        if (mouse.on()) {
            rows += GAP + KEY;
        }
        if (space.on()) {
            rows += GAP + 12;
        }
        return rows;
    }

    @Override
    protected void draw(DrawContext context, int x, int y) {
        GameOptions options = mc.options;
        int step = KEY + GAP;

        key(context, x + step, y, KEY, KEY, "W", options.forwardKey.isPressed());
        key(context, x, y + step, KEY, KEY, "A", options.leftKey.isPressed());
        key(context, x + step, y + step, KEY, KEY, "S", options.backKey.isPressed());
        key(context, x + step * 2, y + step, KEY, KEY, "D", options.rightKey.isPressed());

        int cursor = y + step * 2;
        if (mouse.on()) {
            int half = (WIDTH - GAP) / 2;
            String left = cps.on() ? "LMB " + ClickTracker.cps(ClickTracker.LEFT) : "LMB";
            String right = cps.on() ? "RMB " + ClickTracker.cps(ClickTracker.RIGHT) : "RMB";
            key(context, x, cursor, half, KEY, left, ClickTracker.isDown(ClickTracker.LEFT));
            key(context, x + half + GAP, cursor, half, KEY, right, ClickTracker.isDown(ClickTracker.RIGHT));
            cursor += KEY + GAP;
        }
        if (space.on()) {
            key(context, x, cursor, WIDTH, 12, "-----", options.jumpKey.isPressed());
        }
    }

    private void key(DrawContext context, int x, int y, int w, int h, String label, boolean pressed) {
        int fill = pressed ? Draw.withAlpha(textColor(), 0xC8) : 0x80000000;
        int text = pressed ? 0xFF101010 : textColor();
        Draw.rounded(context, x, y, w, h, 2, fill);
        Draw.centeredText(context, label, x, y, w, h, text, false);
    }
}
