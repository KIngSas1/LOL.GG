# Module update (stargg-indev) + AutoElytra / AutoMace fix

## Modules taken from stargg-indev
Everything that differs from the 1.4.3 base was applied on top of the HUD editor / public profile version, no conflicts:
AutoMace, AutoElytra, MaceSwap, WindChargeKey, AutoPearl, PearlCatch; updated AimAssist, ShieldBreaker, Triggerbot;
ModuleManager (new attack dispatch), the attack/pearl and ClientPlayerEntity mixins, MultiSelect / RandomRange
settings and widgets, FriendManager, TargetFilters, ItemFilters, SilentRotationManager, 14 new icons.
The indev notes are kept as `INDEV_PORTING_NOTES.md`.

## AutoElytra + AutoMace: no mace hit after the elytra came off
Causes found in the code, and what changed:
1. **Swap started too late.** AutoMace only asked for the chestplate swap at 3.4 blocks. Gliding or diving at 2 to 3
   blocks per tick the player was already past the target when the swap finished.
   `AutoElytra.getEffectivePreHitRange` now grows with the closing speed (reach + 0.4 + speed x 3 ticks, max 16
   blocks); AutoMace and AutoElytra's own combat check both use it.
2. **Armor swap reset the attack cooldown.** The old swap selected the chestplate hotbar slot and used it, then
   selected the old slot again; every held-item change resets the cooldown, so AutoMace's "cooldown ready" check
   failed for 5 to 33 ticks. New setting **Swap Method** (default `Inventory`) swaps the chest slot with the hotbar
   slot by inventory click, without touching the selected slot, and completes in the same tick. `Use Item` keeps the
   old behaviour.
3. **One tick of delay in AutoMace.** The attack was prepared in one tick and executed in the next. It is now
   executed in the same tick.
4. **Swap waited for AutoElytra's own tick.** AutoMace ticks before AutoElytra, so the swap now runs immediately
   when AutoMace asks for it.
5. **Server still sees you gliding.** The server only notices the missing elytra on its next tick, and a gliding
   mace hit loses its smash bonus. AutoMace now waits 90 ms after the swap before attacking.

## Tick button in options
The target filter checkbox used a font glyph that rendered badly. It is now a 12px rounded box with a clean border,
a fill that animates to the accent color, and a pixel-drawn check mark (`Ui.check`) that fades in.

## Not verified
Not compiled with Loom and not tested in game. `clickSlot` / `SlotActionType.SWAP` are the standard Yarn calls but
were only syntax-checked here. If the server you play on rejects inventory clicks, set Swap Method to `Use Item`.
Both swap methods only look for the chestplate / elytra in the hotbar, as before.

## AutoElytra Silent Swap + AutoMace smooth aim / Target Mode
- **AutoElytra: Silent Swap** (new on/off switch, default on; replaces the old *Swap Method* mode). On = swap the chest
  slot with the hotbar slot through an inventory click, the selected hotbar slot never changes. Off = select the armor
  piece, use it from the hand and restore the old slot afterwards.
- **AutoMace: Aim Smoothing** (0 to 0.95, default 0.5). Each tick turns a fraction of the remaining angle (ease-out),
  capped by *Aim Speed*. The aim now continues from the real view angles every tick, so it blends with mouse movement
  instead of snapping back to an angle from an earlier tick.
- **AutoMace: Target Mode** is now a list: *Closest* (nearest in range, old default), *FOV* (only targets inside the
  view cone set by the **FOV** slider, best = smallest angle) and *Straight* (only what the crosshair points at, checked
  along the full aim range). The old on/off Target Mode (crosshair only) is equivalent to *Straight*; saved values from
  the old boolean are ignored and fall back to *Closest*.

## AimAssist: smoother, less jitter
- New **Smoothing** slider (0 to 0.95, default 0.5): ease-out turn (fraction of the remaining angle, capped by the
  Horizontal/Vertical speed). 0 keeps the old constant-speed turn.
- 0.35 degree dead zone so the camera stops twitching when already on target.
- Target hysteresis: the current target is kept unless another one scores 25 percent better, so the aim no longer flips
  between two similar targets every tick.

## AutoMace 2.0 (new module, Combat)
Own implementation built on StarGG's AutoMace (nothing copied from other clients). It keeps every AutoMace option
(smooth aim, Target Mode Closest/FOV/Straight, stun slam, ...) and adds:
- **Smart Mace Swap** + **Density Height**: below the height it prefers the highest Breach mace, at or above it the
  highest Density mace (falls back to Density if no Breach mace is in the hotbar).
- **Swap Back Slot**: 0 = back to the slot you held, 1 to 9 = always that hotbar slot.
- **Mace Swap Min / Max (ms)**: random wait between the axe hit and the mace swap in a stun slam.
- **Only On Non-Glide** (default on): no attack while gliding, since a gliding hit has no smash bonus.
- **Only Stun Slam**: only act on targets that are blocking.
- **AutoElytra "AutoMace Sync"** works with it exactly as with AutoMace (pre-hit range, chestplate swap, wait for the
  swap to settle, re-equip after the hit). AutoMace and AutoMace 2.0 turn each other off when enabled.
- Triggerbot's shield check and the attack interception in ModuleManager also know about the new module.
