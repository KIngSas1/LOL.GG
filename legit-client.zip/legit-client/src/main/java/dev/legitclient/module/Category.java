package dev.legitclient.module;

import dev.legitclient.util.Icon;

/** The panels shown in the click GUI. Add an entry here to get a new panel. */
public enum Category {
    HUD("HUD", Icon.HUD),
    VISUAL("Visual", Icon.VISUAL),
    UTILITY("Utility", Icon.UTILITY),
    CLIENT("Client", Icon.CLIENT);

    private final String title;
    private final Icon icon;

    Category(String title, Icon icon) {
        this.title = title;
        this.icon = icon;
    }

    public Icon icon() {
        return icon;
    }

    public String title() {
        return title;
    }
}
