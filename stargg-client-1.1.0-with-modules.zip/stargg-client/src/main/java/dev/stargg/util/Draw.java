package dev.stargg.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Small 2D drawing helpers shared by the HUD and the click GUI.
 * All colors are 0xAARRGGBB — keep the alpha byte non-zero or text will not render.
 */
public final class Draw {

    public static final int TEXT_HEIGHT = 9;

    private Draw() {
    }

    public static void rect(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + h, color);
    }

    /** Filled rectangle with rounded corners (radius in pixels, best for r <= 4). */
    public static void rounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            rect(ctx, x, y, w, h, color);
            return;
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
    }

    public static void outline(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y + 1, x + 1, y + h - 1, color);
        ctx.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    public static void text(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
        ctx.drawText(MinecraftClient.getInstance().textRenderer, Ui.regular(text), x, y, color, shadow);
    }

    public static void text(DrawContext ctx, String text, int x, int y, int color) {
        text(ctx, text, x, y, color, false);
    }

    public static void centeredText(DrawContext ctx, String text, int x, int y, int w, int h, int color, boolean shadow) {
        int tx = x + (w - width(text)) / 2;
        int ty = Ui.middleY(y, h);
        text(ctx, text, tx, ty, color, shadow);
    }

    public static int width(String text) {
        return MinecraftClient.getInstance().textRenderer.getWidth(Ui.regular(text));
    }

    /** Cuts the text so it fits into {@code maxWidth} pixels. */
    public static String trim(String text, int maxWidth) {
        return Ui.trim(text, Math.max(0, maxWidth));
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0x00FFFFFF);
    }

    /** Linear blend between two ARGB colors; t = 0 gives a, t = 1 gives b. */
    public static int blend(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int ra = Math.round(aa + (ba - aa) * t);
        int rr = Math.round(ar + (br - ar) * t);
        int rg = Math.round(ag + (bg - ag) * t);
        int rb = Math.round(ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }
}
