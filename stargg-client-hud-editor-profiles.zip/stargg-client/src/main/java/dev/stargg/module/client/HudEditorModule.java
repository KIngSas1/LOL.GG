package dev.stargg.module.client;

import dev.stargg.StarGG;
import dev.stargg.gui.HudEditorScreen;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.util.Icon;

/** Client-category button that opens the HUD editor, where HUD elements are placed and toggled. */
public final class HudEditorModule extends Module {

    public HudEditorModule() {
        super("HUD Editor", "Move, snap and toggle your HUD elements", Category.CLIENT);
        icon(Icon.HUD);
    }

    @Override
    public boolean isToggleable() {
        return false;
    }

    @Override
    public boolean opensOnClick() {
        return true;
    }

    @Override
    protected boolean savesEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        if (!(mc.currentScreen instanceof HudEditorScreen)) {
            mc.setScreen(new HudEditorScreen());
        }
    }

    /** Opens the editor from anywhere (the main menu panel uses this). */
    public static void open() {
        HudEditorModule module = StarGG.modules().get(HudEditorModule.class);
        module.setEnabled(false); // re-arm, so opening always works
        module.setEnabled(true);
    }
}
