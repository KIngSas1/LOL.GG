package dev.stargg.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** A configurable set of independent on/off choices (used for item and entity filters). */
public final class MultiSelectSetting extends Setting<Set<String>> {

    private final List<String> options;

    public MultiSelectSetting(String name, String[] options, String... defaults) {
        super(name, immutable(defaults));
        this.options = new ArrayList<>(Arrays.asList(options));
    }

    private static Set<String> immutable(String... values) {
        LinkedHashSet<String> set = new LinkedHashSet<>(Arrays.asList(values));
        return Collections.unmodifiableSet(set);
    }

    public List<String> getOptions() {
        return Collections.unmodifiableList(options);
    }

    /** Replaces external option choices while retaining selected values that still exist. */
    public void setOptions(List<String> nextOptions) {
        replaceOptions(nextOptions);
        set(value);
    }

    /** Mirrors a dynamic external choice list without notifying the external owner. */
    public void setOptionsSilently(List<String> nextOptions, Set<String> selected) {
        replaceOptions(nextOptions);
        LinkedHashSet<String> valid = new LinkedHashSet<>();
        if (selected != null) {
            for (String option : options) {
                if (selected.contains(option)) valid.add(option);
            }
        }
        setSilently(Collections.unmodifiableSet(valid));
    }

    private void replaceOptions(List<String> nextOptions) {
        List<String> clean = new ArrayList<>();
        if (nextOptions != null) {
            for (String option : nextOptions) {
                if (option != null && !option.isBlank() && !clean.contains(option)) {
                    clean.add(option);
                }
            }
        }
        options.clear();
        options.addAll(clean);
    }

    public Set<String> getSelected() {
        return value;
    }

    public boolean has(String option) {
        return value.contains(option);
    }

    public void toggle(String option) {
        if (!options.contains(option)) {
            return;
        }
        LinkedHashSet<String> next = new LinkedHashSet<>(value);
        if (!next.add(option)) {
            next.remove(option);
        }
        set(Collections.unmodifiableSet(next));
    }

    @Override
    public void set(Set<String> selected) {
        LinkedHashSet<String> valid = new LinkedHashSet<>();
        if (selected != null) {
            for (String option : options) {
                if (selected.contains(option)) {
                    valid.add(option);
                }
            }
        }
        super.set(Collections.unmodifiableSet(valid));
    }

    @Override
    public JsonElement save() {
        JsonArray array = new JsonArray();
        for (String option : options) {
            if (value.contains(option)) {
                array.add(option);
            }
        }
        return array;
    }

    @Override
    public void load(JsonElement json) {
        if (json == null) {
            return;
        }
        LinkedHashSet<String> selected = new LinkedHashSet<>();
        if (json.isJsonArray()) {
            for (JsonElement element : json.getAsJsonArray()) {
                if (element.isJsonPrimitive()) {
                    selected.add(element.getAsString());
                }
            }
        } else if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isString()) {
            String raw = json.getAsString();
            for (String option : raw.split(",")) {
                selected.add(option.trim());
            }
        } else if (json.isJsonPrimitive() && json.getAsJsonPrimitive().isBoolean()) {
            // Older configs may contain a boolean for a setting that was previously a toggle.
            if (json.getAsBoolean() && !options.isEmpty()) {
                selected.add(options.get(0));
            }
        }
        set(selected);
    }
}
