package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.NumberSetting;
import dev.legitclient.util.Ui;
import net.minecraft.client.gui.DrawContext;

final class NumberWidget extends SettingWidget {

    private final NumberSetting setting;
    private boolean dragging;

    NumberWidget(NumberSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 28;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY) || dragging);
        label(context, setting.getName(), Theme.TEXT);
        rightText(context, setting.display(), Theme.TEXT_DIM);

        int trackX = x + Theme.PADDING;
        int trackW = w - Theme.PADDING * 2;
        int trackY = y + LINE + 2;
        double fraction = (setting.getDouble() - setting.getMin()) / (setting.getMax() - setting.getMin());
        int filled = (int) Math.round(trackW * fraction);
        Ui.roundRect(context, trackX, trackY, trackW, 3, 1, Theme.TRACK);
        if (filled > 1) {
            Ui.roundRect(context, trackX, trackY, filled, 3, 1, Theme.accent());
        }
        // the knob stays fully inside the track (it used to poke out past the right edge)
        int knobX = trackX + Math.max(0, Math.min(trackW - 8, filled - 4));
        Ui.roundRect(context, knobX, trackY - 2, 8, 8, 4, 0xFFFFFFFF);
    }

    private void applyMouse(double mouseX) {
        double fraction = (mouseX - (x + Theme.PADDING)) / (double) (w - Theme.PADDING * 2);
        fraction = Math.max(0, Math.min(1, fraction));
        setting.set(setting.getMin() + fraction * (setting.getMax() - setting.getMin()));
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            dragging = true;
            applyMouse(mouseX);
        } else if (button == 1) {
            setting.reset();
        }
    }

    @Override
    public void drag(double mouseX) {
        if (dragging) {
            applyMouse(mouseX);
        }
    }

    @Override
    public void release() {
        dragging = false;
    }
}
