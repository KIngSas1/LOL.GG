package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.ActionSetting;
import dev.legitclient.util.Ui;
import net.minecraft.client.gui.DrawContext;

final class ActionWidget extends SettingWidget {

    private final ActionSetting setting;

    ActionWidget(ActionSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return LINE;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        boolean hover = hovered(mouseX, mouseY);
        paintRow(context, hover);
        Ui.textCentered(context, setting.getName(), x, y, w, height(), hover ? Theme.accent() : Theme.TEXT);
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setting.run();
        }
    }
}
