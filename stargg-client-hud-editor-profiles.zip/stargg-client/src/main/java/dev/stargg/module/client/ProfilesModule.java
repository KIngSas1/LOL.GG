package dev.stargg.module.client;

import dev.stargg.StarGG;
import dev.stargg.gui.ProfilesScreen;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.util.Icon;

/** Client-category button that opens the profiles screen (load, save, rename, share your settings). */
public final class ProfilesModule extends Module {

    public ProfilesModule() {
        super("Profiles", "Save, load and share your settings", Category.CLIENT);
        icon(Icon.CLIENT);
    }

    @Override
    public boolean isToggleable() {
        return false;
    }

    @Override
    public boolean opensOnClick() {
        return true;
    }

    @Override
    protected boolean savesEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        if (!(mc.currentScreen instanceof ProfilesScreen)) {
            mc.setScreen(new ProfilesScreen());
        }
    }

    public static void open() {
        ProfilesModule module = StarGG.modules().get(ProfilesModule.class);
        module.setEnabled(false);
        module.setEnabled(true);
    }
}
