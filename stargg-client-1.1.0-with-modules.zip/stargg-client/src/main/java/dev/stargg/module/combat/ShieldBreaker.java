package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.util.hit.EntityHitResult;

/** Temporarily selects a hotbar axe to hit a player who is actively blocking. */
public final class ShieldBreaker extends Module {

    private final NumberSetting swapDelay = add(new NumberSetting("Swap delay", 1, 0, 5, 1));
    private final NumberSetting swapBackDelay = add(new NumberSetting("Swap back delay", 1, 0, 5, 1));
    private final BooleanSetting requireMouseDown = add(new BooleanSetting("Require mouse down", false));

    private int originalSlot = -1;
    private int axeSlot = -1;
    private int delayTicks;
    private int swapBackTicks;
    private PlayerEntity target;
    private boolean attackPending;

    public ShieldBreaker() {
        super("Shield Breaker", "Automatically swaps to an axe against a blocking player", Category.COMBAT);
        icon(Icon.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            restoreSlot();
            return;
        }
        if (requireMouseDown.on() && !mc.options.attackKey.isPressed()) {
            restoreSlot();
            return;
        }

        if (target != null) {
            if (!target.isAlive()) {
                restoreSlot();
                return;
            }
            if (attackPending) {
                if (!target.isBlocking()) {
                    restoreSlot();
                    return;
                }
                if (delayTicks > 0) {
                    delayTicks--;
                    return;
                }
                if (mc.player.getAttackCooldownProgress(0.5F) >= 1.0F) {
                    mc.interactionManager.attackEntity(mc.player, target);
                    mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                    attackPending = false;
                    swapBackTicks = swapBackDelay.getInt();
                }
                return;
            }
            if (swapBackTicks > 0) {
                swapBackTicks--;
            } else {
                restoreSlot();
            }
            return;
        }

        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity playerTarget)) {
            return;
        }
        if (!playerTarget.isAlive() || !playerTarget.isBlocking()) {
            return;
        }
        int foundAxe = findAxeSlot();
        if (foundAxe < 0 || mc.player.getAttackCooldownProgress(0.5F) < 1.0F) {
            return;
        }

        target = playerTarget;
        originalSlot = mc.player.getInventory().getSelectedSlot();
        axeSlot = foundAxe;
        if (originalSlot != axeSlot) {
            mc.player.getInventory().setSelectedSlot(axeSlot);
        }
        delayTicks = swapDelay.getInt();
        attackPending = true;
    }

    private int findAxeSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    private void restoreSlot() {
        if (mc.player != null && originalSlot >= 0 && originalSlot < 9) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        originalSlot = -1;
        axeSlot = -1;
        target = null;
        delayTicks = 0;
        swapBackTicks = 0;
        attackPending = false;
    }

    @Override
    protected void onDisable() {
        restoreSlot();
    }
}
