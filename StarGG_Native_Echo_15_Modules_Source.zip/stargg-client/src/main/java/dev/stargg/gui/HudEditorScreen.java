package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.gui.hudeditor.HudEditorState;
import dev.stargg.gui.hudeditor.HudSnapper;
import dev.stargg.gui.widget.SettingWidget;
import dev.stargg.module.Module;
import dev.stargg.module.client.ClickGuiModule;
import dev.stargg.module.client.HudEditorModule;
import dev.stargg.module.hud.HudModule;
import dev.stargg.setting.Setting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * The HUD editor, ported from the chat v4 HUD editor system.
 *
 * <ul>
 *   <li><b>Elements</b> are drawn on a translucent plate. Hovering shows a label; clicking selects one.</li>
 *   <li>The <b>selected</b> element gets a dashed frame, its name above it, and a close button (turns the element
 *       off) and a settings button stacked next to it.</li>
 *   <li>The settings button opens an <b>anchored settings popup</b> beside it (it flips to the other side when
 *       there is no room) that holds all settings of the element, using the same widgets as the click GUI.</li>
 *   <li>Dragging <b>snaps</b> to the other elements and to the screen center lines, with green guide lines and a
 *       sticky release (see {@link HudSnapper}). Hold Shift to move freely.</li>
 *   <li>The <b>element window</b> has group tabs (Favorite / All / HUD / Game), a search box and a switch per
 *       element. Right-click a row to mark it as favorite.</li>
 * </ul>
 */
public final class HudEditorScreen extends Screen {

    private static final int BTN = 14;
    private static final int GAP = 2;
    private static final int GUIDE_COLOR = 0xFF3DDC84;

    // element window
    private static final int WIN_W = 196;
    private static final int WIN_HEADER = 22;
    private static final int WIN_BACK_W = 24;
    private static final int WIN_TABS = 18;
    private static final int WIN_SEARCH = 24;
    private static final int WIN_ROW = 18;
    private static final int WIN_MAX_ROWS = 8;
    private static final int WIN_FOOTER = 28;

    // settings popup
    private static final int POP_W = 150;
    private static final int POP_HEADER = 18;
    private static final int POP_ROW = 18;

    private enum Group {
        FAVORITE("Favorite"), ALL("All"), HUD("HUD"), GAME("Game");

        final String label;

        Group(String label) {
            this.label = label;
        }
    }

    private static final Set<String> HUD_GROUP = Set.of("Watermark", "ModuleList", "Clock");

    private record Btn(int x, int y, int w, int h, boolean enabled, Runnable action) {
    }

    private final List<Btn> buttons = new ArrayList<>();
    private final List<Btn> pending = new ArrayList<>();
    private final HudSnapper snapper = new HudSnapper();

    private HudModule selected;
    private HudModule dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    // element window
    private int winX = HudEditorState.windowX();
    private int winY = HudEditorState.windowY();
    private int winH;
    private boolean draggingWin;
    private int winDragX;
    private int winDragY;
    private Group group = Group.ALL;
    private String search = "";
    private boolean searchFocused;
    private int listScroll;
    private final int[] tabStart = new int[Group.values().length];
    private final int[] tabEnd = new int[Group.values().length];

    // settings popup
    private boolean popupOpen;
    private HudModule widgetsFor;
    private final List<SettingWidget> widgets = new ArrayList<>();
    private int popX;
    private int popY;
    private int popH;
    private int popBodyY;
    private int popBodyH;
    private int popScroll;
    private boolean draggingWidget;

    private String status = "";
    private long statusUntil;
    private long confirmResetUntil;

    public HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------------ data

    private static List<HudModule> hudModules() {
        List<HudModule> list = new ArrayList<>();
        for (Module module : StarGG.modules().all()) {
            if (module instanceof HudModule hud) {
                list.add(hud);
            }
        }
        return list;
    }

    private static boolean visible(HudModule hud) {
        return hud.isEnabled() && hud.getWidth() > 0;
    }

    private static boolean inWorld() {
        return MinecraftClient.getInstance().world != null;
    }

    private List<HudModule> filtered() {
        List<HudModule> out = new ArrayList<>();
        String query = search.trim().toLowerCase(Locale.ROOT);
        for (HudModule hud : hudModules()) {
            boolean inGroup = switch (group) {
                case ALL -> true;
                case FAVORITE -> HudEditorState.isFavorite(hud.getName());
                case HUD -> HUD_GROUP.contains(hud.getClass().getSimpleName());
                case GAME -> !HUD_GROUP.contains(hud.getClass().getSimpleName());
            };
            if (inGroup && (query.isEmpty() || hud.getName().toLowerCase(Locale.ROOT).contains(query))) {
                out.add(hud);
            }
        }
        return out;
    }

    private void flash(String message) {
        status = message;
        statusUntil = System.currentTimeMillis() + 2200;
    }

    private static boolean shiftDown() {
        long window = MinecraftClient.getInstance().getWindow().getHandle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    private static boolean controlDown() {
        long window = MinecraftClient.getInstance().getWindow().getHandle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SUPER) == GLFW.GLFW_PRESS;
    }

    // ------------------------------------------------------------- selection

    private void select(HudModule hud) {
        if (hud != selected) {
            closePopup();
        }
        selected = hud;
    }

    private void closePopup() {
        popupOpen = false;
        draggingWidget = false;
        popScroll = 0;
        SettingWidget.releaseFocus();
    }

    private void togglePopup() {
        if (popupOpen) {
            closePopup();
            return;
        }
        if (selected == null) {
            return;
        }
        if (widgetsFor != selected) {
            widgets.clear();
            for (Setting<?> setting : selected.getSettings()) {
                try {
                    widgets.add(SettingWidget.create(setting));
                } catch (IllegalArgumentException ignored) {
                    // a setting type without a widget is simply not editable here
                }
            }
            widgetsFor = selected;
        }
        popupOpen = true;
        popScroll = 0;
    }

    private void turnOff(HudModule hud) {
        hud.setEnabled(false);
        flash(hud.getName() + " off");
        if (hud == selected) {
            closePopup();
            selected = null;
        }
    }

    // ------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        pending.clear();
        boolean world = inWorld();

        if (world) {
            renderElements(context, mouseX, mouseY);
            renderGuides(context);
        } else {
            Ui.textCentered(context, "Join a world to edit your HUD", 0, height / 2 - 20, width, 12, Theme.TEXT);
        }
        renderWindow(context, mouseX, mouseY);
        if (world && popupOpen && selected != null) {
            renderPopup(context, mouseX, mouseY);
        }
        renderStatus(context);
        buttons.clear();
        buttons.addAll(pending);
    }

    // ---- elements

    private void renderElements(DrawContext context, int mouseX, int mouseY) {
        HudModule hovered = dragging == null && !overUi(mouseX, mouseY) ? pick(mouseX, mouseY) : null;
        for (HudModule hud : hudModules()) {
            if (!visible(hud)) {
                continue;
            }
            boolean isSelected = hud == selected;
            boolean isHovered = hud == hovered || hud == dragging;
            // translucent plate so even an empty element can be seen and grabbed
            int plate = Draw.withAlpha(Theme.HEADER, isSelected ? 0x99 : 0x66);
            Draw.rect(context, hud.getX(), hud.getY(), hud.getWidth(), hud.getHeight(), plate);
            if (isSelected) {
                Draw.rect(context, hud.getX(), hud.getY(), hud.getWidth(), hud.getHeight(), Draw.withAlpha(Theme.accent(), 0x22));
            } else if (isHovered) {
                Draw.outline(context, hud.getX() - 1, hud.getY() - 1, hud.getWidth() + 2, hud.getHeight() + 2,
                        Draw.withAlpha(Theme.accent(), 0x96));
            }
            if (isSelected || isHovered) {
                renderLabel(context, hud, isSelected);
            }
        }
        if (selected != null && visible(selected)) {
            renderSelectionChrome(context, mouseX, mouseY, selected);
        }
    }

    private void renderLabel(DrawContext context, HudModule hud, boolean withPosition) {
        String text = withPosition ? hud.getName() + "  " + hud.getX() + ", " + hud.getY() : hud.getName();
        int y = hud.getY() - Ui.TEXT_HEIGHT - 6;
        if (y < 2) {
            y = hud.getY() + hud.getHeight() + 6;
        }
        int x = Math.max(2, Math.min(hud.getX(), width - Ui.width(text) - 2));
        Ui.text(context, text, x, y, Theme.TEXT_BRIGHT, true);
    }

    /** {closeX, closeY, settingsX, settingsY} of the two buttons next to the element. */
    private int[] controls(HudModule hud) {
        int bx = hud.getX() + hud.getWidth() + GAP + 1;
        if (bx + BTN + 3 > width) {
            bx = hud.getX() - GAP - 1 - BTN;
        }
        int by = Math.max(0, Math.min(hud.getY(), height - (BTN * 2 + GAP)));
        return new int[]{bx, by, bx, by + BTN + GAP};
    }

    private void renderSelectionChrome(DrawContext context, int mouseX, int mouseY, HudModule hud) {
        int[] c = controls(hud);
        int left = Math.min(hud.getX(), c[0]) - 3;
        int right = Math.max(hud.getX() + hud.getWidth(), c[0] + BTN) + 3;
        int top = Math.min(hud.getY(), c[1]) - 3;
        int bottom = Math.max(hud.getY() + hud.getHeight(), c[3] + BTN) + 3;
        dashed(context, left, top, right, bottom, Theme.accent());

        drawControl(context, mouseX, mouseY, c[0], c[1], Ui.Tex.CLOSE, false);
        drawControl(context, mouseX, mouseY, c[2], c[3], Ui.Tex.DOTS, popupOpen);
    }

    private void drawControl(DrawContext context, int mouseX, int mouseY, int x, int y, Ui.Tex icon, boolean active) {
        boolean hovered = Draw.inside(mouseX, mouseY, x, y, BTN, BTN);
        int fill = active ? Theme.accent() : (hovered ? Theme.ROW_HOVER : Theme.HEADER);
        Ui.roundRect(context, x, y, BTN, BTN, 3, fill);
        int tint = active ? Theme.onAccent() : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT);
        Ui.icon(context, icon, x + (BTN - icon.size) / 2, y + (BTN - icon.size) / 2, tint);
    }

    /** A dashed 1 unit rectangle (dash and gap are 1 unit each). */
    private static void dashed(DrawContext context, int x1, int y1, int x2, int y2, int color) {
        for (int x = x1; x <= x2; x += 2) {
            context.fill(x, y1, x + 1, y1 + 1, color);
            context.fill(x, y2, x + 1, y2 + 1, color);
        }
        for (int y = y1; y <= y2; y += 2) {
            context.fill(x1, y, x1 + 1, y + 1, color);
            context.fill(x2, y, x2 + 1, y + 1, color);
        }
    }

    private void renderGuides(DrawContext context) {
        if (dragging == null) {
            return;
        }
        for (HudSnapper.Guide guide : snapper.guides()) {
            Draw.rect(context, guide.x1(), guide.y1(), Math.max(1, guide.x2() - guide.x1()), Math.max(1, guide.y2() - guide.y1()), GUIDE_COLOR);
        }
    }

    // ---- element window

    private int visibleRows(int count) {
        return Math.max(1, Math.min(WIN_MAX_ROWS, count));
    }

    private int windowHeight(int count) {
        return WIN_HEADER + WIN_TABS + WIN_SEARCH + visibleRows(count) * WIN_ROW + WIN_FOOTER;
    }

    private void renderWindow(DrawContext context, int mouseX, int mouseY) {
        List<HudModule> list = filtered();
        int rows = visibleRows(list.size());
        winH = windowHeight(list.size());
        winX = Math.max(0, Math.min(winX, width - WIN_W));
        winY = Math.max(0, Math.min(winY, height - winH));
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, list.size() - rows)));

        Ui.roundRect(context, winX, winY, WIN_W, winH, 4, Theme.bg(Theme.ROW));
        Ui.roundRect(context, winX, winY, WIN_W, WIN_HEADER, 4, Theme.bg(Theme.HEADER));
        Draw.rect(context, winX, winY + WIN_HEADER - 4, WIN_W, 4, Theme.bg(Theme.HEADER));
        Ui.icon(context, Ui.Tex.CAT_HUD, winX + Theme.PADDING, winY + (WIN_HEADER - 10) / 2, Theme.accent());
        Ui.textBold(context, "HUD Editor", winX + Theme.PADDING + 15, Ui.middleY(winY, WIN_HEADER), Theme.TEXT_BRIGHT);
        // back to the client's home GUI
        boolean backHover = Draw.inside(mouseX, mouseY, winX + WIN_W - WIN_BACK_W, winY, WIN_BACK_W, WIN_HEADER);
        Ui.icon(context, Ui.Tex.BACK, winX + WIN_W - WIN_BACK_W + (WIN_BACK_W - Ui.Tex.BACK.size) / 2,
                winY + (WIN_HEADER - Ui.Tex.BACK.size) / 2, backHover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);

        // group tabs with an underline below the selected one
        int tabY = winY + WIN_HEADER;
        int cursor = winX + Theme.PADDING;
        for (Group g : Group.values()) {
            int tw = Ui.width(g.label);
            tabStart[g.ordinal()] = cursor - 4;
            tabEnd[g.ordinal()] = cursor + tw + 4;
            boolean selectedTab = g == group;
            boolean hovered = Draw.inside(mouseX, mouseY, cursor - 4, tabY, tw + 8, WIN_TABS);
            Ui.textMiddle(context, g.label, cursor, tabY, WIN_TABS, selectedTab ? Theme.TEXT_BRIGHT : (hovered ? Theme.TEXT : Theme.TEXT_DIM));
            if (selectedTab) {
                dashed(context, cursor, tabY + WIN_TABS - 3, cursor + tw, tabY + WIN_TABS - 3, Theme.accent());
            }
            cursor += tw + 14;
        }

        // search box
        int sx = winX + Theme.PADDING;
        int sy = tabY + WIN_TABS + 3;
        int sw = WIN_W - Theme.PADDING * 2;
        int sh = WIN_SEARCH - 6;
        Ui.roundRect(context, sx, sy, sw, sh, 3, Theme.bg(Theme.SETTING_ROW));
        if (searchFocused) {
            Draw.rect(context, sx + 3, sy + sh - 1, sw - 6, 1, Theme.accent());
        }
        if (search.isEmpty() && !searchFocused) {
            Ui.textMiddle(context, "Search elements...", sx + 6, sy, sh, Theme.TEXT_FAINT);
        } else {
            String shown = Ui.trim(search, sw - 14);
            Ui.textMiddle(context, shown, sx + 6, sy, sh, Theme.TEXT_BRIGHT);
            if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                Draw.rect(context, sx + 6 + Ui.width(shown) + 1, sy + 4, 1, sh - 8, Theme.TEXT_BRIGHT);
            }
        }

        // rows
        int listY = winY + WIN_HEADER + WIN_TABS + WIN_SEARCH;
        if (list.isEmpty()) {
            String empty = group == Group.FAVORITE && search.isEmpty() ? "Right-click an element to favorite it" : "No elements found";
            Ui.textCentered(context, empty, winX, listY, WIN_W, WIN_ROW, Theme.TEXT_FAINT);
        }
        for (int i = 0; i < rows && listScroll + i < list.size(); i++) {
            HudModule hud = list.get(listScroll + i);
            int rowY = listY + i * WIN_ROW;
            boolean hovered = Draw.inside(mouseX, mouseY, winX, rowY, WIN_W, WIN_ROW);
            boolean on = hud.isEnabled();
            if (hud == selected) {
                Draw.rect(context, winX + 2, rowY, WIN_W - 4, WIN_ROW, Draw.withAlpha(Theme.accent(), 0x30));
            } else if (hovered) {
                Draw.rect(context, winX + 2, rowY, WIN_W - 4, WIN_ROW, Theme.bg(Theme.ROW_HOVER));
            }
            int textX = winX + Theme.PADDING;
            if (HudEditorState.isFavorite(hud.getName())) {
                Ui.icon(context, Ui.Tex.STAR, textX - 1, rowY + (WIN_ROW - Ui.Tex.STAR.size) / 2, Theme.accent());
            }
            textX += 12;
            String name = Ui.trim(hud.getName(), WIN_W - Theme.PADDING * 2 - 12 - 26);
            Ui.textMiddle(context, name, textX, rowY, WIN_ROW, on ? Theme.TEXT : Theme.TEXT_FAINT);
            drawSwitch(context, winX + WIN_W - Theme.PADDING - 18, rowY + (WIN_ROW - 10) / 2, on);
        }
        if (list.size() > rows) {
            int trackH = rows * WIN_ROW;
            int thumbH = Math.max(10, trackH * rows / list.size());
            int thumbY = listY + (trackH - thumbH) * listScroll / Math.max(1, list.size() - rows);
            Draw.rect(context, winX + WIN_W - 3, thumbY, 2, thumbH, Draw.withAlpha(Theme.accent(), 0x80));
        }

        // footer
        int footY = listY + rows * WIN_ROW + 4;
        boolean resetArmed = System.currentTimeMillis() < confirmResetUntil;
        int bw = (WIN_W - Theme.PADDING * 2 - 4) / 2;
        footerButton(context, mouseX, mouseY, Ui.Tex.RESET, resetArmed ? "Sure?" : "Reset all", winX + Theme.PADDING, footY, bw, resetArmed, this::resetAll);
        footerButton(context, mouseX, mouseY, Ui.Tex.CLOSE, "Done", winX + Theme.PADDING + bw + 4, footY, bw, false, this::close);
    }

    private void footerButton(DrawContext context, int mouseX, int mouseY, Ui.Tex icon, String label, int x, int y, int w, boolean active, Runnable action) {
        int h = 18;
        boolean hovered = Draw.inside(mouseX, mouseY, x, y, w, h);
        int fill = active ? Theme.accent() : (hovered ? Theme.ROW_HOVER : Theme.BADGE);
        int text = active ? Theme.onAccent() : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT);
        Ui.roundRect(context, x, y, w, h, 3, fill);
        Ui.iconLabel(context, icon, label, x, y, w, h, text);
        pending.add(new Btn(x, y, w, h, true, action));
    }

    private static void drawSwitch(DrawContext context, int x, int y, boolean on) {
        Ui.roundRect(context, x, y, 18, 10, 5, on ? Theme.accent() : Theme.TRACK);
        int knobX = on ? x + 10 : x + 2;
        Ui.roundRect(context, knobX, y + 2, 6, 6, 3, on ? Theme.onAccent() : Theme.TEXT_DIM);
    }

    // ---- settings popup

    private int widgetsHeight() {
        int h = 0;
        for (SettingWidget widget : widgets) {
            if (widget.isVisible()) {
                h += widget.height();
            }
        }
        return h;
    }

    private void layoutPopup() {
        int[] c = controls(selected);
        int content = widgetsHeight() + POP_ROW;
        int maxBody = Math.max(POP_ROW * 2, height - 16 - POP_HEADER);
        popBodyH = Math.min(content, maxBody);
        popH = POP_HEADER + popBodyH;
        // beside the settings button; on the other side when it would run off the screen
        popX = c[2] + BTN + GAP + POP_W > width ? c[2] - GAP - POP_W : c[2] + BTN + GAP;
        popX = Math.max(0, Math.min(popX, width - POP_W));
        popY = Math.max(0, Math.min(c[3], height - popH));
        popBodyY = popY + POP_HEADER;
        popScroll = Math.max(0, Math.min(popScroll, Math.max(0, content - popBodyH)));
    }

    private void renderPopup(DrawContext context, int mouseX, int mouseY) {
        layoutPopup();
        Ui.roundRect(context, popX, popY, POP_W, popH, 4, Theme.bg(Theme.ROW));
        Ui.roundRect(context, popX, popY, POP_W, POP_HEADER, 4, Theme.bg(Theme.HEADER));
        Draw.rect(context, popX, popY + POP_HEADER - 4, POP_W, 4, Theme.bg(Theme.HEADER));
        Ui.textBold(context, Ui.trim(selected.getName(), POP_W - Theme.PADDING * 2 - 16), popX + Theme.PADDING,
                Ui.middleY(popY, POP_HEADER), Theme.TEXT_BRIGHT);
        int cx = popX + POP_W - Ui.Tex.CLOSE.size - 4;
        boolean closeHover = Draw.inside(mouseX, mouseY, cx - 2, popY, Ui.Tex.CLOSE.size + 6, POP_HEADER);
        Ui.icon(context, Ui.Tex.CLOSE, cx, popY + (POP_HEADER - Ui.Tex.CLOSE.size) / 2, closeHover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);

        context.enableScissor(popX, popBodyY, popX + POP_W, popBodyY + popBodyH);
        int cursor = popBodyY - popScroll;
        for (SettingWidget widget : widgets) {
            if (widget.isVisible()) {
                widget.render(context, popX, cursor, POP_W, mouseX, mouseY);
                cursor += widget.height();
            }
        }
        // reset position row
        boolean hovered = Draw.inside(mouseX, mouseY, popX, cursor, POP_W, POP_ROW) && mouseY >= popBodyY && mouseY < popBodyY + popBodyH;
        Draw.rect(context, popX, cursor, POP_W, POP_ROW, Theme.bg(hovered ? Theme.SETTING_HOVER : Theme.SETTING_ROW));
        int rowColor = hovered ? Theme.TEXT_BRIGHT : Theme.TEXT;
        Ui.icon(context, Ui.Tex.RESET, popX + Theme.PADDING, cursor + (POP_ROW - Ui.Tex.RESET.size) / 2, rowColor);
        Ui.textMiddle(context, "Reset position", popX + Theme.PADDING + Ui.Tex.RESET.size + 5, cursor, POP_ROW, rowColor);
        context.disableScissor();
    }

    private int resetRowY() {
        return popBodyY - popScroll + widgetsHeight();
    }

    private void renderStatus(DrawContext context) {
        String hint = "Drag to move  -  Hold Shift: no snap  -  Arrows nudge (Shift x10)  -  R reset";
        Ui.textCentered(context, Ui.trim(hint, width - 16), 0, height - 14, width, 12, Theme.TEXT_FAINT);
        if (System.currentTimeMillis() > statusUntil || status.isEmpty()) {
            return;
        }
        int w = Ui.width(status) + 16;
        int x = (width - w) / 2;
        Ui.roundRect(context, x, 8, w, 18, 4, Theme.bg(Theme.HEADER));
        Ui.textCentered(context, status, x, 8, w, 18, Theme.TEXT_BRIGHT);
    }

    // ----------------------------------------------------------------- actions

    private void resetSelected() {
        if (selected != null) {
            selected.resetPosition();
            flash(selected.getName() + " reset");
        }
    }

    private void resetAll() {
        long now = System.currentTimeMillis();
        if (now > confirmResetUntil) {
            confirmResetUntil = now + 3000;
            return;
        }
        confirmResetUntil = 0;
        for (HudModule hud : hudModules()) {
            hud.resetPosition();
        }
        flash("All HUD positions reset");
    }

    // ------------------------------------------------------------------- input

    private boolean overWindow(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, winX, winY, WIN_W, winH);
    }

    private boolean overPopup(double mouseX, double mouseY) {
        return popupOpen && selected != null && Draw.inside(mouseX, mouseY, popX, popY, POP_W, popH);
    }

    private boolean overControls(double mouseX, double mouseY) {
        if (selected == null || !visible(selected)) {
            return false;
        }
        int[] c = controls(selected);
        return Draw.inside(mouseX, mouseY, c[0], c[1], BTN, BTN) || Draw.inside(mouseX, mouseY, c[2], c[3], BTN, BTN);
    }

    private boolean overUi(double mouseX, double mouseY) {
        return overWindow(mouseX, mouseY) || overPopup(mouseX, mouseY) || overControls(mouseX, mouseY);
    }

    /** The smallest visible element under the cursor, so small elements inside big ones can still be grabbed. */
    private HudModule pick(double mouseX, double mouseY) {
        HudModule best = null;
        for (HudModule hud : hudModules()) {
            if (visible(hud) && hud.contains(mouseX, mouseY)
                    && (best == null || hud.getWidth() * hud.getHeight() < best.getWidth() * best.getHeight())) {
                best = hud;
            }
        }
        return best;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        // footer buttons of the element window
        for (Btn btn : buttons) {
            if (Draw.inside(mouseX, mouseY, btn.x(), btn.y(), btn.w(), btn.h())) {
                if (button == 0 && btn.enabled()) {
                    btn.action().run();
                }
                return true;
            }
        }

        if (inWorld() && overPopup(mouseX, mouseY)) {
            clickPopup(mouseX, mouseY, button);
            return true;
        }
        if (overWindow(mouseX, mouseY)) {
            clickWindow(mouseX, mouseY, button);
            return true;
        }
        searchFocused = false;

        if (!inWorld()) {
            return super.mouseClicked(click, doubled);
        }
        if (overControls(mouseX, mouseY)) {
            int[] c = controls(selected);
            if (button == 0) {
                if (Draw.inside(mouseX, mouseY, c[0], c[1], BTN, BTN)) {
                    turnOff(selected);
                } else {
                    togglePopup();
                }
            }
            return true;
        }

        HudModule hit = pick(mouseX, mouseY);
        if (hit == null) {
            selected = null;
            closePopup();
            return super.mouseClicked(click, doubled);
        }
        select(hit);
        if (button == 0) {
            dragging = hit;
            dragOffsetX = (int) mouseX - hit.getX();
            dragOffsetY = (int) mouseY - hit.getY();
            snapper.reset();
        } else if (button == 1) {
            togglePopup();
        }
        return true;
    }

    private void clickPopup(double mouseX, double mouseY, int button) {
        int closeW = Ui.Tex.CLOSE.size + 6;
        if (mouseY < popBodyY) {
            if (button == 0 && mouseX >= popX + POP_W - closeW - 4) {
                closePopup();
            }
            return;
        }
        if (mouseY >= popBodyY + popBodyH) {
            return;
        }
        for (SettingWidget widget : widgets) {
            if (widget.isVisible() && widget.hit(mouseX, mouseY)) {
                widget.click(mouseX, mouseY, button);
                draggingWidget = true;
                return;
            }
        }
        if (button == 0 && mouseY >= resetRowY() && mouseY < resetRowY() + POP_ROW) {
            resetSelected();
        }
    }

    private void clickWindow(double mouseX, double mouseY, int button) {
        int relative = (int) mouseY - winY;
        if (relative < WIN_HEADER) {
            if (button == 0 && mouseX >= winX + WIN_W - WIN_BACK_W) {
                ClickGuiModule.open();
                return;
            }
            if (button == 0) {
                draggingWin = true;
                winDragX = (int) mouseX - winX;
                winDragY = (int) mouseY - winY;
            }
            searchFocused = false;
            return;
        }
        if (relative < WIN_HEADER + WIN_TABS) {
            searchFocused = false;
            for (Group g : Group.values()) {
                if (mouseX >= tabStart[g.ordinal()] && mouseX < tabEnd[g.ordinal()] && button == 0) {
                    group = g;
                    listScroll = 0;
                }
            }
            return;
        }
        if (relative < WIN_HEADER + WIN_TABS + WIN_SEARCH) {
            searchFocused = button == 0;
            return;
        }
        searchFocused = false;
        List<HudModule> list = filtered();
        int rows = visibleRows(list.size());
        int index = (relative - WIN_HEADER - WIN_TABS - WIN_SEARCH) / WIN_ROW;
        if (index < 0 || index >= rows || listScroll + index >= list.size()) {
            return;
        }
        HudModule hud = list.get(listScroll + index);
        if (button == 1) {
            HudEditorState.toggleFavorite(hud.getName());
            flash(hud.getName() + (HudEditorState.isFavorite(hud.getName()) ? " added to favorites" : " removed from favorites"));
            return;
        }
        if (button != 0) {
            return;
        }
        boolean onSwitch = mouseX >= winX + WIN_W - Theme.PADDING - 22;
        if (onSwitch || !hud.isEnabled()) {
            hud.toggle();
            flash(hud.getName() + (hud.isEnabled() ? " on" : " off"));
            if (hud.isEnabled()) {
                select(hud);
            } else if (selected == hud) {
                closePopup();
                selected = null;
            }
        } else {
            select(hud);
        }
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (draggingWin) {
            winX = (int) click.x() - winDragX;
            winY = (int) click.y() - winDragY;
            return true;
        }
        if (draggingWidget) {
            for (SettingWidget widget : widgets) {
                widget.drag(click.x());
            }
            return true;
        }
        if (dragging != null) {
            int rawX = (int) click.x() - dragOffsetX;
            int rawY = (int) click.y() - dragOffsetY;
            if (shiftDown()) {
                snapper.reset();
                dragging.moveTo(rawX, rawY, width, height);
                return true;
            }
            List<HudSnapper.Box> others = new ArrayList<>();
            for (HudModule other : hudModules()) {
                if (other != dragging && visible(other)) {
                    others.add(new HudSnapper.Box(other.getX(), other.getY(), other.getWidth(), other.getHeight()));
                }
            }
            int[] snapped = snapper.snap(rawX, rawY, dragging.getWidth(), dragging.getHeight(), others, width, height);
            dragging.moveTo(snapped[0], snapped[1], width, height);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        draggingWin = false;
        if (draggingWidget) {
            widgets.forEach(SettingWidget::release);
            draggingWidget = false;
        }
        snapper.reset();
        HudEditorState.setWindow(winX, winY);
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int step = (int) Math.signum(verticalAmount);
        if (inWorld() && overPopup(mouseX, mouseY)) {
            popScroll = Math.max(0, popScroll - step * POP_ROW);
            return true;
        }
        if (overWindow(mouseX, mouseY)) {
            listScroll = Math.max(0, listScroll - step);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean charTyped(CharInput charInput) {
        if (!searchFocused) {
            return super.charTyped(charInput);
        }
        int codePoint = charInput.codepoint();
        if (codePoint >= 32 && codePoint < 127 && search.length() < 24) {
            search += new String(Character.toChars(codePoint));
            listScroll = 0;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
            } else if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) {
                    search = search.substring(0, search.length() - 1);
                    listScroll = 0;
                }
            } else if (key == GLFW.GLFW_KEY_V && controlDown()) {
                String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                if (clip != null) {
                    for (char c : clip.toCharArray()) {
                        if (c >= 32 && c < 127 && search.length() < 24) {
                            search += c;
                        }
                    }
                    listScroll = 0;
                }
            }
            return true;
        }

        SettingWidget focused = SettingWidget.getFocused();
        if (focused != null && focused.keyPressed(key)) {
            return true;
        }

        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (popupOpen) {
                closePopup();
            } else {
                close();
            }
            return true;
        }
        if (selected != null && visible(selected)) {
            int step = shiftDown() ? 10 : 1;
            int dx = 0;
            int dy = 0;
            switch (key) {
                case GLFW.GLFW_KEY_LEFT -> dx = -step;
                case GLFW.GLFW_KEY_RIGHT -> dx = step;
                case GLFW.GLFW_KEY_UP -> dy = -step;
                case GLFW.GLFW_KEY_DOWN -> dy = step;
                case GLFW.GLFW_KEY_R -> {
                    resetSelected();
                    return true;
                }
                default -> {
                    return super.keyPressed(input);
                }
            }
            selected.moveTo(selected.getX() + dx, selected.getY() + dy, width, height);
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void removed() {
        dragging = null;
        draggingWin = false;
        SettingWidget.releaseFocus();
        HudEditorState.setWindow(winX, winY);
        HudEditorState.save();
        StarGG.modules().get(HudEditorModule.class).setEnabled(false);
        StarGG.config().save();
    }
}
