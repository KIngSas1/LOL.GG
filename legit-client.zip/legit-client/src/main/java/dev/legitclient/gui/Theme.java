package dev.legitclient.gui;

import dev.legitclient.module.client.ClickGuiModule;
import dev.legitclient.util.Draw;

/** Colors and sizes of the click GUI. Tweak the look here. */
public final class Theme {

    public static final int PANEL_WIDTH = 120;
    public static final int HEADER_HEIGHT = 18;
    public static final int MODULE_HEIGHT = 16;
    public static final int PADDING = 6;

    public static final int HEADER = 0xFF0F0F14;
    public static final int ROW = 0xFF1B1B23;
    public static final int ROW_HOVER = 0xFF262630;
    public static final int SETTING_ROW = 0xFF14141A;
    public static final int SETTING_HOVER = 0xFF1C1C24;
    public static final int TRACK = 0xFF2C2C38;
    public static final int TEXT = 0xFFE8E8EE;
    public static final int TEXT_DIM = 0xFF8B8B99;

    private Theme() {
    }

    public static int accent() {
        return ClickGuiModule.accent();
    }

    /** Applies the user's panel opacity to a background color. */
    public static int bg(int color) {
        return Draw.withAlpha(color, ClickGuiModule.panelAlpha());
    }
}
