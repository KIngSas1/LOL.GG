package dev.legitclient.module.hud;

import dev.legitclient.LegitClient;
import dev.legitclient.gui.Theme;
import dev.legitclient.util.Draw;
import dev.legitclient.util.Icon;
import net.minecraft.client.gui.DrawContext;

/** STAR.GG watermark: "STAR" in white, ".GG" in the client theme color, then the version. */
public final class Watermark extends HudModule {

    private static final String STAR = "STAR";
    private static final String GG = ".GG";
    private static final String VERSION = " " + LegitClient.VERSION;

    public Watermark() {
        super("Watermark", "Shows the client name", 4, 4);
        icon(Icon.WATERMARK);
        enabledByDefault();
    }

    @Override
    protected int contentWidth() {
        return Draw.width(STAR) + Draw.width(GG) + Draw.width(VERSION);
    }

    @Override
    protected int contentHeight() {
        return Draw.TEXT_HEIGHT;
    }

    @Override
    protected void draw(DrawContext context, int x, int y) {
        int cursor = x;
        Draw.text(context, STAR, cursor, y, 0xFFFFFFFF, shadow.on());
        cursor += Draw.width(STAR);
        Draw.text(context, GG, cursor, y, Theme.accent(), shadow.on());
        cursor += Draw.width(GG);
        Draw.text(context, VERSION, cursor, y, textColor(), shadow.on());
    }
}
