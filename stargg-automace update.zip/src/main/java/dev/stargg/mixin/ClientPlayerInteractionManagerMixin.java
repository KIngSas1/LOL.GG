package dev.stargg.mixin;

import dev.stargg.StarGG;
import dev.stargg.module.utility.AutoElytra;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.ActionResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Dispatches local attack events to modules such as W-Tap. */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true, require = 0)
    private void stargg$beforeAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == client.player && StarGG.modules().onAttack(target)) {
            ci.cancel();
        }
    }
    @Inject(method = "interactItem", at = @At("HEAD"), require = 0)
    private void stargg$pearlThrown(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == client.player && player.getStackInHand(hand).isOf(Items.ENDER_PEARL)) {
            AutoElytra module = StarGG.modules().get(AutoElytra.class);
            if (module != null && module.isEnabled()) {
                module.onPearlThrow();
            }
        }
    }

}
