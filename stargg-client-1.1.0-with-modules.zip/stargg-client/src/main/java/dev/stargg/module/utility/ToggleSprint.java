package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.util.Icon;

/**
 * Holds the vanilla sprint key for you while you walk forward — the same thing
 * as the "Toggle Sprint" accessibility option, so all vanilla sprint rules still apply.
 */
public final class ToggleSprint extends Module {

    public ToggleSprint() {
        super("Toggle Sprint", "Sprints automatically while moving forward", Category.UTILITY);
        icon(Icon.SPRINT);
    }

    @Override
    public void onTick() {
        if (mc.currentScreen == null && mc.options.forwardKey.isPressed()) {
            mc.options.sprintKey.setPressed(true);
        }
    }

    @Override
    protected void onDisable() {
        mc.options.sprintKey.setPressed(false);
    }
}
