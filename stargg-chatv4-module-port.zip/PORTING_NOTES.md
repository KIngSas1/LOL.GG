# Chat V4 module port notes

This StarGG branch contains native Fabric implementations of six requested modules:

| Module | StarGG category | Main controls ported |
|---|---|---|
| Aim Assist | Combat | Simple/Adaptive mode, target filters, mouse requirement, strafe increase, block-break checks and item whitelist, vertical/horizontal speeds, max angle, distance, item limits, target area and priority |
| Triggerbot | Combat | Target filters, randomized extra-delay and mouse-over ranges, first-hit gate, mouse requirement, activation-click behavior, air crits, shield check, miss/early-hit chances, item limits |
| Shield Breaker | Utility | Swap delay, swap-back delay, double click, item whitelist, automatic axe swap and slot restoration |
| Auto Mace | Utility | Target filters, aim/silent aim, range, automatic attack, randomized extra delay, Elytra unequip/re-equip, smash-only, manual/auto mace selection, Density/Breach preference, Stun Slam and chance, item limits |
| Auto Pearl | Utility | Pearl cooldown, distance/angle limits, item limits, minimum health, On bind/Aggro mode, silent aim, aim speed and vertical check |
| Pearl Catch | Utility | Upward/Current aim, aim speed, silent aim and charge delay |

## Architecture changes

Chat V4 and StarGG use different Minecraft versions and different module/event systems. The original classes therefore could not be copied directly. The port uses StarGG's settings, module manager, Fabric/Yarn entity and inventory APIs, and its Central GUI.

Two reusable setting types were added:

- `MultiSelectSetting` persists a set of choices and is shown with a new multi-select GUI widget.
- `RandomRangeSetting` persists minimum/maximum endpoints and is shown with a two-slider GUI widget. Triggerbot and Auto Mace sample a random value from the configured range.

The port also adds shared item/target filtering, six module icon pairs, a silent outgoing-rotation manager and a player interaction mixin used by the slot-swap modules.

## Behavior notes

The settings and feature intent are represented, but this is a native port rather than a byte-for-byte or behavior-identical port. Some behavior is necessarily adapted to the current Fabric version:

- Aim Assist uses StarGG's per-tick target scan and smooth yaw/pitch steps. The target priority calculations approximate Chat V4's comparators.
- Triggerbot uses client-side crosshair targeting, local cooldown and health-change tracking. Timing and hit behavior can differ from Chat V4's custom attack-key/event pipeline.
- Auto Mace reads mace enchantment component text to identify Density/Breach levels because the Chat V4 enchantment wrappers do not exist in StarGG. The auto-selection score is an approximation, not the original fall/impact prediction engine.
- Auto Pearl predicts the nearest eligible enemy pearl's landing point with a local trajectory simulation. It does not recreate every Chat V4 pearl tracking/aim-lock helper.
- Pearl Catch ports the projectile-interception planning math and wraps it in StarGG's tick state machine, but actual packet timing and projectile physics remain version/server dependent.
- Shield Breaker and Auto Mace perform hotbar switching and restore the selected slot around their attacks. Server-side cancellation, cooldown, and knockback rules may vary by server.

## Build status

The project targets Minecraft 1.21.11, Yarn 1.21.11+build.4 and Java 21. Run `./gradlew build` from the project root with network access so Gradle can obtain the configured wrapper and Fabric/Minecraft dependencies. A successful build could not be confirmed in the current environment because the Gradle distribution download host was unreachable.
