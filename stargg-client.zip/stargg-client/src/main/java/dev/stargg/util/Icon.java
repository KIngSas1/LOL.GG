package dev.stargg.util;

import dev.stargg.StarGG;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * The icons shown in the click GUI. Each constant points at two textures in
 * {@code assets/stargg/textures/gui/icons/}: {@code <file>.png} (bright) and
 * {@code <file>_dim.png} (used while a module is off).
 *
 * <p>To add an icon: drop a 32x32 PNG pair there and add a constant here.
 */
public enum Icon {
    HUD("hud"),
    VISUAL("visual"),
    UTILITY("utility"),
    CLIENT("client"),

    WATERMARK("watermark"),
    FPS("fps"),
    CPS("cps"),
    PING("ping"),
    COORDINATES("coordinates"),
    COMPASS("compass"),
    CLOCK("clock"),
    KEYSTROKES("keystrokes"),
    ARMOR("armor"),
    POTION("potion"),
    LIST("list"),
    FULLBRIGHT("fullbright"),
    ZOOM("zoom"),
    HURT_CAM("hurtcam"),
    WEATHER("weather"),
    SPRINT("sprint"),
    CLICK_GUI("clickgui");

    private static final int TEXTURE_SIZE = 32;

    private final Identifier bright;
    private final Identifier dim;

    Icon(String file) {
        this.bright = Identifier.of(StarGG.MOD_ID, "textures/gui/icons/" + file + ".png");
        this.dim = Identifier.of(StarGG.MOD_ID, "textures/gui/icons/" + file + "_dim.png");
    }

    /** Draws the icon as a size x size square at (x, y). */
    public void draw(DrawContext context, int x, int y, int size, boolean isBright) {
        // The only texture-drawing call in the mod; if a Minecraft update changes it, fix it here.
        context.drawTexture(RenderPipelines.GUI_TEXTURED, isBright ? bright : dim,
                x, y, 0f, 0f, size, size, TEXTURE_SIZE, TEXTURE_SIZE, TEXTURE_SIZE, TEXTURE_SIZE);
    }
}
