package dev.stargg.util;

import dev.stargg.StarGG;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Opens/closes the embedded runtime's original Click GUI without recreating Echo features or settings. */
public final class EchoModuleBridge {

    private EchoModuleBridge() {
    }

    /** Called by the StarGG Client-panel action on the Minecraft client thread. */
    public static void openOriginalClickGui() {
        setOriginalClickGuiOpen(true);
    }

    /** Keeps the supplied profile's other values while preventing its saved GUI-open flag from opening on boot. */
    public static void closeOriginalClickGui() {
        setOriginalClickGuiOpen(false);
    }

    private static void setOriginalClickGuiOpen(boolean open) {
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                loader = EchoModuleBridge.class.getClassLoader();
            }

            Class<?> echoMain = Class.forName("hack.echo.o", true, loader);
            Field managerField = echoMain.getField("featureManager");
            Object manager = managerField.get(null);
            if (manager == null) {
                throw new IllegalStateException("Echo feature manager is not initialized yet");
            }

            Class<?> clickGuiType = Class.forName("hack.echo.gm", true, loader);
            Method lookup = manager.getClass().getMethod("getFeatureByClass", Class.class);
            Object clickGui = lookup.invoke(manager, clickGuiType);
            if (clickGui == null) {
                throw new IllegalStateException("Original Echo Click GUI module was not registered");
            }

            Method setEnabled = clickGui.getClass().getMethod("setEnabled", boolean.class);
            if (open) {
                // Re-arm it so the native Echo screen is opened even when it is already marked open.
                setEnabled.invoke(clickGui, false);
                setEnabled.invoke(clickGui, true);
            } else {
                setEnabled.invoke(clickGui, false);
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            StarGG.LOGGER.error("Could not {} the original Echo module GUI", open ? "open" : "close", exception);
        }
    }
}
