# Original Echo modules as native STAR.GG modules

The supplied `Ww.json` file contains 87 feature records, of which 15 are enabled. These 15 original feature instances are now exposed inside STAR.GG's own module manager and GUI. They are not launched through Echo's separate click GUI and are not replacement implementations.

## Selected modules and categories

| STAR.GG category | Native module entry | Original Echo class |
|---|---|---|
| Combat | Aim Assist | `hack.echo.a2` |
| Combat | Auto Mace | `hack.echo.ac` |
| Combat | Mace Swap | `hack.echo.gA` |
| Combat | Spear Assist | `hack.echo.ce` |
| Combat | Spear Lunge | `hack.echo.ha` |
| Combat | Spear Reach | `hack.echo.eI` |
| Combat | Trigger Bot | `hack.echo.b_` |
| Movement | Jump Reset | `hack.echo.aW` |
| Movement | Move Fix | `hack.echo.bO` |
| Movement | No Jump Delay | `hack.echo.cv` |
| Movement | Sprint | `hack.echo.dg` |
| Utility | Pot Refill | `hack.echo.aQ` |
| Client | Capes | `hack.echo.g0` |
| Client | Echo Click GUI | `hack.echo.gm` |
| Client | Targets | `hack.echo.aP` |

The selected classes' original Echo categories are mapped into the closest STAR.GG panel. Echo `INTERNALS` maps to STAR.GG `Client`; therefore, Capes, Echo Click GUI, and Targets appear under Client. There are no selected Echo modules whose original category is `RENDER`, so no selected entry is placed in STAR.GG `Visual`.

## How native registration works

`EchoNativeModule` extends STAR.GG's real `Module` base class. Its instance wraps the exact feature object retrieved from Echo's own feature manager. STAR.GG's `ModuleManager` registers it like a normal module, and the existing Frames/Central GUIs create their normal module rows/cards from `ModuleManager.inCategory(...)`.

The adapter does not implement Aim Assist, mace behavior, spear behavior, targeting, or any other feature logic. `onEnable` and `onDisable` call the original Echo feature's `setEnabled`; its original event handlers continue to run in Echo's event system.

## Original settings surfaced natively

The adapter maps all setting objects used by the selected feature classes:

- `eK` → native Boolean setting.
- `ai` → native Number slider with original minimum, maximum, increment, and suffix-independent value.
- `bW` → native integer Number slider.
- `gF` → native min/max Random Range slider.
- `fm` → native Mode selector.
- `gM` → native multi-select for each original boolean option.
- `fR` → native paged multi-select for all registry-backed item options; selected registry IDs are written back to Echo.
- `cJ` → native key capture control.

Visibility predicates and live values are read from the original settings. Changes made in the STAR.GG UI are sent directly to the existing Echo setting objects. All Echo settings are retained; unknown types cause integration to fail rather than silently omitting an option.

Each module also has STAR.GG's ordinary module keybind control. Echo's parallel feature key polling is disabled after its original bind is transferred to STAR.GG, preventing duplicate key toggles. The separate `Echo Click GUI` display name avoids colliding with STAR.GG's own `Click GUI` module.

## Profile and startup order

The bundled `echo/Ww.json` is restored through Echo's profile manager. Once that manager has accepted the profile, STAR.GG constructs the 15 adapters, registers them, and loads STAR.GG's own config so previously saved STAR.GG values remain authoritative. The native GUI is therefore populated before the player can open it after normal startup.

## Build status

The full Gradle/Loom build was not completed in the working environment because `gradlew` could not resolve `services.gradle.org` while trying to download Gradle 9.2.0. The adapter source was separately syntax-checked against a focused stub harness, but that does not replace a full Minecraft/Fabric compile or in-game test. Use JDK 21 and run `gradlew.bat build` with Gradle distribution access to finish verification.
