package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.module.client.ClickGuiModule;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/**
 * The main menu panel: logo + gear, one row per category (tap to open/close its panel), a MISC
 * section with the HUD editor and profile shortcuts, and a footer with a hint.
 */
final class MainPanel implements GuiPanel {

    private static final String TITLE_STAR = "STAR";
    private static final String TITLE_GG = ".GG";
    private static final String HINT = "Right-click: settings";
    private static final int HEADER_H = 26;
    private static final int ROW_H = 22;
    private static final int MISC_H = 14;
    private static final int FOOTER_H = 20;

    private final List<Panel> panels;
    private final Runnable openSettings;
    private final Runnable openHudEditor;
    private final Runnable openProfiles;
    private final float[] rowAnimation;

    private int x;
    private int y;
    private int scroll;
    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    MainPanel(List<Panel> panels, int defaultX, int defaultY, Runnable openSettings, Runnable openHudEditor, Runnable openProfiles) {
        this.panels = panels;
        this.openSettings = openSettings;
        this.openHudEditor = openHudEditor;
        this.openProfiles = openProfiles;
        this.rowAnimation = new float[panels.size()];
        int[] saved = StarGG.config().getPanelPosition("Main");
        this.x = saved != null ? saved[0] : defaultX;
        this.y = saved != null ? saved[1] : defaultY;
    }

    @Override
    public void setScroll(int scroll) {
        this.scroll = scroll;
    }

    private int top() {
        return y - scroll;
    }

    private int height() {
        return HEADER_H + ROW_H * panels.size() + MISC_H + ROW_H * 2 + FOOTER_H;
    }

    @Override
    public int bottom() {
        return y + height();
    }

    // ------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY) {
        int w = Theme.PANEL_WIDTH;
        int top = top();
        // header: logo, name, gear
        Draw.rect(context, x, top, w, HEADER_H, Theme.bg(Theme.HEADER));
        Ui.icon(context, Ui.Tex.LOGO, x + Theme.PADDING, top + (HEADER_H - Ui.Tex.LOGO.size) / 2, Theme.TEXT_BRIGHT);
        int titleX = x + Theme.PADDING + 17;
        int titleY = Ui.middleY(top, HEADER_H);
        Ui.textBold(context, TITLE_STAR, titleX, titleY, Theme.TEXT_BRIGHT);
        Ui.textBold(context, TITLE_GG, titleX + Ui.widthBold(TITLE_STAR), titleY, Theme.accent());
        boolean gearHover = Draw.inside(mouseX, mouseY, x + w - 26, top, 26, HEADER_H);
        Ui.icon(context, Ui.Tex.GEAR, x + w - Theme.PADDING - 10, top + (HEADER_H - 10) / 2, gearHover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);

        // category rows
        int cursor = top + HEADER_H;
        for (int i = 0; i < panels.size(); i++) {
            Panel panel = panels.get(i);
            boolean hovered = Draw.inside(mouseX, mouseY, x, cursor, w, ROW_H);
            rowAnimation[i] = Theme.approach(rowAnimation[i], panel.isShown() ? 1f : 0f);
            Draw.rect(context, x, cursor, w, ROW_H, Theme.bg(hovered ? Theme.ROW_HOVER : Theme.ROW));
            int color = Draw.blend(hovered ? Theme.TEXT : Theme.TEXT_DIM, Theme.accent(), rowAnimation[i]);
            Ui.icon(context, panel.category().tex(), x + Theme.PADDING, cursor + (ROW_H - 10) / 2, color);
            Ui.textMiddle(context, panel.category().title(), x + Theme.PADDING + 17, cursor, ROW_H, color);
            Ui.icon(context, Ui.Tex.CHEVRON_RIGHT, x + w - Theme.PADDING - 6, cursor + (ROW_H - 6) / 2, color);
            cursor += ROW_H;
        }

        // MISC section
        Draw.rect(context, x, cursor, w, MISC_H, Theme.bg(Theme.DIVIDER));
        Ui.textMiddle(context, "MISC", x + Theme.PADDING, cursor, MISC_H, Theme.TEXT_FAINT);
        cursor += MISC_H;

        boolean editorHover = Draw.inside(mouseX, mouseY, x, cursor, w, ROW_H);
        Draw.rect(context, x, cursor, w, ROW_H, Theme.bg(editorHover ? Theme.ROW_HOVER : Theme.ROW));
        int editorColor = editorHover ? Theme.TEXT : Theme.TEXT_DIM;
        Ui.textMiddle(context, "HUD Editor", x + Theme.PADDING, cursor, ROW_H, editorColor);
        Ui.icon(context, Ui.Tex.CHEVRON_RIGHT, x + w - Theme.PADDING - 6, cursor + (ROW_H - 6) / 2, editorColor);
        cursor += ROW_H;

        boolean profilesHover = Draw.inside(mouseX, mouseY, x, cursor, w, ROW_H);
        Draw.rect(context, x, cursor, w, ROW_H, Theme.bg(profilesHover ? Theme.ROW_HOVER : Theme.ROW));
        int profilesColor = profilesHover ? Theme.TEXT : Theme.TEXT_DIM;
        Ui.textMiddle(context, "Profiles", x + Theme.PADDING, cursor, ROW_H, profilesColor);
        Ui.icon(context, Ui.Tex.CHEVRON_RIGHT, x + w - Theme.PADDING - 6, cursor + (ROW_H - 6) / 2, profilesColor);
        // the profile badge only gets the space the label and chevron leave over
        int labelEnd = x + Theme.PADDING + Ui.width("Profiles") + 8;
        int badgeRight = x + w - Theme.PADDING - 6 - 6;
        int maxBadgeText = Math.max(12, badgeRight - labelEnd - 10);
        String profile = Ui.trim(ClickGuiModule.profileName(), maxBadgeText);
        int badgeW = Ui.width(profile) + 10;
        int badgeX = badgeRight - badgeW;
        Ui.roundRect(context, badgeX, cursor + 4, badgeW, ROW_H - 8, 2, Theme.bg(Theme.BADGE));
        Ui.textCentered(context, profile, badgeX, cursor, badgeW, ROW_H, Theme.TEXT_DIM);
        cursor += ROW_H;

        // footer hint
        Draw.rect(context, x, cursor, w, FOOTER_H, Theme.bg(Theme.HEADER));
        Ui.textMiddle(context, Ui.trim(HINT, w - Theme.PADDING * 2), x + Theme.PADDING, cursor, FOOTER_H, Theme.TEXT_FAINT);
    }

    // ----------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int w = Theme.PANEL_WIDTH;
        int top = top();
        if (!Draw.inside(mouseX, mouseY, x, top, w, height())) {
            return false;
        }
        int relative = (int) mouseY - top;

        if (relative < HEADER_H) {
            if (button == 0 && mouseX >= x + w - 26) {
                openSettings.run();
            } else if (button == 0) {
                startDrag(mouseX, mouseY);
            }
            return true;
        }
        relative -= HEADER_H;

        if (relative < ROW_H * panels.size()) {
            if (button == 0 || button == 1) {
                panels.get(relative / ROW_H).toggleShown();
            }
            return true;
        }
        relative -= ROW_H * panels.size();

        if (relative < MISC_H) {
            if (button == 0) {
                startDrag(mouseX, mouseY);
            }
            return true;
        }
        relative -= MISC_H;

        if (relative < ROW_H) {
            if (button == 0) {
                openHudEditor.run();
            }
            return true;
        }
        relative -= ROW_H;

        if (relative < ROW_H) {
            if (button == 0) {
                openProfiles.run();
            }
            return true;
        }

        return true;
    }

    private void startDrag(double mouseX, double mouseY) {
        dragging = true;
        dragOffsetX = (int) mouseX - x;
        dragOffsetY = (int) mouseY - top();
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY) {
        if (dragging) {
            x = Math.max(0, (int) mouseX - dragOffsetX);
            y = Math.max(0, (int) mouseY - dragOffsetY + scroll);
        }
    }

    @Override
    public void mouseReleased() {
        if (dragging) {
            dragging = false;
            StarGG.config().setPanelPosition("Main", x, y);
        }
    }
}
