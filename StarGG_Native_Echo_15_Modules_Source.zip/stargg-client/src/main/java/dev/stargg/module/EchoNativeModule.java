package dev.stargg.module;

import dev.stargg.StarGG;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.KeySetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.setting.Setting;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * A STAR.GG-native module entry backed by one of Echo's original feature instances.
 *
 * <p>The feature's implementation remains in the original Echo runtime. This class does not
 * recreate its combat/movement logic: it exposes that real feature through STAR.GG's module
 * manager, category cards, bind handling, persistence and setting widgets. Every option is
 * bound bidirectionally to its original Echo setting object.</p>
 */
public final class EchoNativeModule extends Module {

    private final Object echoFeature;
    private final String originalClassName;
    private final List<SettingBinding> bindings = new ArrayList<>();

    public EchoNativeModule(Object echoFeature, String displayName, Category category) {
        super(displayName, readDescription(echoFeature), category);
        this.echoFeature = echoFeature;
        this.originalClassName = echoFeature.getClass().getName();

        int originalKey = readInt(echoFeature, "getKey", -1);
        defaultBind(originalKey, BindMode.TOGGLE);

        if (readBoolean(echoFeature, "isEnabled", false)) {
            enabledByDefault();
        }

        initializeNativeSettings();
    }

    private void initializeNativeSettings() {
        try {
            // Echo calls initSettings during feature registration. Calling it again is safe and
            // guarantees its public settings list reflects the fields of the real feature class.
            invoke(echoFeature, "initSettings");
            Field settingsField = echoFeature.getClass().getField("settings");
            Object value = settingsField.get(echoFeature);
            if (!(value instanceof Iterable<?> originalSettings)) {
                throw new IllegalStateException("Echo feature did not expose its native settings list");
            }

            for (Object originalSetting : originalSettings) {
                SettingBinding binding = createBinding(originalSetting);
                bindings.add(binding);
                addUnchecked(binding.nativeSetting);
            }
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Could not read settings for " + originalClassName, exception);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void addUnchecked(Setting<?> setting) {
        add((Setting) setting);
    }

    private SettingBinding createBinding(Object original) {
        String type = original.getClass().getSimpleName();
        String name = readString(original, "getName", type);
        Setting<?> nativeSetting;
        SyncKind kind;
        Map<String, Object> registryIds = Map.of();

        switch (type) {
            case "eK" -> {
                BooleanSetting setting = new BooleanSetting(name, readBoolean(original, "getValue", false));
                setting.setChangeListener(value -> invokeSetting(original, "setValue", value));
                nativeSetting = setting;
                kind = SyncKind.BOOLEAN;
            }
            case "ai" -> {
                double current = readNumber(original, "getValue", 0.0);
                double min = readNumber(original, "getMinValue", 0.0);
                double max = readNumber(original, "getMaxValue", 100.0);
                double step = readNumber(original, "getIncrement", 1.0);
                NumberSetting setting = new NumberSetting(name, current, min, max, step);
                setting.setSuffix(readString(original, "getSuffix", ""));
                setting.setChangeListener(value -> invokeSetting(original, "setValue", value.floatValue()));
                nativeSetting = setting;
                kind = SyncKind.FLOAT;
            }
            case "bW" -> {
                double current = readNumber(original, "getValue", 0.0);
                double min = readNumber(original, "getMinValue", 0.0);
                double max = readNumber(original, "getMaxValue", 100.0);
                NumberSetting setting = new NumberSetting(name, current, min, max, 1.0);
                setting.setSuffix(readString(original, "getSuffix", ""));
                setting.setChangeListener(value -> invokeSetting(original, "setValue", value.intValue()));
                nativeSetting = setting;
                kind = SyncKind.INTEGER;
            }
            case "gF" -> {
                double currentMin = readNumber(original, "getMinValue", 0.0);
                double currentMax = readNumber(original, "getMaxValue", currentMin);
                double allowedMin = readNumber(original, "getLowerBound", currentMin);
                double allowedMax = readNumber(original, "getUpperBound", currentMax);
                double step = readNumber(original, "getIncrement", 1.0);
                RandomRangeSetting setting = new RandomRangeSetting(
                        name, currentMin, currentMax, allowedMin, allowedMax, step);
                setting.setSuffix(readString(original, "getSuffix", ""));
                setting.setChangeListener(range -> {
                    invokeSetting(original, "setMinValue", (float) range.min());
                    invokeSetting(original, "setMaxValue", (float) range.max());
                });
                nativeSetting = setting;
                kind = SyncKind.RANGE;
            }
            case "fm" -> {
                List<String> modes = readModes(original);
                String current = readString(original, "getValue", modes.isEmpty() ? "" : modes.get(0));
                if (!modes.contains(current)) {
                    modes.add(current);
                }
                ModeSetting setting = new ModeSetting(name, current, modes.toArray(String[]::new));
                setting.setChangeListener(value -> invokeSetting(original, "setValue", (CharSequence) value));
                nativeSetting = setting;
                kind = SyncKind.MODE;
            }
            case "gM" -> {
                Map<String, Boolean> options = readBooleanOptions(original);
                String[] names = options.keySet().toArray(String[]::new);
                String[] selected = options.entrySet().stream()
                        .filter(Map.Entry::getValue)
                        .map(Map.Entry::getKey)
                        .toArray(String[]::new);
                MultiSelectSetting setting = new MultiSelectSetting(name, names, selected);
                setting.setChangeListener(values -> {
                    Map<String, Boolean> currentOptions = readBooleanOptions(original);
                    for (String option : currentOptions.keySet()) {
                        invokeSetting(original, "setOption", (CharSequence) option, values.contains(option));
                    }
                });
                nativeSetting = setting;
                kind = SyncKind.BOOLEAN_OPTIONS;
            }
            case "fR" -> {
                RegistryOptions registryOptions = readRegistryOptions(original);
                registryIds = registryOptions.idsByLabel;
                String[] options = registryOptions.labels.toArray(String[]::new);
                String[] selected = registryOptions.selectedLabels.toArray(String[]::new);
                MultiSelectSetting setting = new MultiSelectSetting(name, options, selected);
                Map<String, Object> ids = registryIds;
                setting.setChangeListener(values -> {
                    LinkedHashSet<Object> selectedIds = new LinkedHashSet<>();
                    for (String label : values) {
                        Object id = ids.get(label);
                        if (id != null) {
                            selectedIds.add(id);
                        }
                    }
                    invokeSetting(original, "setSelectedIds", selectedIds);
                });
                nativeSetting = setting;
                kind = SyncKind.REGISTRY_OPTIONS;
            }
            case "cJ" -> {
                KeySetting setting = new KeySetting(name, readInt(original, "getKey", -1));
                setting.setChangeListener(value -> invokeSetting(original, "setKey", value));
                nativeSetting = setting;
                kind = SyncKind.KEY;
            }
            default -> throw new IllegalStateException("Unsupported original Echo setting type " + type
                    + " in " + originalClassName + "; refusing to omit or replace this option");
        }

        nativeSetting.showWhen(() -> readBoolean(original, "isVisible", true));
        return new SettingBinding(original, nativeSetting, kind, registryIds);
    }

    private void syncFromEcho() {
        synchronizeEnabledState(readBoolean(echoFeature, "isEnabled", isEnabled()));
        for (SettingBinding binding : bindings) {
            Object original = binding.original;
            try {
                switch (binding.kind) {
                    case BOOLEAN -> ((BooleanSetting) binding.nativeSetting)
                            .setSilently(readBoolean(original, "getValue", false));
                    case FLOAT -> {
                        NumberSetting setting = (NumberSetting) binding.nativeSetting;
                        setting.setBoundsSilently(readNumber(original, "getMinValue", setting.getMin()),
                                readNumber(original, "getMaxValue", setting.getMax()),
                                readNumber(original, "getIncrement", 1.0));
                        setting.setValueSilently(readNumber(original, "getValue", setting.getDouble()));
                    }
                    case INTEGER -> {
                        NumberSetting setting = (NumberSetting) binding.nativeSetting;
                        setting.setBoundsSilently(readNumber(original, "getMinValue", setting.getMin()),
                                readNumber(original, "getMaxValue", setting.getMax()), 1.0);
                        setting.setValueSilently(readNumber(original, "getValue", setting.getDouble()));
                    }
                    case RANGE -> {
                        RandomRangeSetting setting = (RandomRangeSetting) binding.nativeSetting;
                        setting.setAllowedBoundsSilently(readNumber(original, "getLowerBound", setting.getMinAllowed()),
                                readNumber(original, "getUpperBound", setting.getMaxAllowed()),
                                readNumber(original, "getIncrement", 1.0),
                                readNumber(original, "getMinValue", setting.getMinimum()),
                                readNumber(original, "getMaxValue", setting.getMaximum()));
                    }
                    case MODE -> {
                        ModeSetting setting = (ModeSetting) binding.nativeSetting;
                        List<String> modes = readModes(original);
                        String current = readString(original, "getValue", setting.get());
                        setting.setModesSilently(modes, current);
                    }
                    case BOOLEAN_OPTIONS -> {
                        MultiSelectSetting setting = (MultiSelectSetting) binding.nativeSetting;
                        Map<String, Boolean> options = readBooleanOptions(original);
                        LinkedHashSet<String> selected = new LinkedHashSet<>();
                        options.forEach((option, enabled) -> {
                            if (enabled) selected.add(option);
                        });
                        List<String> nextOptions = new ArrayList<>(options.keySet());
                        if (!setting.getOptions().equals(nextOptions)) {
                            setting.setOptionsSilently(nextOptions, selected);
                        } else {
                            setting.setSilently(Collections.unmodifiableSet(selected));
                        }
                    }
                    case REGISTRY_OPTIONS -> {
                        Object selectedValue = invoke(original, "getSelectedIds");
                        Set<?> selectedIds = selectedValue instanceof Set<?> set ? set : Set.of();
                        LinkedHashSet<String> selectedLabels = new LinkedHashSet<>();
                        binding.registryIds.forEach((label, id) -> {
                            if (selectedIds.contains(id)) selectedLabels.add(label);
                        });
                        MultiSelectSetting setting = (MultiSelectSetting) binding.nativeSetting;
                        setting.setSilently(Collections.unmodifiableSet(selectedLabels));
                    }
                    case KEY -> ((KeySetting) binding.nativeSetting)
                            .setSilently(readInt(original, "getKey", -1));
                }
            } catch (RuntimeException exception) {
                if (!binding.warned) {
                    binding.warned = true;
                    StarGG.LOGGER.warn("Could not synchronize Echo setting '{}' on '{}'",
                            readString(original, "getName", "?"), getName(), exception);
                }
            }
        }
    }

    /** STAR.GG owns key polling for the native module entry; disable Echo's parallel poll. */
    public void deactivateOriginalKeyPolling() {
        if (getKey() > 0) {
            invoke(echoFeature, "setKey", -1);
        }
    }

    @Override
    public void onManagerTick() {
        syncFromEcho();
    }

    @Override
    protected void onEnable() {
        invoke(echoFeature, "setEnabled", true);
    }

    @Override
    protected void onDisable() {
        invoke(echoFeature, "setEnabled", false);
    }

    /** The original Echo event handlers continue to execute in their own event bus. */

    private static String readDescription(Object target) {
        return readString(target, "getDescription", "Original Echo feature");
    }

    private static boolean readBoolean(Object target, String method, boolean fallback) {
        Object value = invoke(target, method);
        return value instanceof Boolean bool ? bool : fallback;
    }

    private static int readInt(Object target, String method, int fallback) {
        Object value = invoke(target, method);
        return value instanceof Number number ? number.intValue() : fallback;
    }

    private static double readNumber(Object target, String method, double fallback) {
        Object value = invoke(target, method);
        return value instanceof Number number ? number.doubleValue() : fallback;
    }

    private static String readString(Object target, String method, String fallback) {
        Object value = invoke(target, method);
        return value == null ? fallback : value.toString();
    }

    private static List<String> readModes(Object target) {
        Object value = invoke(target, "getModes");
        List<String> result = new ArrayList<>();
        if (value instanceof Iterable<?> iterable) {
            for (Object mode : iterable) {
                if (mode != null) result.add(mode.toString());
            }
        }
        return result;
    }

    private static Map<String, Boolean> readBooleanOptions(Object target) {
        Object value = invoke(target, "getOptionsView");
        if (!(value instanceof Map<?, ?> map)) {
            throw new IllegalStateException("Echo multi-option setting did not expose its option map");
        }
        Map<String, Boolean> result = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            result.put(String.valueOf(entry.getKey()), Boolean.TRUE.equals(entry.getValue()));
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private static RegistryOptions readRegistryOptions(Object target) {
        Object registryValue = invoke(target, "getRegistry");
        if (!(registryValue instanceof Registry<?> registry)) {
            throw new IllegalStateException("Echo registry option list is unavailable for " + target.getClass().getName());
        }
        Object selectedValue = invoke(target, "getSelectedIds");
        Set<?> selectedIds = selectedValue instanceof Set<?> set ? set : Set.of();
        Object nameProviderValue = invoke(target, "getNameProvider");
        Function<Object, String> nameProvider = nameProviderValue instanceof Function<?, ?> function
                ? value -> String.valueOf(((Function<Object, ?>) function).apply(value))
                : Object::toString;

        List<String> labels = new ArrayList<>();
        List<String> selected = new ArrayList<>();
        Map<String, Object> idsByLabel = new LinkedHashMap<>();
        for (Identifier id : registry.getIds()) {
            if (id == null) continue;
            String idText = id.toString();
            Object entry = registry.get(id);
            String display = entry == null ? idText : safeApply(nameProvider, entry, idText);
            String label = display + " [" + idText + "]";
            if (idsByLabel.putIfAbsent(label, id) == null) {
                labels.add(label);
                if (selectedIds.contains(id)) selected.add(label);
            }
        }
        if (labels.isEmpty()) {
            throw new IllegalStateException("Echo registry option list was empty for " + target.getClass().getName());
        }
        return new RegistryOptions(labels, selected, idsByLabel);
    }

    private static String safeApply(Function<Object, String> provider, Object value, String fallback) {
        try {
            String name = provider.apply(value);
            return name == null || name.isBlank() ? fallback : name;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static void invokeSetting(Object target, String method, Object... arguments) {
        try {
            invokeRequired(target, method, arguments);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            StarGG.LOGGER.error("Could not update original Echo option '{}'", method, exception);
        }
    }

    private static Object invoke(Object target, String method, Object... arguments) {
        try {
            return invokeRequired(target, method, arguments);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }

    private static Object invokeRequired(Object target, String methodName, Object... arguments)
            throws ReflectiveOperationException {
        if (target == null) {
            throw new IllegalStateException("Cannot invoke " + methodName + " on a null Echo object");
        }
        Method selected = null;
        for (Method method : target.getClass().getMethods()) {
            if (!method.getName().equals(methodName) || method.getParameterCount() != arguments.length) {
                continue;
            }
            if (compatible(method.getParameterTypes(), arguments)) {
                selected = method;
                break;
            }
        }
        if (selected == null) {
            for (Class<?> type = target.getClass(); type != null; type = type.getSuperclass()) {
                for (Method method : type.getDeclaredMethods()) {
                    if (!method.getName().equals(methodName) || method.getParameterCount() != arguments.length) {
                        continue;
                    }
                    if (compatible(method.getParameterTypes(), arguments)) {
                        method.setAccessible(true);
                        selected = method;
                        break;
                    }
                }
                if (selected != null) break;
            }
        }
        if (selected == null) {
            throw new NoSuchMethodException(target.getClass().getName() + "." + methodName);
        }
        return selected.invoke(target, arguments);
    }

    private static boolean compatible(Class<?>[] parameters, Object[] arguments) {
        for (int i = 0; i < parameters.length; i++) {
            Object argument = arguments[i];
            if (argument == null) {
                if (parameters[i].isPrimitive()) return false;
                continue;
            }
            Class<?> expected = wrap(parameters[i]);
            if (expected.isInstance(argument)) continue;
            if (Number.class.isAssignableFrom(expected) && argument instanceof Number) continue;
            if (expected == CharSequence.class && argument instanceof CharSequence) continue;
            if (expected == Collection.class && argument instanceof Collection<?>) continue;
            if (expected.isAssignableFrom(argument.getClass())) continue;
            return false;
        }
        return true;
    }

    private static Class<?> wrap(Class<?> type) {
        if (!type.isPrimitive()) return type;
        if (type == boolean.class) return Boolean.class;
        if (type == byte.class) return Byte.class;
        if (type == short.class) return Short.class;
        if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class;
        if (type == float.class) return Float.class;
        if (type == double.class) return Double.class;
        if (type == char.class) return Character.class;
        return type;
    }

    private enum SyncKind {
        BOOLEAN, FLOAT, INTEGER, RANGE, MODE, BOOLEAN_OPTIONS, REGISTRY_OPTIONS, KEY
    }

    private static final class SettingBinding {
        private final Object original;
        private final Setting<?> nativeSetting;
        private final SyncKind kind;
        private Map<String, Object> registryIds;
        private boolean warned;

        private SettingBinding(Object original, Setting<?> nativeSetting, SyncKind kind,
                               Map<String, Object> registryIds) {
            this.original = original;
            this.nativeSetting = nativeSetting;
            this.kind = kind;
            this.registryIds = registryIds;
        }

        private void replaceRegistryIds(Map<String, Object> next) {
            registryIds.clear();
            registryIds.putAll(next);
        }
    }

    private record RegistryOptions(List<String> labels, List<String> selectedLabels,
                                   Map<String, Object> idsByLabel) {
    }
}
