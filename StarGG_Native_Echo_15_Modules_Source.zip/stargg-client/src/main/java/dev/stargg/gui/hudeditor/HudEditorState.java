package dev.stargg.gui.hudeditor;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.stargg.StarGG;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

/** Remembers the favourite HUD elements and where the editor's element window was left. */
public final class HudEditorState {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("stargg").resolve("hud_editor.json");

    private static final Set<String> FAVORITES = new LinkedHashSet<>();
    private static int windowX = 8;
    private static int windowY = 28;
    private static boolean loaded;

    private HudEditorState() {
    }

    private static void ensureLoaded() {
        if (loaded) {
            return;
        }
        loaded = true;
        try {
            if (Files.exists(FILE)) {
                JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
                if (root.has("favorites")) {
                    for (JsonElement e : root.getAsJsonArray("favorites")) {
                        FAVORITES.add(e.getAsString());
                    }
                }
                windowX = root.has("x") ? root.get("x").getAsInt() : windowX;
                windowY = root.has("y") ? root.get("y").getAsInt() : windowY;
            }
        } catch (Exception e) {
            StarGG.LOGGER.warn("Could not read hud_editor.json: {}", e.toString());
        }
    }

    public static void save() {
        ensureLoaded();
        try {
            JsonObject root = new JsonObject();
            JsonArray favorites = new JsonArray();
            FAVORITES.forEach(favorites::add);
            root.add("favorites", favorites);
            root.addProperty("x", windowX);
            root.addProperty("y", windowY);
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(root));
        } catch (Exception e) {
            StarGG.LOGGER.warn("Could not write hud_editor.json: {}", e.toString());
        }
    }

    public static boolean isFavorite(String module) {
        ensureLoaded();
        return FAVORITES.contains(module);
    }

    public static void toggleFavorite(String module) {
        ensureLoaded();
        if (!FAVORITES.remove(module)) {
            FAVORITES.add(module);
        }
        save();
    }

    public static int windowX() {
        ensureLoaded();
        return windowX;
    }

    public static int windowY() {
        ensureLoaded();
        return windowY;
    }

    public static void setWindow(int x, int y) {
        ensureLoaded();
        windowX = x;
        windowY = y;
    }
}
