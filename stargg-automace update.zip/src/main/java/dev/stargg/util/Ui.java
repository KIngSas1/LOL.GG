package dev.stargg.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.stargg.StarGG;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Text, icon and rounded-shape helpers for the click GUI only (the HUD keeps using {@link Draw}).
 *
 * <p>Everything here is resolution aware: fonts ({@code font/ui_<scale>.json}), icons and rounded corners
 * ({@code textures/gui/ui/*_<pixels>.png}) exist once per GUI scale, so each texel lands on exactly one screen
 * pixel. That is what keeps them crisp instead of pixelated. Scales above {@link #MAX_SCALE} use the largest set.
 */
public final class Ui {

    public static final int TEXT_HEIGHT = 9;
    /** Cap height of the client font in GUI units; the baseline always sits 7 units below the text origin. */
    public static final int CAP_HEIGHT = 7;
    /** Cap height (rounded) of the larger title font, used for the logo wordmark. The baseline is still 7 below the origin. */
    public static final int TITLE_CAP_HEIGHT = 9;
    public static final int MAX_SCALE = 6;

    // If a Minecraft update changes Style#withFont, fix it here (older versions took an Identifier directly).
    private static final Style[] REGULAR = new Style[MAX_SCALE + 1];
    private static final Style[] BOLD = new Style[MAX_SCALE + 1];
    private static final Style[] TITLE = new Style[MAX_SCALE + 1];
    private static final Identifier[][] CORNERS = new Identifier[6][MAX_SCALE + 1];

    static {
        for (int s = 1; s <= MAX_SCALE; s++) {
            REGULAR[s] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(StarGG.MOD_ID, "ui_bold_" + s)));
            BOLD[s] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(StarGG.MOD_ID, "ui_bold_" + s)));
            TITLE[s] = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of(StarGG.MOD_ID, "ui_title_" + s)));
            for (int r = 1; r <= 5; r++) {
                CORNERS[r][s] = Identifier.of(StarGG.MOD_ID, "textures/gui/ui/corner_" + r + "_" + s + ".png");
            }
        }
    }

    /** Icons, each with its fixed size in GUI units. */
    public enum Tex {
        LOGO("logo", 12),
        SEARCH("search", 10),
        DOTS("dots", 12),
        GEAR("gear", 10),
        CHEVRON_RIGHT("chevron_right", 6),
        CHEVRON_UP("chevron_up", 8),
        CHEVRON_DOWN("chevron_down", 8),
        CAT_HUD("cat_hud", 10),
        CAT_COMBAT("cat_combat", 10),
        CAT_MOVEMENT("cat_movement", 10),
        CAT_VISUAL("cat_visual", 10),
        CAT_UTILITY("cat_utility", 10),
        CAT_CLIENT("cat_client", 10),
        // navigation icons of the Central GUI (drawn for this project, one PNG per GUI scale)
        HOME("home", 12),
        ADD_WINDOW("add_window", 12),
        CODE("code", 12),
        REFRESH("refresh", 12),
        CLOSE("close", 12);

        public final int size;
        private final Identifier[] byScale = new Identifier[MAX_SCALE + 1];

        Tex(String file, int size) {
            this.size = size;
            for (int s = 1; s <= MAX_SCALE; s++) {
                byScale[s] = Identifier.of(StarGG.MOD_ID, "textures/gui/ui/" + file + "_" + (size * s) + ".png");
            }
        }
    }

    private Ui() {
    }

    private static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    /** The current GUI scale factor, clamped to the range the textures/fonts were generated for. */
    public static int scale() {
        int s = (int) Math.round(mc().getWindow().getScaleFactor());
        return Math.max(1, Math.min(MAX_SCALE, s));
    }

    // ---------------------------------------------------------------- glyph atlas text
    //
    // The old TTF font path made vanilla bake the glyphs into a single-channel atlas. On some renderers
    // (mobile launchers) that atlas is sampled with its alpha applied twice, which shows up as a dark,
    // thin outline around every letter and makes light text look dim. All GUI/HUD text is therefore drawn
    // from our own pre-rendered glyph sheets (textures/gui/font/<face>_<scale>.png): plain white RGBA
    // with straight alpha, tinted by the text color exactly like the icons. Every glyph lands on whole
    // screen pixels, so it stays crisp. The face is Proxima Nova Semibold (the "small bold" look).
    // Characters that are not on the sheets (CJK, emoji, ...) fall back to the TTF fonts below.

    private static final int FACE_UI = 0;
    private static final int FACE_TITLE = 1;
    private static final String[] FACE_NAMES = {"ui", "title"};

    private static final class Atlas {
        final Identifier texture;
        final int texW;
        final int texH;
        final float[][] low = new float[256][];
        final Map<Integer, float[]> high = new HashMap<>();

        Atlas(Identifier texture, int texW, int texH) {
            this.texture = texture;
            this.texW = texW;
            this.texH = texH;
        }

        /** {u, v, w, h, xOffset, yOffset (from the baseline), advance}, all in screen pixels. */
        float[] glyph(int cp) {
            return cp >= 0 && cp < 256 ? low[cp] : high.get(cp);
        }
    }

    private static final Atlas[][] ATLASES = new Atlas[2][MAX_SCALE + 1];
    private static final boolean[][] ATLAS_TRIED = new boolean[2][MAX_SCALE + 1];

    private static Atlas atlas(int face, int scale) {
        if (!ATLAS_TRIED[face][scale]) {
            ATLAS_TRIED[face][scale] = true;
            ATLASES[face][scale] = loadAtlas(face, scale);
        }
        return ATLASES[face][scale];
    }

    private static Atlas loadAtlas(int face, int scale) {
        String name = FACE_NAMES[face] + "_" + scale;
        String path = "/assets/" + StarGG.MOD_ID + "/font/glyphs/" + name + ".json";
        try (InputStream in = Ui.class.getResourceAsStream(path)) {
            if (in == null) {
                return null;
            }
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            Atlas atlas = new Atlas(Identifier.of(StarGG.MOD_ID, "textures/gui/font/" + name + ".png"),
                    root.get("texW").getAsInt(), root.get("texH").getAsInt());
            for (Map.Entry<String, JsonElement> entry : root.getAsJsonObject("glyphs").entrySet()) {
                int cp = Integer.parseInt(entry.getKey());
                var a = entry.getValue().getAsJsonArray();
                float[] g = new float[7];
                for (int i = 0; i < 7; i++) {
                    g[i] = a.get(i).getAsFloat();
                }
                if (cp < 256) {
                    atlas.low[cp] = g;
                } else {
                    atlas.high.put(cp, g);
                }
            }
            return atlas;
        } catch (Exception e) {
            StarGG.LOGGER.warn("Could not load glyph sheet {}, using the TTF font instead", name, e);
            return null;
        }
    }

    /** Total advance of the text in screen pixels, or -1 if a character is missing from the sheet. */
    private static float advancePx(Atlas atlas, String text) {
        float total = 0f;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            float[] g = atlas.glyph(cp);
            if (g == null) {
                return -1f;
            }
            total += g[6];
        }
        return total;
    }

    private static int measure(int face, String text) {
        int s = scale();
        Atlas atlas = atlas(face, s);
        if (atlas != null) {
            float px = advancePx(atlas, text);
            if (px >= 0f) {
                return (int) Math.ceil(px / s - 0.001f);
            }
        }
        return mc().textRenderer.getWidth(fallback(face, text));
    }

    private static void draw(DrawContext ctx, int face, String text, int x, int y, int color, boolean shadow) {
        if ((color >>> 24) == 0) {
            color |= 0xFF000000;
        }
        int s = scale();
        Atlas atlas = atlas(face, s);
        if (atlas == null || advancePx(atlas, text) < 0f) {
            ctx.drawText(mc().textRenderer, fallback(face, text), x, y, color, shadow);
            return;
        }
        // Work in screen pixels: shrink the matrix by the GUI scale so one texel is exactly one pixel.
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(1f / s, 1f / s);
        if (shadow) {
            int off = Math.max(1, s / 2);
            int shade = (color & 0xFF000000) | ((color & 0x00FCFCFC) >> 2);
            drawGlyphs(ctx, atlas, text, x * s + off, (y + CAP_HEIGHT) * s + off, shade);
        }
        drawGlyphs(ctx, atlas, text, x * s, (y + CAP_HEIGHT) * s, color);
        ctx.getMatrices().popMatrix();
    }

    private static void drawGlyphs(DrawContext ctx, Atlas atlas, String text, int originPx, int baselinePx, int color) {
        float cursor = originPx;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            float[] g = atlas.glyph(cp);
            int w = (int) g[2];
            int h = (int) g[3];
            if (w > 0 && h > 0) {
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, atlas.texture,
                        Math.round(cursor + g[4]), baselinePx + (int) g[5],
                        g[0], g[1], w, h, w, h, atlas.texW, atlas.texH, color);
            }
            cursor += g[6];
        }
    }

    /** TTF text for characters that are not on the glyph sheets. */
    private static Text fallback(int face, String text) {
        int s = scale();
        return Text.literal(text).setStyle(face == FACE_TITLE ? TITLE[s] : BOLD[s]);
    }

    // ------------------------------------------------------------------ text

    public static int width(String text) {
        return measure(FACE_UI, text);
    }

    public static int widthBold(String text) {
        return measure(FACE_UI, text);
    }

    /** Client-font text for the current GUI scale (TTF form; only used as a fallback). */
    public static Text regular(String text) {
        return fallback(FACE_UI, text);
    }

    public static void text(DrawContext ctx, String text, int x, int y, int color) {
        draw(ctx, FACE_UI, text, x, y, color, false);
    }

    /** Same face as {@link #text}: all client text is already semibold. */
    public static void textBold(DrawContext ctx, String text, int x, int y, int color) {
        draw(ctx, FACE_UI, text, x, y, color, false);
    }

    public static void textBold(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
        draw(ctx, FACE_UI, text, x, y, color, shadow);
    }

    /** Regular text with an optional shadow (used by the HUD). */
    public static void text(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
        draw(ctx, FACE_UI, text, x, y, color, shadow);
    }

    // ------------------------------------------------------- title (large bold) text

    public static int widthTitle(String text) {
        return measure(FACE_TITLE, text);
    }

    public static void textTitle(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
        draw(ctx, FACE_TITLE, text, x, y, color, shadow);
    }

    /** Y of the title-font text origin that centers its capital letters in a row. */
    public static int middleYTitle(int rowY, int rowH) {
        return rowY + (rowH - TITLE_CAP_HEIGHT) / 2 + (TITLE_CAP_HEIGHT - CAP_HEIGHT);
    }

    /** Y of the text origin that puts the capital letters exactly on the middle line of a row. */
    public static int middleY(int rowY, int rowH) {
        return rowY + (rowH - CAP_HEIGHT) / 2;
    }

    /** Draws text vertically centered inside a row that starts at rowY and is rowH tall. */
    public static void textMiddle(DrawContext ctx, String text, int x, int rowY, int rowH, int color) {
        text(ctx, text, x, middleY(rowY, rowH), color);
    }

    /** Draws text so that it ends at rightX. */
    public static void textRight(DrawContext ctx, String text, int rightX, int rowY, int rowH, int color) {
        textMiddle(ctx, text, rightX - width(text), rowY, rowH, color);
    }

    public static void textCentered(DrawContext ctx, String text, int x, int rowY, int w, int rowH, int color) {
        textMiddle(ctx, text, x + (w - width(text)) / 2, rowY, rowH, color);
    }

    public static String trim(String text, int maxWidth) {
        if (width(text) <= maxWidth) {
            return text;
        }
        String cut = text;
        while (!cut.isEmpty() && width(cut + "..") > maxWidth) {
            cut = cut.substring(0, cut.length() - 1);
        }
        return cut + "..";
    }

    // ----------------------------------------------------------------- shapes

    /** Draws an icon at its natural size, tinted with the given ARGB color. */
    public static void icon(DrawContext ctx, Tex tex, int x, int y, int color) {
        int px = tex.size * scale();
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex.byScale[scale()], x, y, 0f, 0f, tex.size, tex.size, px, px, px, px, color);
    }

    /**
     * Anti-aliased rounded rectangle (radius 1 to 5 GUI units). A radius of half the size gives a pill or
     * a circle. The straight parts are plain fills; only the four corners are textures.
     */
    public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.min(Math.min(r, 5), Math.min(w, h) / 2);
        if (r <= 0) {
            ctx.fill(x, y, x + w, y + h, color);
            return;
        }
        int s = scale();
        int c = r * s;
        Identifier corner = CORNERS[r][s];
        ctx.fill(x + r, y, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + r, y + h - r, color);
        ctx.fill(x + w - r, y + r, x + w, y + h - r, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x, y, 0f, 0f, r, r, c, c, 2 * c, 2 * c, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x + w - r, y, (float) c, 0f, r, r, c, c, 2 * c, 2 * c, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x, y + h - r, 0f, (float) c, r, r, c, c, 2 * c, 2 * c, color);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, corner, x + w - r, y + h - r, (float) c, (float) c, r, r, c, c, 2 * c, 2 * c, color);
    }
}
