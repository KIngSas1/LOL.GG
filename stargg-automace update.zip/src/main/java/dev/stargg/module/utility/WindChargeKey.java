package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

import java.util.concurrent.ThreadLocalRandom;

/** Keybind action: selects a hotbar wind charge, throws it, then restores the selected slot. */
public final class WindChargeKey extends Module {

    private final BooleanSetting randomization = add(new BooleanSetting("Randomization", false));
    private final NumberSetting randomMinDelay = add(new NumberSetting("Random Min (ms)", 0.0, 0.0, 500.0, 1.0));
    private final NumberSetting randomMaxDelay = add(new NumberSetting("Random Max (ms)", 25.0, 0.0, 500.0, 1.0));
    private final BooleanSetting autoJump = add(new BooleanSetting("Auto Jump", false));

    private boolean thrown;
    private int originalSlot = -1;
    private int waitTicks;
    private long throwAt;

    public WindChargeKey() {
        super("WindChargeKey", "Throws a wind charge and optionally jumps at the same time", Category.COMBAT);
        randomMinDelay.showWhen(randomization::on);
        randomMaxDelay.showWhen(randomization::on);
    }

    @Override
    protected void onEnable() {
        thrown = false;
        waitTicks = 0;
        originalSlot = -1;
        if (mc.player == null || mc.interactionManager == null) {
            setEnabled(false);
            return;
        }
        int chargeSlot = findChargeSlot();
        if (chargeSlot < 0) {
            setEnabled(false);
            return;
        }
        originalSlot = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(chargeSlot);
        long min = randomization.on() ? (long) randomMinDelay.getDouble() : 0L;
        long max = randomization.on() ? (long) Math.max(min, randomMaxDelay.getDouble()) : 0L;
        long delay = min == max ? min : ThreadLocalRandom.current().nextLong(min, max + 1L);
        throwAt = System.currentTimeMillis() + delay;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null || originalSlot < 0) {
            setEnabled(false);
            return;
        }
        if (!thrown) {
            if (!mc.player.getMainHandStack().isOf(Items.WIND_CHARGE)) {
                setEnabled(false);
                return;
            }
            if (System.currentTimeMillis() < throwAt) return;

            // Both actions happen in this same client tick: send the use interaction, then jump.
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.swingHand(Hand.MAIN_HAND);
            if (autoJump.on()) {
                mc.player.jump();
            }
            thrown = true;
            waitTicks = 0;
            return;
        }

        if (++waitTicks >= 2) {
            setEnabled(false);
        }
    }

    @Override
    protected void onDisable() {
        if (mc.player != null && originalSlot >= 0 && originalSlot < 9) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        originalSlot = -1;
        thrown = false;
        waitTicks = 0;
        throwAt = 0L;
    }

    private int findChargeSlot() {
        if (mc.player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(Items.WIND_CHARGE)) return slot;
        }
        return -1;
    }
}
