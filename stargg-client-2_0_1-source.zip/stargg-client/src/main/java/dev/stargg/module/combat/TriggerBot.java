package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.CombatUtil;
import dev.stargg.util.FallTracker;
import dev.stargg.util.ItemFilters;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/** Attacks automatically whenever the crosshair is on a valid target. */
public final class TriggerBot extends Module {

    private final NumberSetting maxRange = add(new NumberSetting("Max range", 3.0, 1.0, 6.0, 0.1));
    private final NumberSetting minCooldown = add(new NumberSetting("Min cooldown", 0.92, 0.0, 1.0, 0.01));
    private final RandomRangeSetting delay = add(new RandomRangeSetting("Delay (ms)", 20.0, 80.0, 0.0, 500.0, 5.0));
    private final BooleanSetting critsOnly = add(new BooleanSetting("Crits only", false));
    private final BooleanSetting skipBlocking = add(new BooleanSetting("Skip blocking targets", false));
    private final BooleanSetting holdAttack = add(new BooleanSetting("Only while holding attack", false));
    private final BooleanSetting notWhileUsing = add(new BooleanSetting("Not while using item", true));
    private final MultiSelectSetting weapons = add(new MultiSelectSetting("Weapons", CombatUtil.WEAPON_OPTIONS, "Any"));
    private final MultiSelectSetting targets = add(new MultiSelectSetting("Targets", CombatUtil.TARGET_OPTIONS, "Players"));
    private final BooleanSetting ignoreFriends = add(new BooleanSetting("Ignore friends", true));

    private int lastTargetId = -1;
    private long nextAttackAt;

    public TriggerBot() {
        super("Trigger Bot", "Attacks when your crosshair is on a target", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            reset();
            return;
        }
        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof LivingEntity target)) {
            reset();
            return;
        }
        if (!CombatUtil.isValidTarget(target, targets, ignoreFriends.on())
                || mc.player.distanceTo(target) > maxRange.getFloat()
                || !ItemFilters.matches(mc.player.getMainHandStack(), weapons)
                || holdAttack.on() && !mc.options.attackKey.isPressed()
                || notWhileUsing.on() && mc.player.isUsingItem()
                || skipBlocking.on() && target.isBlocking()
                || critsOnly.on() && !canCrit()) {
            reset();
            return;
        }
        if (target.getId() != lastTargetId) {
            lastTargetId = target.getId();
            nextAttackAt = 0L;
        }
        if (mc.player.getAttackCooldownProgress(0.5F) < minCooldown.getFloat()) {
            return;
        }

        long now = System.currentTimeMillis();
        if (nextAttackAt == 0L) {
            nextAttackAt = now + (long) delay.sample();
        }
        if (now < nextAttackAt) {
            return;
        }
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        nextAttackAt = 0L;
    }

    private boolean canCrit() {
        return !mc.player.isOnGround() && FallTracker.distance() > 0.0 && mc.player.getVelocity().y < 0.0
                && !mc.player.isClimbing() && !mc.player.isTouchingWater() && !mc.player.hasVehicle();
    }

    private void reset() {
        lastTargetId = -1;
        nextAttackAt = 0L;
    }

    @Override
    protected void onDisable() {
        reset();
    }
}
