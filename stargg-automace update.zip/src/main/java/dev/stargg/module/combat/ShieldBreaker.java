package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.ItemFilters;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.util.Hand;

/** Intercepts a manual hit on a blocking player, swaps to an axe, then restores the prior slot. */
public final class ShieldBreaker extends Module {

    private static final String[] ITEM_OPTIONS = {
            "Swords", "Axes", "Pickaxes", "Shovels", "Hoes", "Tools", "Mace", "Trident", "Ender Pearl", "Wind Charge", "Hand"
    };

    private final NumberSetting swapDelay = add(new NumberSetting("Swap delay", 0.0, 0.0, 10.0, 1.0));
    private final NumberSetting swapBackDelay = add(new NumberSetting("Swap back delay", 2.0, 1.0, 10.0, 1.0));
    private final BooleanSetting doubleClick = add(new BooleanSetting("Double click", false));
    private final BooleanSetting limitToItems = add(new BooleanSetting("Limit to items", false));
    private final MultiSelectSetting allowedItems = add(new MultiSelectSetting("Allowed items", ITEM_OPTIONS, "Swords"));

    private int originalSlot = -1;
    private int axeSlot = -1;
    private int delayTicks;
    private int swapBackTicks;
    private int waitTicks;
    private PlayerEntity target;
    private boolean active;
    private boolean attackPending;
    private boolean firstHitSent;
    private boolean secondHitSent;
    private boolean repeatWithCurrentAxe;

    public ShieldBreaker() {
        super("Shield Breaker", "Swaps to an axe when manually attacking a blocking player", Category.UTILITY);
        icon(Icon.SHIELD_BREAKER);
        allowedItems.showWhen(limitToItems::on);
    }

    /** True while this module is performing its own axe swap/attack sequence. */
    public boolean isRunningSequence() {
        return active;
    }

    /** @return true when the original unarmed/held-item attack should be cancelled. */
    public boolean interceptAttack(Entity entity) {
        if (!isEnabled() || active || mc.player == null || mc.currentScreen != null
                || !(entity instanceof PlayerEntity playerTarget) || !playerTarget.isAlive() || !playerTarget.isBlocking()) {
            return false;
        }
        if (limitToItems.on() && !ItemFilters.matches(mc.player.getMainHandStack(), allowedItems)) {
            return false;
        }

        if (mc.player.getMainHandStack().getItem() instanceof AxeItem) {
            if (doubleClick.on()) {
                begin(playerTarget, mc.player.getInventory().getSelectedSlot(), -1, false);
                repeatWithCurrentAxe = true;
            }
            return false;
        }

        int foundAxe = findAxeSlot();
        if (foundAxe < 0) {
            return false;
        }
        int selected = mc.player.getInventory().getSelectedSlot();
        if (selected == foundAxe) {
            return false;
        }

        begin(playerTarget, selected, foundAxe, true);
        mc.player.getInventory().setSelectedSlot(foundAxe);
        return true;
    }

    private void begin(PlayerEntity playerTarget, int previousSlot, int foundAxe, boolean shouldSwap) {
        target = playerTarget;
        originalSlot = previousSlot;
        axeSlot = foundAxe;
        active = true;
        attackPending = shouldSwap;
        firstHitSent = !shouldSwap;
        secondHitSent = false;
        repeatWithCurrentAxe = !shouldSwap;
        delayTicks = swapDelay.getInt();
        swapBackTicks = 0;
        waitTicks = 0;
    }

    @Override
    public void onTick() {
        if (!active) {
            return;
        }
        if (mc.player == null || mc.world == null || mc.interactionManager == null || target == null || !target.isAlive()) {
            restoreSlot();
            return;
        }

        if (attackPending) {
            if (delayTicks > 0) {
                delayTicks--;
                return;
            }
            if (mc.player.getAttackCooldownProgress(0.5F) < 1.0F) {
                return;
            }
            attackPending = false;
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            firstHitSent = true;
            waitTicks = 0;
            return;
        }

        if (!firstHitSent) {
            restoreSlot();
            return;
        }
        waitTicks++;
        if (target.isBlocking() && waitTicks < 5) {
            return;
        }

        if (doubleClick.on() && !secondHitSent && !repeatWithCurrentAxe && !target.isBlocking()) {
            secondHitSent = true;
            if (mc.player.getAttackCooldownProgress(0.5F) >= 1.0F) {
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        } else if (doubleClick.on() && repeatWithCurrentAxe && !secondHitSent && !target.isBlocking()) {
            secondHitSent = true;
            if (mc.player.getAttackCooldownProgress(0.5F) >= 1.0F) {
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }

        if (swapBackTicks < swapBackDelay.getInt()) {
            swapBackTicks++;
            return;
        }
        restoreSlot();
    }

    public boolean canBreakShield() {
        return isEnabled() && mc.player != null
                && (!limitToItems.on() || ItemFilters.matches(mc.player.getMainHandStack(), allowedItems))
                && (mc.player.getMainHandStack().getItem() instanceof AxeItem || findAxeSlot() >= 0);
    }

    private int findAxeSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    private void restoreSlot() {
        if (mc.player != null && originalSlot >= 0 && originalSlot < 9) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        originalSlot = -1;
        axeSlot = -1;
        target = null;
        active = false;
        attackPending = false;
        firstHitSent = false;
        secondHitSent = false;
        repeatWithCurrentAxe = false;
        delayTicks = 0;
        swapBackTicks = 0;
        waitTicks = 0;
    }

    @Override
    protected void onDisable() {
        restoreSlot();
    }
}
