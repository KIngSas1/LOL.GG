package dev.legitclient;

import dev.legitclient.config.ConfigManager;
import dev.legitclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Mod entry point. Wires Fabric events to the module manager. */
public final class LegitClient implements ClientModInitializer {

    public static final String MOD_ID = "legitclient";
    public static final String NAME = "STAR.GG";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    private static final ModuleManager MODULES = new ModuleManager();
    private static final ConfigManager CONFIG = new ConfigManager();

    public static ModuleManager modules() {
        return MODULES;
    }

    public static ConfigManager config() {
        return CONFIG;
    }

    @Override
    public void onInitializeClient() {
        MODULES.init();
        CONFIG.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MODULES.tick(client);
            CONFIG.tick();
        });

        // Drawn on top of the vanilla HUD. (If your Fabric API version lacks
        // HudElementRegistry, use HudRenderCallback.EVENT instead.)
        HudElementRegistry.addLast(
                Identifier.of(MOD_ID, "hud"),
                (context, tickCounter) -> MODULES.renderHud(context));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> CONFIG.save());
        LOGGER.info("{} {} loaded with {} modules", NAME, VERSION, MODULES.all().size());
    }
}
