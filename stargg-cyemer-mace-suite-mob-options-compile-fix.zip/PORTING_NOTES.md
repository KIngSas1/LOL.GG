# StarGG module port notes

This project keeps the existing StarGG / Fabric 1.21.11 structure and adds the requested modules from the supplied Cyemer source. The previous Chat V4 `AutoMace` implementation has been replaced, not duplicated.

## Imported modules

| Module | Category | Ported behavior / controls |
|---|---|---|
| AutoMace | Combat | Swing Range, Aim Range, Aim In Air, Auto Switch, Swap Back, Aim Speed, Min Fall Dist, Cooldown, Mace Swap Delay, Stun Slam, Weapon Only, Aim Mode (Strict / Loose / Horizontal), Stop Aim, Hitbox Accuracy, Ignore Friends, Target Mode, Target settings (Players / Mobs / Peaceful / Neutral and visibility filters); target acquisition and attack sequences support selected living-entity categories |
| MaceSwap | Combat | Intercepts a manual entity hit, chooses a Density mace while falling or a Breach mace below the configured threshold, swaps for the hit and restores the prior slot; Not on Axe, Weapon Only, Density Height, Randomization, Random Min/Max |
| WindChargeKey | Combat | Keybind action selects a hotbar Wind Charge, uses it, waits briefly and restores the prior slot; Randomization and Random Min/Max |
| AutoElytra | Combat | Elytra/chestplate swap logic driven by AutoMace sync, pearl use, air/ground state and nearby-target height/distance conditions; Target settings (Players / Mobs / Peaceful / Neutral and visibility filters), Randomization, AutoMace Sync, In Air, On Pearl, Disable on Ground, Reequip Delay, Height Diff, Height Range, Mace Pre-Hit Range and Min Drop Dist |

### WindChargeKey change requested

Added a BooleanSetting named **Auto Jump**. When enabled, the module sends the Wind Charge use interaction and calls `player.jump()` in the same client tick. The option is off by default. It triggers even when the player is already airborne.

### Supporting changes

- Registered the new modules under the existing Combat category.
- Added a generated 32×32 transparent AutoElytra icon and its dim/off-state version, then registered `Icon.AUTO_ELYTRA`.
- Added a small persistent `FriendManager` / `Friend` utility used by AutoMace's Ignore Friends and AutoElytra's nearby-target selection. It stores entries at `config/stargg/friends.json`; this project does not yet include a friend-list GUI.
- Added an `interactItem` mixin hook so AutoElytra can react to local Ender Pearl use.
- Connected AutoMace's mace-hit and pre-hit signals to AutoElytra without importing Cyemer's separate event bus.
- Guarded internally-generated AutoMace, MaceSwap and ShieldBreaker attacks from being intercepted by one another.

## Adaptations / limitations

This is a native port of the source behavior into StarGG's module and tick systems, not a byte-for-byte class copy. The source's `RotationManager`, `AttackValidator`, `ModuleRandomDelay`, `SystemInputSimulator`, and event bus are not present in StarGG, so their behavior is adapted using StarGG's tick hooks, normal player rotations, interaction-manager calls, and local delay state.

The source's `Render Pred` 3D bounding-box overlay is not included because the StarGG 1.21.11 rendering pipeline does not currently expose the same MatrixStack/VertexConsumer hook used by the supplied client. The aim/attack prediction and hitbox checks are ported, but that optional visual overlay is not.

The source's target-lock system is approximated by requiring the current crosshair player when Target Mode is enabled. The source friend list UI is not imported; the friend utility and JSON store are present, but names/UUIDs need to be added through its API or the JSON file until a GUI is built.

WindChargeKey uses StarGG's direct `interactItem` API instead of simulating a physical keyboard hold. Auto Jump is invoked in the same client-tick callback as the use interaction; actual server packet processing and movement timing remain dependent on the game tick and server.

## Build status

Target: Minecraft 1.21.11, Yarn 1.21.11+build.4, Java 21, Fabric API 0.139.4+1.21.11. The Gradle wrapper could not download its Gradle distribution in this environment because `services.gradle.org` was unreachable, so a successful compile has not been verified here. Run `./gradlew build` from the project root in an environment with network access and send the complete log if another compiler error appears.

## Target settings (AutoMace and AutoElytra)

Both modules now use StarGG's existing Chat V4-style multi-select target filter. `Players` is enabled by default; `Mobs`, `Peaceful`, and `Neutral` are independently selectable and disabled by default. The optional `Ignore naked`, `Ignore invisible`, and `Ignore behind walls` filters are also available. AutoMace's target acquisition, crosshair target mode, aim, reach checks, and attack sequence now use `LivingEntity` instead of being player-only. AutoElytra's mace pre-hit chestplate swap target scan also searches selected living entities rather than players only. Player friends and spectators remain excluded as before.
