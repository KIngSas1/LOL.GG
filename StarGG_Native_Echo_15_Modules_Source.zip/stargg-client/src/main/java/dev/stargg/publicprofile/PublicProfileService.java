package dev.stargg.publicprofile;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Where public profiles live. The UI only talks to this interface, so the storage can be swapped without touching
 * any screen: {@link LocalPublicProfileService} keeps them in a folder; an implementation that talks to your own
 * server can be installed with {@link PublicProfiles#setService}.
 *
 * <p>Futures may complete on any thread; the UI hops back onto the render thread itself.
 */
public interface PublicProfileService {

    /** Short name shown in the screen header, e.g. "Local folder". */
    String backendName();

    /** The name of the current viewer; used to recognise their own profiles and reviews. */
    String viewerName();

    /** Listed profiles matching the text (name, owner, tags), carrying all of the given tags. List view data only. */
    CompletableFuture<List<PublicProfile>> search(String query, List<String> tags, PublicProfileSortMode sort);

    /** The viewer's own profiles, listed or not. */
    CompletableFuture<List<PublicProfile>> mine();

    /** Full profile including data and reviews. */
    CompletableFuture<PublicProfile> get(long id);

    /** Looks a profile up by its share code (listed or not); completes with null if there is none. */
    CompletableFuture<PublicProfile> findByShareCode(String code);

    /** Publishes a new profile. */
    CompletableFuture<PublicProfile> publish(String name, String description, List<String> tags, String data,
                                             boolean listedPublicly, boolean uploadAnonymously);

    /** Replaces the data of one of the viewer's profiles and bumps its version. */
    CompletableFuture<PublicProfile> update(long id, String data);

    /** Changes the listing options of one of the viewer's profiles. */
    CompletableFuture<PublicProfile> setListing(long id, boolean listedPublicly);

    CompletableFuture<Void> unpublish(long id);

    /** Counts a download. */
    CompletableFuture<PublicProfile> recordDownload(long id);

    /** Creates or replaces the viewer's review of a profile. */
    CompletableFuture<PublicProfile> review(long id, boolean liked, String message);

    CompletableFuture<PublicProfile> deleteReview(long id, long reviewId);

    /** The owner's reply to a review. */
    CompletableFuture<PublicProfile> reply(long id, long reviewId, String text);
}
