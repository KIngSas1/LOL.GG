package dev.stargg.publicprofile;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.stargg.StarGG;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

/**
 * Stores public profiles as one JSON file each in {@code config/stargg/public_profiles}. It works without any server;
 * point the folder at a shared drive or copy files between machines to exchange profiles, or replace the service with
 * one that talks to a server.
 */
public final class LocalPublicProfileService implements PublicProfileService {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final int CODE_LENGTH = 8;
    private static final int MAX_REVIEW_LENGTH = 200;

    private final Path directory = FabricLoader.getInstance().getConfigDir().resolve("stargg").resolve("public_profiles");
    private final SecureRandom random = new SecureRandom();

    @Override
    public String backendName() {
        return "Local folder";
    }

    @Override
    public String viewerName() {
        try {
            String name = MinecraftClient.getInstance().getSession().getUsername();
            return name == null || name.isBlank() ? "Player" : name;
        } catch (Throwable t) {
            return "Player";
        }
    }

    // ------------------------------------------------------------------ storage

    private Path file(long id) {
        return directory.resolve(id + ".json");
    }

    private synchronized List<PublicProfile> readAll() {
        List<PublicProfile> all = new ArrayList<>();
        if (!Files.isDirectory(directory)) {
            return all;
        }
        try (Stream<Path> files = Files.list(directory)) {
            List<Path> paths = files.filter(p -> p.getFileName().toString().endsWith(".json")).toList();
            for (Path path : paths) {
                try {
                    PublicProfile profile = GSON.fromJson(Files.readString(path), PublicProfile.class);
                    if (profile != null && profile.id != 0) {
                        if (profile.tags == null) {
                            profile.tags = new ArrayList<>();
                        }
                        if (profile.reviews == null) {
                            profile.reviews = new ArrayList<>();
                        }
                        all.add(profile);
                    }
                } catch (Exception e) {
                    StarGG.LOGGER.warn("Skipping unreadable public profile {}: {}", path.getFileName(), e.toString());
                }
            }
        } catch (IOException e) {
            StarGG.LOGGER.warn("Could not list public profiles: {}", e.toString());
        }
        return all;
    }

    private synchronized PublicProfile read(long id) {
        for (PublicProfile profile : readAll()) {
            if (profile.id == id) {
                return profile;
            }
        }
        return null;
    }

    private synchronized void write(PublicProfile profile) throws IOException {
        Files.createDirectories(directory);
        Files.writeString(file(profile.id), GSON.toJson(profile));
    }

    private String newShareCode(List<PublicProfile> existing) {
        while (true) {
            StringBuilder code = new StringBuilder();
            for (int i = 0; i < CODE_LENGTH; i++) {
                code.append(CODE_ALPHABET.charAt(random.nextInt(CODE_ALPHABET.length())));
            }
            String candidate = code.toString();
            if (existing.stream().noneMatch(p -> candidate.equalsIgnoreCase(p.shareCode))) {
                return candidate;
            }
        }
    }

    private boolean isOwner(PublicProfile profile) {
        return profile.ownerKey != null && profile.ownerKey.equalsIgnoreCase(viewerName());
    }

    private static <T> CompletableFuture<T> failed(String message) {
        return CompletableFuture.failedFuture(new IllegalStateException(message));
    }

    private static void recount(PublicProfile profile) {
        long likes = 0;
        long dislikes = 0;
        for (PublicProfileReview review : profile.reviews) {
            if (review.liked) {
                likes++;
            } else {
                dislikes++;
            }
        }
        profile.likes = likes;
        profile.dislikes = dislikes;
    }

    // ------------------------------------------------------------------ queries

    @Override
    public CompletableFuture<List<PublicProfile>> search(String query, List<String> tags, PublicProfileSortMode sort) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<PublicProfile> result = new ArrayList<>();
        for (PublicProfile profile : readAll()) {
            if (!profile.listedPublicly) {
                continue;
            }
            boolean matchesText = q.isEmpty()
                    || profile.name.toLowerCase(Locale.ROOT).contains(q)
                    || profile.ownerDisplay().toLowerCase(Locale.ROOT).contains(q)
                    || profile.tags.stream().anyMatch(t -> t.toLowerCase(Locale.ROOT).contains(q));
            boolean matchesTags = tags == null || tags.stream().allMatch(
                    wanted -> profile.tags.stream().anyMatch(t -> t.equalsIgnoreCase(wanted)));
            if (matchesText && matchesTags) {
                result.add(profile.summary());
            }
        }
        Comparator<PublicProfile> order = switch (sort) {
            case RATED -> Comparator.comparingDouble(PublicProfile::score).reversed().thenComparing(p -> -p.likes);
            case DOWNLOADED -> Comparator.comparingLong((PublicProfile p) -> p.downloads).reversed();
            case NEWEST -> Comparator.comparingLong((PublicProfile p) -> p.createdMillis).reversed();
        };
        result.sort(order);
        return CompletableFuture.completedFuture(result);
    }

    @Override
    public CompletableFuture<List<PublicProfile>> mine() {
        List<PublicProfile> result = new ArrayList<>();
        for (PublicProfile profile : readAll()) {
            if (isOwner(profile)) {
                result.add(profile.summary());
            }
        }
        result.sort(Comparator.comparingLong((PublicProfile p) -> p.updatedMillis).reversed());
        return CompletableFuture.completedFuture(result);
    }

    @Override
    public CompletableFuture<PublicProfile> get(long id) {
        PublicProfile profile = read(id);
        return profile == null ? failed("That profile no longer exists") : CompletableFuture.completedFuture(profile);
    }

    @Override
    public CompletableFuture<PublicProfile> findByShareCode(String code) {
        String wanted = code == null ? "" : code.trim();
        for (PublicProfile profile : readAll()) {
            if (!wanted.isEmpty() && wanted.equalsIgnoreCase(profile.shareCode)) {
                return CompletableFuture.completedFuture(profile);
            }
        }
        return CompletableFuture.completedFuture(null);
    }

    // ---------------------------------------------------------------- mutations

    @Override
    public synchronized CompletableFuture<PublicProfile> publish(String name, String description, List<String> tags, String data,
                                                                 boolean listedPublicly, boolean uploadAnonymously) {
        if (data == null || data.isBlank()) {
            return failed("Nothing to publish");
        }
        try {
            List<PublicProfile> existing = readAll();
            long id = existing.stream().mapToLong(p -> p.id).max().orElse(0) + 1;
            long now = System.currentTimeMillis();
            PublicProfile profile = new PublicProfile();
            profile.id = id;
            profile.name = name;
            profile.ownerKey = viewerName();
            profile.owner = uploadAnonymously ? null : viewerName();
            profile.description = description == null ? "" : description;
            profile.tags = new ArrayList<>(tags);
            profile.createdMillis = now;
            profile.updatedMillis = now;
            profile.listedPublicly = listedPublicly;
            profile.uploadAnonymously = uploadAnonymously;
            profile.shareCode = newShareCode(existing);
            profile.data = data;
            write(profile);
            return CompletableFuture.completedFuture(profile);
        } catch (IOException e) {
            return failed("Could not save: " + e.getMessage());
        }
    }

    private CompletableFuture<PublicProfile> mutate(long id, boolean ownerOnly, java.util.function.Consumer<PublicProfile> change) {
        synchronized (this) {
            PublicProfile profile = read(id);
            if (profile == null) {
                return failed("That profile no longer exists");
            }
            if (ownerOnly && !isOwner(profile)) {
                return failed("Only the owner can do that");
            }
            try {
                change.accept(profile);
                write(profile);
                return CompletableFuture.completedFuture(profile);
            } catch (IllegalStateException e) {
                return failed(e.getMessage());
            } catch (IOException e) {
                return failed("Could not save: " + e.getMessage());
            }
        }
    }

    @Override
    public CompletableFuture<PublicProfile> update(long id, String data) {
        return mutate(id, true, profile -> {
            profile.data = data;
            profile.version++;
            profile.updatedMillis = System.currentTimeMillis();
        });
    }

    @Override
    public CompletableFuture<PublicProfile> setListing(long id, boolean listedPublicly) {
        return mutate(id, true, profile -> profile.listedPublicly = listedPublicly);
    }

    @Override
    public synchronized CompletableFuture<Void> unpublish(long id) {
        PublicProfile profile = read(id);
        if (profile == null) {
            return CompletableFuture.completedFuture(null);
        }
        if (!isOwner(profile)) {
            return failed("Only the owner can do that");
        }
        try {
            Files.deleteIfExists(file(id));
            return CompletableFuture.completedFuture(null);
        } catch (IOException e) {
            return failed("Could not delete: " + e.getMessage());
        }
    }

    @Override
    public CompletableFuture<PublicProfile> recordDownload(long id) {
        return mutate(id, false, profile -> profile.downloads++);
    }

    @Override
    public CompletableFuture<PublicProfile> review(long id, boolean liked, String message) {
        return mutate(id, false, profile -> {
            if (isOwner(profile)) {
                throw new IllegalStateException("You cannot review your own profile");
            }
            String text = message == null ? "" : message.trim();
            if (text.length() > MAX_REVIEW_LENGTH) {
                text = text.substring(0, MAX_REVIEW_LENGTH);
            }
            String viewer = viewerName();
            PublicProfileReview mine = null;
            for (PublicProfileReview review : profile.reviews) {
                if (viewer.equalsIgnoreCase(review.author)) {
                    mine = review;
                }
            }
            if (mine == null) {
                mine = new PublicProfileReview();
                mine.id = profile.reviews.stream().mapToLong(r -> r.id).max().orElse(0) + 1;
                mine.author = viewer;
                mine.createdMillis = System.currentTimeMillis();
                profile.reviews.add(mine);
            }
            mine.liked = liked;
            mine.message = text;
            mine.version = profile.version;
            recount(profile);
        });
    }

    @Override
    public CompletableFuture<PublicProfile> deleteReview(long id, long reviewId) {
        return mutate(id, false, profile -> {
            String viewer = viewerName();
            profile.reviews.removeIf(r -> r.id == reviewId && (viewer.equalsIgnoreCase(r.author) || isOwner(profile)));
            recount(profile);
        });
    }

    @Override
    public CompletableFuture<PublicProfile> reply(long id, long reviewId, String text) {
        return mutate(id, true, profile -> {
            String reply = text == null ? "" : text.trim();
            if (reply.length() > MAX_REVIEW_LENGTH) {
                reply = reply.substring(0, MAX_REVIEW_LENGTH);
            }
            for (PublicProfileReview review : profile.reviews) {
                if (review.id == reviewId) {
                    review.reply = reply.isEmpty() ? null : reply;
                    review.replyMillis = System.currentTimeMillis();
                }
            }
        });
    }
}
