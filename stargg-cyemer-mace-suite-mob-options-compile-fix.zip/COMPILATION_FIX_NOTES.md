# Compilation fixes

Fixed the three errors from the supplied GitHub Actions log:

1. `MaceSwap` no longer imports the unavailable `net.minecraft.item.SwordItem`. Sword detection now uses the existing Minecraft `ItemTags.SWORDS` tag, matching the approach already used by `AutoMace`.
2. `AutoMace` now exposes `canBreakShield(PlayerEntity)`, the target-aware method called by `Triggerbot`. It reports true only when AutoMace is enabled, Stun Slam and Auto Switch are enabled, the blocking target passes the configured target filters/range, the required axe and mace are available, and the fall-distance requirement is met.

The project was not compiled in this environment because the Gradle 9.2.0 distribution is not cached and the Gradle distribution host is unreachable here. Run `./gradlew compileJava` in GitHub Actions to verify the full project.
