package dev.legitclient.module.hud;

import dev.legitclient.LegitClient;
import dev.legitclient.util.Icon;

import java.util.List;

public final class Watermark extends TextHudModule {

    public Watermark() {
        super("Watermark", "Shows the client name", 4, 4);
        icon(Icon.WATERMARK);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        return List.of(LegitClient.NAME + " " + LegitClient.VERSION);
    }
}
