package dev.stargg.module.client;

import dev.stargg.StarGG;
import dev.stargg.gui.CentralGuiScreen;
import dev.stargg.gui.ClickGuiScreen;
import dev.stargg.module.BindMode;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.ColorSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

/** Opens the click GUI and holds its look settings (GUI style, accent color, opacity). */
public final class ClickGuiModule extends Module {

    public static final String STYLE_FRAMES = "Frames";
    public static final String STYLE_CENTRAL = "Central";

    private static ClickGuiModule instance;

    private final ModeSetting guiStyle = add(new ModeSetting("GUI style", STYLE_FRAMES, STYLE_FRAMES, STYLE_CENTRAL));
    private final ColorSetting accentColor = add(new ColorSetting("Accent", "Teal"));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 92, 50, 100, 1));

    private ClickGuiScreen framesScreen;
    private CentralGuiScreen centralScreen;
    private boolean swapping;

    public ClickGuiModule() {
        super("Click GUI", "Opens this menu and changes its look", Category.CLIENT);
        icon(Icon.CLICK_GUI);
        defaultBind(GLFW.GLFW_KEY_RIGHT_SHIFT, BindMode.TOGGLE);
        instance = this;
    }

    // ------------------------------------------------------------ static look-up

    public static int accent() {
        return instance == null ? 0xFF0E9E85 : instance.accentColor.argb();
    }

    public static int panelAlpha() {
        return instance == null ? 235 : (int) Math.round(instance.opacity.getDouble() / 100.0 * 255.0);
    }

    /** Name of the active profile (shown in the GUI). */
    public static String profileName() {
        return StarGG.config().getActiveProfile();
    }

    /** True while the "GUI style" setting is on {@code Central}. */
    public static boolean centralSelected() {
        return instance != null && instance.guiStyle.is(STYLE_CENTRAL);
    }

    /** Sets the GUI style ({@link #STYLE_FRAMES} or {@link #STYLE_CENTRAL}). */
    public static void selectStyle(String style) {
        if (instance != null) {
            instance.guiStyle.set(style);
        }
    }

    // -------------------------------------------------------------- behaviour

    @Override
    public boolean isToggleable() {
        return false;
    }

    @Override
    protected boolean savesEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        Screen wanted = screenForStyle();
        if (mc.currentScreen != wanted) {
            mc.setScreen(wanted);
        }
    }

    private Screen screenForStyle() {
        if (centralSelected()) {
            if (centralScreen == null) {
                centralScreen = new CentralGuiScreen();
            }
            return centralScreen;
        }
        if (framesScreen == null) {
            framesScreen = new ClickGuiScreen();
        }
        return framesScreen;
    }

    /**
     * Replaces the open click GUI with the one that matches the current "GUI style" setting. Called by the
     * screens themselves when the setting changed while they are open.
     */
    public void swapScreen() {
        Screen wanted = screenForStyle();
        if (mc.currentScreen == wanted) {
            return;
        }
        swapping = true;
        try {
            mc.setScreen(wanted); // the old screen's removed() runs here and must not close the module
        } finally {
            swapping = false;
        }
    }

    /** True while {@link #swapScreen()} is replacing one click GUI with the other. */
    public boolean isSwapping() {
        return swapping;
    }
}
