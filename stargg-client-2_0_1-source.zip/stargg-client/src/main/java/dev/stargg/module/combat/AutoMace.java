package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.CombatUtil;
import dev.stargg.util.FallTracker;
import dev.stargg.util.SilentRotationManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

import java.util.List;

/** While falling, attacks a nearby target with the mace (optionally swapping to it and aiming first). */
public final class AutoMace extends Module {

    private final NumberSetting range = add(new NumberSetting("Range", 3.0, 1.0, 6.0, 0.1));
    private final NumberSetting minFall = add(new NumberSetting("Min fall distance", 3.0, 1.5, 30.0, 0.5));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Health", "Crosshair"));
    private final NumberSetting fov = add(new NumberSetting("FOV", 360.0, 30.0, 360.0, 5.0));
    private final MultiSelectSetting targets = add(new MultiSelectSetting("Targets", CombatUtil.TARGET_OPTIONS, "Players"));
    private final BooleanSetting ignoreFriends = add(new BooleanSetting("Ignore friends", true));
    private final BooleanSetting autoSwap = add(new BooleanSetting("Auto swap", true));
    private final BooleanSetting swapBack = add(new BooleanSetting("Swap back", true));
    private final BooleanSetting rotate = add(new BooleanSetting("Rotate", true));
    private final BooleanSetting silentAim = add(new BooleanSetting("Silent aim", true));
    private final NumberSetting aimSpeed = add(new NumberSetting("Aim speed", 60.0, 1.0, 180.0, 1.0));
    private final NumberSetting minCooldown = add(new NumberSetting("Min cooldown", 0.9, 0.0, 1.0, 0.05));
    private final RandomRangeSetting attackDelay = add(new RandomRangeSetting("Attack delay (ms)", 0.0, 50.0, 0.0, 500.0, 5.0));
    private final BooleanSetting notWhileUsing = add(new BooleanSetting("Not while using item", true));

    private float aimYaw;
    private float aimPitch;
    private boolean aimInit;
    private int aimTicks;
    private long nextAttackAt;
    private int restoreSlot = -1;
    private int restoreTicks;

    public AutoMace() {
        super("Auto Mace", "Smashes nearby targets with the mace while you fall", Category.COMBAT);
        silentAim.showWhen(rotate::on);
        aimSpeed.showWhen(rotate::on);
        swapBack.showWhen(autoSwap::on);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            clearAim();
            return;
        }
        if (restoreSlot >= 0 && --restoreTicks <= 0) {
            CombatUtil.selectSlot(restoreSlot);
            restoreSlot = -1;
        }
        if (mc.player.isOnGround() || mc.player.getAbilities().flying
                || mc.player.getVelocity().y >= 0.0
                || FallTracker.distance() < minFall.getDouble()
                || notWhileUsing.on() && mc.player.isUsingItem()) {
            clearAim();
            return;
        }

        boolean holding = CombatUtil.isMace(mc.player.getMainHandStack());
        int maceSlot = holding ? mc.player.getInventory().getSelectedSlot()
                : autoSwap.on() ? CombatUtil.findHotbar(CombatUtil::isMace) : -1;
        if (maceSlot < 0) {
            clearAim();
            return;
        }

        List<LivingEntity> candidates = CombatUtil.targetsInRange(range.getDouble(), targets, ignoreFriends.on());
        LivingEntity target = CombatUtil.best(candidates, priority.get(), fov.getDouble());
        if (target == null) {
            clearAim();
            nextAttackAt = 0L;
            return;
        }

        boolean aimed;
        if (rotate.on()) {
            float[] wanted = CombatUtil.rotationsTo(target.getBoundingBox().getCenter());
            updateAim(wanted[0], wanted[1]);
            boolean close = Math.abs(MathHelper.wrapDegrees(wanted[0] - aimYaw)) <= 2.5F
                    && Math.abs(wanted[1] - aimPitch) <= 2.5F;
            aimTicks = close ? aimTicks + 1 : 0;
            aimed = aimTicks >= 2;
        } else {
            aimed = mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == target;
        }
        if (!aimed || mc.player.getAttackCooldownProgress(0.5F) < minCooldown.getFloat()) {
            return;
        }

        long now = System.currentTimeMillis();
        if (nextAttackAt == 0L) {
            nextAttackAt = now + (long) attackDelay.sample();
        }
        if (now < nextAttackAt) {
            return;
        }

        if (!holding) {
            if (restoreSlot < 0 && swapBack.on()) {
                restoreSlot = mc.player.getInventory().getSelectedSlot();
            }
            CombatUtil.selectSlot(maceSlot);
        }
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        if (restoreSlot >= 0) {
            restoreTicks = 2;
        }
        nextAttackAt = 0L;
        aimTicks = 0;
    }

    private void updateAim(float targetYaw, float targetPitch) {
        if (!aimInit) {
            aimYaw = mc.player.getYaw();
            aimPitch = mc.player.getPitch();
            aimInit = true;
        }
        float speed = aimSpeed.getFloat();
        float[] next = CombatUtil.stepRotation(aimYaw, aimPitch, targetYaw, targetPitch, speed, speed, 1.0F);
        aimYaw = next[0];
        aimPitch = next[1];
        if (silentAim.on()) {
            SilentRotationManager.set(this, aimYaw, aimPitch, 8);
        } else {
            SilentRotationManager.clear(this);
            mc.player.setYaw(aimYaw);
            mc.player.setPitch(aimPitch);
        }
    }

    private void clearAim() {
        SilentRotationManager.clear(this);
        aimInit = false;
        aimTicks = 0;
    }

    @Override
    protected void onDisable() {
        clearAim();
        if (mc.player != null && restoreSlot >= 0) {
            CombatUtil.selectSlot(restoreSlot);
        }
        restoreSlot = -1;
        nextAttackAt = 0L;
    }
}
