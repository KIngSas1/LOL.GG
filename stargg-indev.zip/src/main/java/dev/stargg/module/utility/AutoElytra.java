package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.FriendManager;
import dev.stargg.util.TargetFilters;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

/** Elytra/chestplate swapping logic ported from the supplied Cyemer client. */
public final class AutoElytra extends Module {

    private final BooleanSetting randomization = add(new BooleanSetting("Randomization", false));
    private final NumberSetting randomMinDelay = add(new NumberSetting("Min Random (ms)", 0.0, 0.0, 500.0, 1.0));
    private final NumberSetting randomMaxDelay = add(new NumberSetting("Max Random (ms)", 25.0, 0.0, 500.0, 1.0));
    private static final String[] TARGET_OPTIONS = {
            "Players", "Mobs", "Peaceful", "Neutral", "Ignore naked", "Ignore invisible", "Ignore behind walls"
    };

    private final MultiSelectSetting targetFilter = add(new MultiSelectSetting("Target settings", TARGET_OPTIONS, "Players"));
    private final BooleanSetting autoMaceSync = add(new BooleanSetting("AutoMace Sync", true));
    private final BooleanSetting inAir = add(new BooleanSetting("In Air", false));
    private final BooleanSetting onPearl = add(new BooleanSetting("On Pearl", true));
    private final BooleanSetting disableOnGround = add(new BooleanSetting("Disable on Ground", true));
    private final NumberSetting reequipDelay = add(new NumberSetting("Reequip Delay (ms)", 100.0, 0.0, 1000.0, 10.0));
    private final NumberSetting heightDiff = add(new NumberSetting("Height Diff", 4.0, 1.0, 10.0, 0.1));
    private final NumberSetting heightRange = add(new NumberSetting("Height Range", 10.0, 1.0, 50.0, 0.5));
    private final NumberSetting preHitRange = add(new NumberSetting("Mace Pre-Hit Range", 3.4, 2.5, 5.0, 0.1));
    private final NumberSetting minDropDistance = add(new NumberSetting("Min Drop Dist", 1.5, 0.5, 5.0, 0.1));

    private boolean swapInProgress;
    private boolean swapTargetElytra;
    private int swapOriginalSlot = -1;
    private int swapWaitTicks;
    private long swapUseAt;
    private boolean swapUseSent;
    private boolean queuedSwap;
    private boolean queuedSwapTargetElytra;
    private long queuedSwapAt;
    private int airTicks;
    private double highestY;
    private boolean wasOnGround = true;
    private long suppressChestplateUntil;
    private long maceReequipAt;
    private long pearlReequipAt;
    private long autoMaceSyncPauseUntil;
    private long autoMaceSyncActiveUntil;

    public AutoElytra() {
        super("AutoElytra", "Automatically swaps Elytra and chestplate around mace and pearl windows", Category.COMBAT);
        icon(Icon.AUTO_ELYTRA);
        randomMinDelay.showWhen(randomization::on);
        randomMaxDelay.showWhen(randomization::on);
    }

    @Override
    protected void onEnable() {
        resetSwapState();
        clearQueuedSwap();
        suppressChestplateUntil = 0L;
        maceReequipAt = 0L;
        pearlReequipAt = 0L;
        autoMaceSyncPauseUntil = 0L;
        autoMaceSyncActiveUntil = 0L;
        if (mc.player != null) {
            highestY = mc.player.getY();
            wasOnGround = mc.player.isOnGround();
        }
        airTicks = 0;
    }

    @Override
    protected void onDisable() {
        finishSwap();
        clearQueuedSwap();
        airTicks = 0;
        suppressChestplateUntil = 0L;
        maceReequipAt = 0L;
        pearlReequipAt = 0L;
        autoMaceSyncPauseUntil = 0L;
        autoMaceSyncActiveUntil = 0L;
    }

    public static void notifyMaceHit() {
        AutoElytra module = dev.stargg.StarGG.modules().get(AutoElytra.class);
        if (module != null) module.onMaceHit();
    }

    /** Called by AutoMace when a mace hit or the pre-hit window is detected. */
    public void onMaceHit() {
        if (!isEnabled() || mc.player == null) return;
        maceReequipAt = System.currentTimeMillis() + (long) reequipDelay.getDouble();
        suppressChestplateUntil = System.currentTimeMillis() + (long) reequipDelay.getDouble()
                + (long) randomMaxDelay.getDouble() + 250L;
    }

    public void onAutoMaceSync() {
        if (!isEnabled() || mc.player == null || !autoMaceSync.on()) return;
        long now = System.currentTimeMillis();
        autoMaceSyncActiveUntil = now + 400L;

        // Do not fight an in-flight chestplate swap. If an Elytra re-equip was already
        // underway, cancel it cleanly before requesting the chestplate for the mace hit.
        if (now >= autoMaceSyncPauseUntil && isWearingElytra() && findChestplateSlot() >= 0) {
            if (swapInProgress && swapTargetElytra) {
                finishSwap();
            }
            if (!swapInProgress && (!queuedSwap || queuedSwapTargetElytra)) {
                clearQueuedSwap();
                queueSwap(false, 0L);
            }
        }
    }

    /** AutoMace waits for armor swapping to finish before changing to the mace or attacking. */
    public boolean isMaceAttackReady() {
        if (!isEnabled() || !autoMaceSync.on() || mc.player == null) return true;
        if (swapInProgress || queuedSwap) return false;
        if (System.currentTimeMillis() < autoMaceSyncPauseUntil) return true;
        // If the player has no chestplate available, do not deadlock AutoMace.
        return !isWearingElytra() || findChestplateSlot() < 0;
    }

    public double getMacePreHitRange() {
        return preHitRange.getDouble();
    }

    /** Called from the item-use mixin when the local player uses an ender pearl. */
    public void onPearlThrow() {
        if (!isEnabled() || !onPearl.on() || mc.player == null) return;
        pearlReequipAt = System.currentTimeMillis() + (long) reequipDelay.getDouble();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        updateAirTracking();
        processPendingEventReequips();

        long now = System.currentTimeMillis();
        boolean chestplateSwapPending = (swapInProgress && !swapTargetElytra)
                || (queuedSwap && !queuedSwapTargetElytra);
        boolean syncPriority = autoMaceSync.on() && (now < autoMaceSyncActiveUntil || chestplateSwapPending);
        boolean forceElytraForAir = !syncPriority && inAir.on() && shouldForceElytraInAir();
        if (syncPriority && queuedSwap && queuedSwapTargetElytra) clearQueuedSwap();

        if (forceElytraForAir) {
            if (!isWearingElytra()) {
                if (swapInProgress && !swapTargetElytra) finishSwap();
                queueSwap(true, 0L);
            }
            if (queuedSwap && !queuedSwapTargetElytra) clearQueuedSwap();
        } else if (disableOnGround.on() && mc.player.isOnGround()) {
            if (isWearingElytra()) queueSwap(false, 0L);
            if (queuedSwap && queuedSwapTargetElytra) clearQueuedSwap();
        } else if (shouldSwapToChestplateForCombat()) {
            queueSwap(false, 0L);
        }

        if (!swapInProgress) tryStartQueuedSwap();
        if (swapInProgress) processSwap();
    }

    private void scheduleElytraReequip(long delay) {
        maceReequipAt = System.currentTimeMillis() + Math.max(0L, delay);
    }

    private void processPendingEventReequips() {
        long now = System.currentTimeMillis();
        boolean consumedMace = false;
        if (maceReequipAt > 0L && now >= maceReequipAt) {
            queueSwap(true, 0L);
            maceReequipAt = 0L;
            consumedMace = true;
        }
        if (pearlReequipAt > 0L && now >= pearlReequipAt) {
            if (!consumedMace) queueSwap(true, 0L);
            pearlReequipAt = 0L;
        }
    }

    private boolean shouldSwapToChestplateForCombat() {
        if (!isWearingElytra() || System.currentTimeMillis() < suppressChestplateUntil) return false;
        if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isInLava() || mc.player.isClimbing()) return false;
        if (airTicks < 4 || getManualDropDistance() < minDropDistance.getDouble()) return false;
        if (mc.player.getVelocity().y > -0.03) return false;

        LivingEntity nearest = findNearestTarget(Math.max(heightRange.getDouble(), preHitRange.getDouble()));
        if (nearest == null) return false;
        double diffY = mc.player.getY() - nearest.getY();
        if (diffY <= 0.0) return false;
        double horizontalDistance = horizontalDistanceTo(nearest);
        double totalDistance = mc.player.distanceTo(nearest);
        boolean higherThanEnemy = diffY >= heightDiff.getDouble() && horizontalDistance <= heightRange.getDouble();
        boolean nearlyInMaceRange = diffY >= 1.0 && totalDistance <= preHitRange.getDouble();
        return higherThanEnemy || nearlyInMaceRange;
    }

    private void queueSwap(boolean toElytra, long baseDelayMs) {
        queuedSwap = true;
        queuedSwapTargetElytra = toElytra;
        queuedSwapAt = System.currentTimeMillis() + Math.max(0L, baseDelayMs);
    }

    private void clearQueuedSwap() {
        queuedSwap = false;
        queuedSwapTargetElytra = false;
        queuedSwapAt = 0L;
    }

    private void tryStartQueuedSwap() {
        if (!queuedSwap || mc.player == null || System.currentTimeMillis() < queuedSwapAt) return;
        if (queuedSwapTargetElytra && isWearingElytra()) {
            clearQueuedSwap();
            return;
        }
        if (!queuedSwapTargetElytra && !isWearingElytra() && isChestplate(mc.player.getEquippedStack(EquipmentSlot.CHEST))) {
            clearQueuedSwap();
            return;
        }
        startSwap(queuedSwapTargetElytra);
        clearQueuedSwap();
    }

    private boolean startSwap(boolean toElytra) {
        if (mc.player == null || swapInProgress) return false;
        int targetSlot = toElytra ? findElytraSlot() : findChestplateSlot();
        if (targetSlot < 0) return false;
        swapOriginalSlot = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(targetSlot);
        swapTargetElytra = toElytra;
        swapWaitTicks = 0;
        swapUseSent = false;
        swapUseAt = System.currentTimeMillis() + randomExtraDelay();
        swapInProgress = true;
        return true;
    }

    private void processSwap() {
        if (mc.player == null || mc.interactionManager == null) {
            finishSwap();
            return;
        }
        if (!swapUseSent) {
            if (System.currentTimeMillis() >= swapUseAt) {
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                mc.player.swingHand(Hand.MAIN_HAND);
                swapUseSent = true;
            }
            return;
        }

        swapWaitTicks++;
        boolean wearingElytra = isWearingElytra();
        boolean swapComplete = swapTargetElytra ? wearingElytra
                : !wearingElytra && isChestplate(mc.player.getEquippedStack(EquipmentSlot.CHEST));
        if (swapComplete || swapWaitTicks >= 10) {
            if (!swapComplete) handleSwapFailure();
            finishSwap();
        }
    }

    private void handleSwapFailure() {
        autoMaceSyncPauseUntil = System.currentTimeMillis() + 250L;
        if (!isWearingElytra() && findElytraSlot() >= 0) {
            clearQueuedSwap();
            queueSwap(true, 0L);
        }
    }

    private void finishSwap() {
        if (mc.player != null && swapOriginalSlot >= 0 && swapOriginalSlot < 9) {
            mc.player.getInventory().setSelectedSlot(swapOriginalSlot);
        }
        resetSwapState();
    }

    private void resetSwapState() {
        swapInProgress = false;
        swapTargetElytra = false;
        swapOriginalSlot = -1;
        swapWaitTicks = 0;
        swapUseAt = 0L;
        swapUseSent = false;
    }

    private void updateAirTracking() {
        boolean onGround = mc.player.isOnGround();
        if (onGround) {
            highestY = mc.player.getY();
            airTicks = 0;
        } else if (wasOnGround) {
            highestY = mc.player.getY();
            airTicks = 1;
        } else {
            highestY = Math.max(highestY, mc.player.getY());
            airTicks++;
        }
        wasOnGround = onGround;
    }

    private double getManualDropDistance() {
        return Math.max(0.0, highestY - mc.player.getY());
    }

    private boolean shouldForceElytraInAir() {
        if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isInLava() || mc.player.isClimbing()) return false;
        return getGroundDistanceBelowPlayer() >= 2.0;
    }

    private double getGroundDistanceBelowPlayer() {
        Vec3d start = new Vec3d(mc.player.getX(), mc.player.getBoundingBox().minY + 0.05, mc.player.getZ());
        Vec3d end = start.add(0.0, -64.0, 0.0);
        var hit = mc.world.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, mc.player));
        return hit.getType() == HitResult.Type.MISS ? Double.MAX_VALUE
                : Math.max(0.0, start.y - hit.getPos().y);
    }

    private double horizontalDistanceTo(LivingEntity target) {
        double dx = mc.player.getX() - target.getX();
        double dz = mc.player.getZ() - target.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    private LivingEntity findNearestTarget(double maxDistance) {
        if (mc.world == null || mc.player == null) return null;
        return mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(maxDistance),
                        entity -> entity instanceof LivingEntity)
                .stream()
                .filter(LivingEntity.class::isInstance)
                .map(LivingEntity.class::cast)
                .filter(this::isValidCombatTarget)
                .filter(target -> mc.player.distanceTo(target) <= maxDistance)
                .min(Comparator.comparingDouble(target -> mc.player.squaredDistanceTo(target)))
                .orElse(null);
    }

    private boolean isValidCombatTarget(LivingEntity target) {
        if (!TargetFilters.matches(target, targetFilter, mc)) return false;
        if (target instanceof PlayerEntity player) {
            return !player.isSpectator()
                    && !FriendManager.getInstance().isFriend(player.getUuid())
                    && !FriendManager.getInstance().isFriend(player.getName().getString());
        }
        return true;
    }

    private boolean isWearingElytra() {
        return mc.player != null && mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
    }

    private int findChestplateSlot() {
        if (mc.player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (isChestplate(stack)) return slot;
        }
        return -1;
    }

    private int findElytraSlot() {
        if (mc.player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(Items.ELYTRA)) return slot;
        }
        return -1;
    }

    private boolean isChestplate(ItemStack stack) {
        if (stack == null || stack.isEmpty() || stack.isOf(Items.ELYTRA)) return false;
        EquippableComponent component = stack.get(DataComponentTypes.EQUIPPABLE);
        return component != null && component.slot() == EquipmentSlot.CHEST;
    }

    private long randomExtraDelay() {
        if (!randomization.on()) return 0L;
        long min = Math.max(0L, (long) randomMinDelay.getDouble());
        long max = Math.max(min, (long) randomMaxDelay.getDouble());
        return min == max ? min : ThreadLocalRandom.current().nextLong(min, max + 1L);
    }
}
