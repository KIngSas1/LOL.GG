package dev.stargg.module.combat;

import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.CombatUtil;
import dev.stargg.util.FallTracker;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/** While falling, swaps to a hotbar mace for the hit you are making, then swaps back. */
public final class MaceSwap extends WeaponSwapModule {

    private final NumberSetting minFall = add(new NumberSetting("Min fall distance", 1.5, 0.0, 20.0, 0.1));
    private final BooleanSetting onlyAirborne = add(new BooleanSetting("Only airborne", true));

    public MaceSwap() {
        super("Mace Swap", "Swaps to your mace for a hit while you are falling, then back");
    }

    @Override
    protected boolean isWanted(ItemStack held) {
        return CombatUtil.isMace(held);
    }

    @Override
    protected int findSlot() {
        return CombatUtil.findHotbar(CombatUtil::isMace);
    }

    @Override
    protected boolean shouldSwap(LivingEntity target) {
        if (onlyAirborne.on() && mc.player.isOnGround()) {
            return false;
        }
        return FallTracker.distance() >= minFall.getDouble();
    }
}
