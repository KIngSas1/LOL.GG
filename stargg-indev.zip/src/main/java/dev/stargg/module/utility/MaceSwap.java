package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

import java.util.concurrent.ThreadLocalRandom;

/** Swaps to a mace for the intercepted manual hit and restores the original hotbar slot. */
public final class MaceSwap extends Module {

    private final BooleanSetting notOnAxe = add(new BooleanSetting("Not on Axe (stunslam)", true));
    private final BooleanSetting weaponOnly = add(new BooleanSetting("Weapon Only", true));
    private final NumberSetting densityHeight = add(new NumberSetting("Density Height", 3.0, 0.0, 10.0, 1.0));
    private final BooleanSetting randomization = add(new BooleanSetting("Randomization", false));
    private final NumberSetting randomMinDelay = add(new NumberSetting("Random Min (ms)", 0.0, 0.0, 500.0, 1.0));
    private final NumberSetting randomMaxDelay = add(new NumberSetting("Random Max (ms)", 25.0, 0.0, 500.0, 1.0));

    private boolean swapping;
    private boolean executingAttack;
    private int originalSlot = -1;
    private int swapTicks;
    private int targetSlot = -1;
    private LivingEntity pendingTarget;
    private boolean attackSent;
    private int restoreTicks;
    private long attackAt;
    private double highestY;

    public MaceSwap() {
        super("MaceSwap", "Swaps to a mace for the next manual attack", Category.COMBAT);
        randomMinDelay.showWhen(randomization::on);
        randomMaxDelay.showWhen(randomization::on);
    }

    @Override
    protected void onEnable() {
        if (mc.player != null) highestY = mc.player.getY();
        reset();
    }

    @Override
    protected void onDisable() {
        restoreSlot();
    }

    public boolean isExecutingAttack() {
        return executingAttack;
    }

    /** Called by the attack mixin before vanilla sends the clicked attack. */
    public boolean interceptAttack(Entity entity) {
        if (!isEnabled() || swapping || mc.player == null || mc.world == null || mc.currentScreen != null
                || !(entity instanceof LivingEntity target) || !target.isAlive() || target == mc.player
                || !(mc.crosshairTarget instanceof EntityHitResult hit) || hit.getEntity() != target) {
            return false;
        }

        ItemStack held = mc.player.getMainHandStack();
        if (weaponOnly.on() && !isWeapon(held)) return false;
        if (notOnAxe.on() && held.getItem() instanceof AxeItem) return false;
        if (held.isOf(Items.MACE)) return false;

        double dropDistance = Math.max(0.0, highestY - mc.player.getY());
        int maceSlot = dropDistance > densityHeight.getDouble()
                ? findMaceWithEnchantment(Enchantments.DENSITY)
                : findMaceWithEnchantment(Enchantments.BREACH);
        if (maceSlot < 0 && dropDistance > densityHeight.getDouble()) {
            maceSlot = findMace();
        }
        if (maceSlot < 0) return false;

        originalSlot = mc.player.getInventory().getSelectedSlot();
        targetSlot = maceSlot;
        pendingTarget = target;
        attackSent = false;
        restoreTicks = 0;
        swapping = true;
        swapTicks = 0;
        long min = randomization.on() ? (long) randomMinDelay.getDouble() : 0L;
        long max = randomization.on() ? (long) Math.max(min, randomMaxDelay.getDouble()) : 0L;
        attackAt = System.currentTimeMillis() + (min == max ? min : ThreadLocalRandom.current().nextLong(min, max + 1L));
        mc.player.getInventory().setSelectedSlot(maceSlot);
        return true;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            restoreSlot();
            return;
        }
        if (mc.player.isOnGround()) {
            highestY = mc.player.getY();
        } else {
            highestY = Math.max(highestY, mc.player.getY());
        }
        if (!swapping) return;

        swapTicks++;
        if (!attackSent && System.currentTimeMillis() >= attackAt) {
            if (targetSlot >= 0 && targetSlot < 9) mc.player.getInventory().setSelectedSlot(targetSlot);
            boolean stillValid = pendingTarget != null && pendingTarget.isAlive()
                    && mc.player.canSee(pendingTarget)
                    && mc.player.distanceTo(pendingTarget) <= 2.95F
                    && mc.player.getAttackCooldownProgress(0.5F) >= 1.0F
                    && mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == pendingTarget;
            if (stillValid) {
                executingAttack = true;
                try {
                    mc.interactionManager.attackEntity(mc.player, pendingTarget);
                    mc.player.swingHand(Hand.MAIN_HAND);
                } finally {
                    executingAttack = false;
                }
            }
            attackSent = true;
            restoreTicks = 0;
        } else if (attackSent && ++restoreTicks >= 2) {
            restoreSlot();
        }
    }

    private boolean isWeapon(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        return stack.getItem() instanceof AxeItem || stack.isIn(ItemTags.SWORDS)
                || stack.isOf(Items.MACE) || stack.isOf(Items.TRIDENT);
    }

    private int findMace() {
        if (mc.player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(Items.MACE)) return slot;
        }
        return -1;
    }

    private int findMaceWithEnchantment(RegistryKey<Enchantment> enchantmentKey) {
        if (mc.player == null || mc.world == null) return -1;
        RegistryEntry<Enchantment> enchantment = mc.world.getRegistryManager()
                .getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(enchantmentKey);
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isOf(Items.MACE) && EnchantmentHelper.getLevel(enchantment, stack) > 0) return slot;
        }
        return -1;
    }

    private void restoreSlot() {
        if (mc.player != null && originalSlot >= 0 && originalSlot < 9) {
            mc.player.getInventory().setSelectedSlot(originalSlot);
        }
        reset();
    }

    private void reset() {
        swapping = false;
        executingAttack = false;
        originalSlot = -1;
        targetSlot = -1;
        pendingTarget = null;
        attackSent = false;
        restoreTicks = 0;
        swapTicks = 0;
        attackAt = 0L;
    }
}
