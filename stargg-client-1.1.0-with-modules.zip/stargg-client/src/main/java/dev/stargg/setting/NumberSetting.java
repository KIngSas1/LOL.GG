package dev.stargg.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumberSetting extends Setting<Double> {

    private final double min;
    private final double max;
    private final double step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getDouble() {
        return value;
    }

    public float getFloat() {
        return value.floatValue();
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    /** Clamps to [min, max] and snaps to the step size. */
    @Override
    public void set(Double newValue) {
        double v = Math.max(min, Math.min(max, newValue));
        if (step > 0) {
            v = min + Math.round((v - min) / step) * step;
            v = Math.max(min, Math.min(max, v));
        }
        super.set(v);
    }

    /** Text shown next to the slider, e.g. "4" or "1.5". */
    public String display() {
        if (step >= 1) {
            return Integer.toString(getInt());
        }
        int decimals = Math.max(1, (int) Math.ceil(-Math.log10(step)));
        return String.format("%." + decimals + "f", value);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement json) {
        if (json != null && json.isJsonPrimitive()) {
            set(json.getAsDouble());
        }
    }
}
