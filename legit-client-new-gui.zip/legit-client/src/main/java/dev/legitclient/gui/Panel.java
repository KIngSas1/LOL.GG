package dev.legitclient.gui;

import dev.legitclient.LegitClient;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.util.Draw;
import dev.legitclient.util.Ui;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * One draggable column holding all modules of a category. It is opened and closed from the main
 * panel (a clip animation), collapsed with the chevron in its header (or right click), and while a
 * search is active it shows only the matching modules.
 */
final class Panel implements GuiPanel {

    private final Category category;
    private final List<ModuleButton> buttons = new ArrayList<>();
    private int x;
    private int y;
    private boolean shown;
    private boolean open = true;
    private boolean dragging;
    private int dragOffsetX;
    private int dragOffsetY;
    private int scroll;
    private String filter = "";
    private float showAnimation;
    private float openAnimation = 1f;

    Panel(Category category, int defaultX, int defaultY) {
        this.category = category;
        for (Module module : LegitClient.modules().inCategory(category)) {
            buttons.add(new ModuleButton(module));
        }
        int[] saved = LegitClient.config().getPanelPosition(category.title());
        this.x = saved != null ? saved[0] : defaultX;
        this.y = saved != null ? saved[1] : defaultY;
    }

    Category category() {
        return category;
    }

    boolean isShown() {
        return shown;
    }

    void toggleShown() {
        shown = !shown;
    }

    void setShown(boolean shown) {
        this.shown = shown;
    }

    void setOpen(boolean open) {
        this.open = open;
    }

    /** Slides the settings of the given module open (used by the gear / Profiles buttons). */
    void expand(Class<? extends Module> type) {
        for (ModuleButton button : buttons) {
            if (type.isInstance(button.getModule())) {
                button.setExpanded(true);
            }
        }
    }

    void setFilter(String text) {
        filter = text.toLowerCase(Locale.ROOT).trim();
    }

    @Override
    public void setScroll(int scroll) {
        this.scroll = scroll;
    }

    // ---------------------------------------------------------------- layout

    private boolean searching() {
        return !filter.isEmpty();
    }

    /** Whether the panel should currently be on screen. */
    private boolean wanted() {
        if (!searching()) {
            return shown;
        }
        for (ModuleButton button : buttons) {
            if (button.matches(filter)) {
                return true;
            }
        }
        return false;
    }

    private int contentHeight() {
        int h = 0;
        for (ModuleButton button : buttons) {
            if (button.matches(filter)) {
                h += button.height();
            }
        }
        return h;
    }

    private int height() {
        return Theme.HEADER_HEIGHT + Math.round(contentHeight() * openAnimation);
    }

    private int visibleHeight() {
        return Math.max(1, Math.round(height() * showAnimation));
    }

    private int top() {
        return y - scroll;
    }

    @Override
    public int bottom() {
        return showAnimation > 0f ? y + height() : 0;
    }

    // ------------------------------------------------------------- rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY) {
        showAnimation = Theme.approach(showAnimation, wanted() ? 1f : 0f);
        openAnimation = Theme.approach(openAnimation, open || searching() ? 1f : 0f);
        if (showAnimation <= 0f) {
            return;
        }

        int w = Theme.PANEL_WIDTH;
        int top = top();
        int visible = visibleHeight();
        Draw.shadow(context, x, top, w, visible);
        context.enableScissor(x, top, x + w, top + visible);

        Draw.rounded(context, x, top, w, Theme.HEADER_HEIGHT, 3, Theme.bg(Theme.HEADER));
        Draw.rect(context, x, top + Theme.HEADER_HEIGHT / 2, w, Theme.HEADER_HEIGHT / 2, Theme.bg(Theme.HEADER));
        Ui.icon(context, category.tex(), x + Theme.PADDING, top + (Theme.HEADER_HEIGHT - 10) / 2, 10, Theme.TEXT);
        Ui.textMiddle(context, category.title(), x + Theme.PADDING + 17, top, Theme.HEADER_HEIGHT, Theme.TEXT);
        Ui.icon(context, open || searching() ? Ui.Tex.CHEVRON_UP : Ui.Tex.CHEVRON_DOWN,
                x + w - Theme.PADDING - 8, top + (Theme.HEADER_HEIGHT - 8) / 2, 8, Theme.TEXT_DIM);

        if (openAnimation > 0f) {
            context.enableScissor(x, top + Theme.HEADER_HEIGHT, x + w, top + height());
            int cursor = top + Theme.HEADER_HEIGHT;
            for (ModuleButton button : buttons) {
                if (button.matches(filter)) {
                    button.render(context, x, cursor, w, mouseX, mouseY);
                    cursor += button.height();
                }
            }
            context.disableScissor();
        }
        context.disableScissor();
    }

    private boolean over(double mouseX, double mouseY) {
        return showAnimation > 0.3f && Draw.inside(mouseX, mouseY, x, top(), Theme.PANEL_WIDTH, visibleHeight());
    }

    /** @return the module whose row is under the mouse, or null. */
    @Override
    public Module hoveredModule(double mouseX, double mouseY) {
        if (over(mouseX, mouseY) && mouseY >= top() + Theme.HEADER_HEIGHT) {
            for (ModuleButton button : buttons) {
                if (button.matches(filter) && button.rowHovered(mouseX, mouseY)) {
                    return button.getModule();
                }
            }
        }
        return null;
    }

    // ----------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!over(mouseX, mouseY)) {
            return false;
        }
        if (mouseY < top() + Theme.HEADER_HEIGHT) {
            // Left click on the chevron (or right click anywhere) collapses; otherwise left click starts a drag.
            boolean chevron = mouseX >= x + Theme.PANEL_WIDTH - 24;
            if (button == 1 || (button == 0 && chevron)) {
                open = !open;
            } else if (button == 0) {
                dragging = true;
                dragOffsetX = (int) mouseX - x;
                dragOffsetY = (int) mouseY - top();
            }
            return true;
        }
        if (openAnimation > 0.99f) {
            for (ModuleButton moduleButton : buttons) {
                if (moduleButton.matches(filter) && moduleButton.mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY) {
        if (dragging) {
            x = Math.max(0, (int) mouseX - dragOffsetX);
            y = Math.max(0, (int) mouseY - dragOffsetY + scroll);
        }
        buttons.forEach(button -> button.mouseDragged(mouseX));
    }

    @Override
    public void mouseReleased() {
        if (dragging) {
            dragging = false;
            LegitClient.config().setPanelPosition(category.title(), x, y);
        }
        buttons.forEach(ModuleButton::mouseReleased);
    }
}
