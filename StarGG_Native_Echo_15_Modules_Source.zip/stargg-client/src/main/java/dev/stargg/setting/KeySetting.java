package dev.stargg.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** A key-code setting with a capture control in STAR.GG's native settings UI. */
public final class KeySetting extends Setting<Integer> {

    public KeySetting(String name, int defaultKey) {
        super(name, defaultKey);
    }

    public int getKey() {
        return value;
    }

    @Override
    public void set(Integer key) {
        if (key == null) {
            return;
        }
        super.set(Math.max(-1, Math.min(512, key)));
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement json) {
        if (json != null && json.isJsonPrimitive() && json.getAsJsonPrimitive().isNumber()) {
            set(json.getAsInt());
        }
    }
}
