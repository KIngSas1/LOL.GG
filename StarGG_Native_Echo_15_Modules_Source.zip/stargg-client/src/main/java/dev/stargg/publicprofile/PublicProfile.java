package dev.stargg.publicprofile;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A profile published for others to use: a snapshot of the module settings plus listing information.
 * Plain data, serialised with Gson by the services.
 */
public final class PublicProfile {

    public long id;
    public String name = "Profile";
    /** Null when the owner uploaded anonymously. */
    public String owner;
    /** Internal owner key (account name) used for ownership checks; never shown. */
    public String ownerKey;
    public String description = "";
    public List<String> tags = new ArrayList<>();
    public long version = 1;
    public long likes;
    public long dislikes;
    public long downloads;
    public long createdMillis;
    public long updatedMillis;
    public String shareCode;
    public boolean listedPublicly = true;
    public boolean uploadAnonymously;
    /** The profile content in the format of {@code ConfigManager#exportProfile}. */
    public String data;
    public List<PublicProfileReview> reviews = new ArrayList<>();

    public String ownerDisplay() {
        return owner == null || owner.isBlank() ? "Anonymous" : owner;
    }

    public String shareCodeUpper() {
        return shareCode == null ? "" : shareCode.toUpperCase(Locale.ROOT);
    }

    /** Wilson-style score so a single like does not outrank a well-rated profile. */
    public double score() {
        long n = likes + dislikes;
        if (n == 0) {
            return 0;
        }
        double p = (double) likes / n;
        double z = 1.96;
        return (p + z * z / (2 * n) - z * Math.sqrt((p * (1 - p) + z * z / (4.0 * n)) / n)) / (1 + z * z / n);
    }

    /** A copy without the (potentially large) profile data and reviews, for list views. */
    public PublicProfile summary() {
        PublicProfile copy = new PublicProfile();
        copy.id = id;
        copy.name = name;
        copy.owner = owner;
        copy.ownerKey = ownerKey;
        copy.description = description;
        copy.tags = new ArrayList<>(tags);
        copy.version = version;
        copy.likes = likes;
        copy.dislikes = dislikes;
        copy.downloads = downloads;
        copy.createdMillis = createdMillis;
        copy.updatedMillis = updatedMillis;
        copy.shareCode = shareCode;
        copy.listedPublicly = listedPublicly;
        copy.uploadAnonymously = uploadAnonymously;
        return copy;
    }
}
