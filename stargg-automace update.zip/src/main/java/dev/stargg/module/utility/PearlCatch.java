package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.SilentRotationManager;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Plans a wind-charge/ender-pearl interception and executes it as a short state machine. */
public final class PearlCatch extends Module {

    private static final double PROJECTILE_SPEED = 1.5;
    private static final double PEARL_DRAG = 0.99;
    private static final double PEARL_GRAVITY = 0.03;
    private static final double MAX_INTERCEPT_DISTANCE_SQUARED = 0.36;
    private static final int MAX_FLIGHT_TICKS = 30;

    private final ModeSetting aimMode = add(new ModeSetting("Aim mode", "Upward", "Upward", "Current aim"));
    private final NumberSetting aimSpeed = add(new NumberSetting("Aim speed", 10.0, 1.0, 10.0, 0.1));
    private final BooleanSetting silentAim = add(new BooleanSetting("Silent aim", true));
    private final NumberSetting chargeDelay = add(new NumberSetting("Charge delay", 0.0, 0.0, 10.0, 1.0));

    private State state = State.IDLE;
    private InterceptPlan plan;
    private int pearlSlot = -1;
    private int chargeSlot = -1;
    private int savedSlot = -1;
    private int stateTicks;
    private int ticksSincePearl;
    private float currentYaw;
    private float currentPitch;
    private boolean rotationInitialized;

    public PearlCatch() {
        super("Pearl Catch", "Throws a pearl, then a wind charge to intercept it", Category.UTILITY);
        icon(Icon.PEARL_CATCH);
    }

    @Override
    protected void onEnable() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            abort();
            return;
        }
        pearlSlot = findHotbarSlot(Items.ENDER_PEARL);
        chargeSlot = findHotbarSlot(Items.WIND_CHARGE);
        if (pearlSlot < 0 || chargeSlot < 0) {
            abort();
            return;
        }
        savedSlot = mc.player.getInventory().getSelectedSlot();
        int delay = chargeDelay.getInt();
        plan = aimMode.is("Current aim")
                ? findCurrentAimPlan(Math.max(3, delay))
                : findUpwardPlan(delay);
        if (plan == null) {
            abort();
            return;
        }
        state = State.AIMING_PEARL;
        stateTicks = 0;
        ticksSincePearl = 0;
        rotationInitialized = false;
        setRotation(plan.pearlYaw, plan.pearlPitch);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || plan == null) {
            abort();
            return;
        }
        stateTicks++;
        if (state == State.AIMING_CHARGE || state == State.WAITING_FOR_CHARGE) {
            ticksSincePearl++;
        }
        if (stateTicks > 40 && state != State.WAITING_FOR_CHARGE) {
            abort();
            return;
        }

        switch (state) {
            case AIMING_PEARL -> {
                setRotation(plan.pearlYaw, plan.pearlPitch);
                if (isRotationReady()) {
                    state = State.THROWING_PEARL;
                }
            }
            case THROWING_PEARL -> {
                throwFromSlot(pearlSlot);
                state = State.AIMING_CHARGE;
                stateTicks = 0;
                ticksSincePearl = 0;
                rotationInitialized = false;
                setRotation(plan.chargeYaw, plan.chargePitch);
            }
            case AIMING_CHARGE -> {
                setRotation(plan.chargeYaw, plan.chargePitch);
                if (isRotationReady()) {
                    state = State.WAITING_FOR_CHARGE;
                    stateTicks = 0;
                } else if (plan.absoluteChargeTiming && ticksSincePearl >= plan.chargeTick) {
                    abort();
                }
            }
            case WAITING_FOR_CHARGE -> {
                boolean ready = plan.absoluteChargeTiming
                        ? ticksSincePearl >= plan.chargeTick
                        : stateTicks >= plan.chargeTick;
                if (ready) {
                    throwFromSlot(chargeSlot);
                    state = State.FINISHED;
                }
            }
            case FINISHED -> setEnabled(false);
            default -> abort();
        }
    }

    private void setRotation(float targetYaw, float targetPitch) {
        if (!rotationInitialized) {
            currentYaw = mc.player.getYaw();
            currentPitch = mc.player.getPitch();
            rotationInitialized = true;
        }
        float yawDelta = MathHelper.wrapDegrees(targetYaw - currentYaw);
        float pitchDelta = targetPitch - currentPitch;
        currentYaw += MathHelper.clamp(yawDelta, -aimSpeed.getFloat(), aimSpeed.getFloat());
        currentPitch = MathHelper.clamp(currentPitch + MathHelper.clamp(pitchDelta, -aimSpeed.getFloat(), aimSpeed.getFloat()), -90.0F, 90.0F);
        if (silentAim.on()) {
            SilentRotationManager.set(this, currentYaw, currentPitch, 8);
        } else {
            SilentRotationManager.clear(this);
            mc.player.setYaw(currentYaw);
            mc.player.setPitch(currentPitch);
        }
    }

    private boolean isRotationReady() {
        float yawError = Math.abs(MathHelper.wrapDegrees(plan.chargeYaw - currentYaw));
        float pitchError = Math.abs(plan.chargePitch - currentPitch);
        if (state == State.AIMING_PEARL) {
            yawError = Math.abs(MathHelper.wrapDegrees(plan.pearlYaw - currentYaw));
            pitchError = Math.abs(plan.pearlPitch - currentPitch);
        }
        return yawError <= 0.35F && pitchError <= 0.35F;
    }

    private void throwFromSlot(int slot) {
        if (slot < 0 || slot > 8 || mc.player == null || mc.interactionManager == null) {
            abort();
            return;
        }
        mc.player.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private int findHotbarSlot(net.minecraft.item.Item item) {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(item)) {
                return slot;
            }
        }
        return -1;
    }

    private InterceptPlan findUpwardPlan(int minimumDelay) {
        float referenceYaw = mc.player.getYaw();
        Vec3d velocity = mc.player.getVelocity();
        double horizontalMotionSquared = velocity.x * velocity.x + velocity.z * velocity.z;
        float[] pearlYaws;
        if (horizontalMotionSquared < 0.003) {
            pearlYaws = new float[]{referenceYaw};
        } else {
            float movementYaw = (float) Math.toDegrees(Math.atan2(-velocity.x, velocity.z));
            pearlYaws = Math.abs(wrapAngle(movementYaw - referenceYaw)) < 20.0F
                    ? new float[]{referenceYaw} : new float[]{referenceYaw, movementYaw};
        }

        InterceptPlan best = null;
        double bestScore = Double.MAX_VALUE;
        for (float pearlPitch = -90.0F; pearlPitch <= -76.0F; pearlPitch += 0.5F) {
            for (float pearlBaseYaw : pearlYaws) {
                for (float pearlYawOffset = -20.0F; pearlYawOffset <= 20.0F; pearlYawOffset += 2.5F) {
                    float pearlYaw = pearlBaseYaw + pearlYawOffset;
                    for (float chargePitch = -90.0F; chargePitch <= -86.0F; chargePitch++) {
                        for (float chargeYawOffset = -20.0F; chargeYawOffset <= 20.0F; chargeYawOffset += 5.0F) {
                            float chargeYaw = referenceYaw + chargeYawOffset;
                            InterceptPlan candidate = evaluatePlan(pearlYaw, pearlPitch, chargeYaw, chargePitch,
                                    minimumDelay, minimumDelay, false);
                            if (candidate != null) {
                                double score = Math.sqrt(candidate.missDistanceSquared)
                                        + Math.abs(wrapAngle(chargeYaw - referenceYaw)) * 0.01
                                        + Math.abs(wrapAngle(pearlYaw - referenceYaw)) * 0.003
                                        + Math.abs(chargePitch + 90.0F) * 0.03;
                                if (score < bestScore) {
                                    best = candidate;
                                    bestScore = score;
                                }
                            }
                        }
                    }
                }
            }
        }
        return best;
    }

    private InterceptPlan findCurrentAimPlan(int minimumDelay) {
        float chargeYaw = mc.player.getYaw();
        float chargePitch = mc.player.getPitch();
        Vec chargeDirection = direction(chargeYaw, chargePitch);
        Vec3d motion = mc.player.getVelocity();
        Vec playerVelocity = new Vec(motion.x, mc.player.isOnGround() ? 0.0 : motion.y, motion.z);
        Vec3d eye = mc.player.getEyePos();
        Vec pearlStart = new Vec(eye.x, eye.y - 0.1, eye.z);
        Vec chargeStart = new Vec(eye.x, eye.y, eye.z);
        Vec chargeVelocity = new Vec(chargeDirection.x * PROJECTILE_SPEED + playerVelocity.x,
                chargeDirection.y * PROJECTILE_SPEED + playerVelocity.y,
                chargeDirection.z * PROJECTILE_SPEED + playerVelocity.z);
        InterceptPlan best = null;
        double bestScore = Double.MAX_VALUE;
        int minDelay = Math.max(3, minimumDelay);
        int maxDelay = minDelay + 12;

        for (int delay = minDelay; delay <= maxDelay; delay++) {
            Vec chargeAtDelay = chargeStart.add(playerVelocity.multiply(delay));
            int maxFlightTicks = getMaxFlightTicks(chargeAtDelay, chargeVelocity);
            for (int flightTicks = 1; flightTicks <= maxFlightTicks; flightTicks++) {
                int pearlTicks = delay + flightTicks;
                Vec chargeTarget = chargeAtDelay.add(chargeVelocity.multiply(flightTicks));
                Vec pBase = calcPearlBasePos(pearlStart, playerVelocity, pearlTicks - 1);
                Vec pBaseNext = calcPearlBasePos(pearlStart, playerVelocity, pearlTicks);
                Vec d0 = chargeTarget.subtract(pBase);
                Vec baseVelocity = pBaseNext.subtract(pBase);
                double d10 = PROJECTILE_SPEED * calcGeometricSum(pearlTicks - 1);
                double d11 = PROJECTILE_SPEED * Math.pow(PEARL_DRAG, pearlTicks);
                double a = dot(baseVelocity, baseVelocity) - d11 * d11;
                double b = -2.0 * dot(d0, baseVelocity) - 2.0 * d10 * d11;
                double c = dot(d0, d0) - d10 * d10;
                double discriminant = b * b - 4.0 * a * c;
                double[] alphas = new double[]{0.0, 0.5, 1.0, safeDivide(-c, b),
                        discriminant < 0.0 || Math.abs(a) < 1.0E-12 ? Double.NaN : (-b - Math.sqrt(discriminant)) / (2.0 * a),
                        discriminant < 0.0 || Math.abs(a) < 1.0E-12 ? Double.NaN : (-b + Math.sqrt(discriminant)) / (2.0 * a)};

                for (double alpha : alphas) {
                    if (Double.isNaN(alpha) || alpha < 0.0 || alpha > 1.0) continue;
                    double requiredDistance = d10 + alpha * d11;
                    if (requiredDistance < 1.0E-9) continue;
                    Vec requiredDirection = d0.subtract(baseVelocity.multiply(alpha)).multiply(1.0 / requiredDistance);
                    double len = Math.sqrt(dot(requiredDirection, requiredDirection));
                    if (len < 1.0E-9) continue;
                    requiredDirection = requiredDirection.multiply(1.0 / len);
                    float pearlYaw = (float) Math.toDegrees(Math.atan2(-requiredDirection.x, requiredDirection.z));
                    float pearlPitch = (float) -Math.toDegrees(Math.atan2(requiredDirection.y,
                            Math.sqrt(requiredDirection.x * requiredDirection.x + requiredDirection.z * requiredDirection.z)));
                    InterceptPlan candidate = evaluatePlan(pearlYaw, pearlPitch, chargeYaw, chargePitch, delay, delay, true);
                    if (candidate != null) {
                        double score = Math.sqrt(candidate.missDistanceSquared) + flightTicks * 0.005
                                + Math.abs(wrapAngle(pearlYaw - chargeYaw)) * 5.0E-4 + delay * 1.0E-4;
                        if (score < bestScore) {
                            best = candidate;
                            bestScore = score;
                        }
                    }
                }
            }
        }
        return best;
    }

    private InterceptPlan evaluatePlan(float pearlYaw, float pearlPitch, float chargeYaw, float chargePitch,
                                       int chargeTick, int minimumDelay, boolean absoluteChargeTiming) {
        Vec pearlDirection = direction(pearlYaw, pearlPitch);
        Vec chargeDirection = direction(chargeYaw, chargePitch);
        Vec3d velocity = mc.player.getVelocity();
        double playerMotionY = mc.player.isOnGround() ? 0.0 : velocity.y;
        Vec playerMotion = new Vec(velocity.x, playerMotionY, velocity.z);
        Vec3d eye = mc.player.getEyePos();
        double pearlX = eye.x;
        double pearlY = eye.y - 0.1;
        double pearlZ = eye.z;
        double pearlMotionX = pearlDirection.x * PROJECTILE_SPEED + playerMotion.x;
        double pearlMotionY = pearlDirection.y * PROJECTILE_SPEED + playerMotion.y;
        double pearlMotionZ = pearlDirection.z * PROJECTILE_SPEED + playerMotion.z;
        double chargeX = eye.x + playerMotion.x * chargeTick;
        double chargeY = eye.y + playerMotion.y * chargeTick;
        double chargeZ = eye.z + playerMotion.z * chargeTick;
        double chargeMotionX = chargeDirection.x * PROJECTILE_SPEED + playerMotion.x;
        double chargeMotionY = chargeDirection.y * PROJECTILE_SPEED + playerMotion.y;
        double chargeMotionZ = chargeDirection.z * PROJECTILE_SPEED + playerMotion.z;
        double closest = Double.MAX_VALUE;

        for (int tick = 1; tick <= chargeTick + MAX_FLIGHT_TICKS; tick++) {
            pearlMotionX *= PEARL_DRAG;
            pearlMotionY = (pearlMotionY - PEARL_GRAVITY) * PEARL_DRAG;
            pearlMotionZ *= PEARL_DRAG;
            pearlX += pearlMotionX;
            pearlY += pearlMotionY;
            pearlZ += pearlMotionZ;
            if (tick > chargeTick) {
                chargeX += chargeMotionX;
                chargeY += chargeMotionY;
                chargeZ += chargeMotionZ;
                double dx = pearlX - chargeX;
                double dy = pearlY - chargeY;
                double dz = pearlZ - chargeZ;
                closest = Math.min(closest, dx * dx + dy * dy + dz * dz);
            }
        }
        return chargeTick >= minimumDelay && closest <= MAX_INTERCEPT_DISTANCE_SQUARED
                ? new InterceptPlan(pearlYaw, pearlPitch, chargeYaw, chargePitch, chargeTick, closest, absoluteChargeTiming)
                : null;
    }

    private int getMaxFlightTicks(Vec chargeStart, Vec chargeVelocity) {
        Vec chargeEnd = chargeStart.add(chargeVelocity.multiply(MAX_FLIGHT_TICKS));
        BlockHitResult hit = mc.world.raycast(new RaycastContext(chargeStart.toVec3d(), chargeEnd.toVec3d(),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        if (hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) {
            double distance = chargeStart.toVec3d().distanceTo(hit.getPos());
            double speed = Math.sqrt(dot(chargeVelocity, chargeVelocity));
            if (speed < 1.0E-9) return 0;
            int ticks = (int) Math.ceil(distance / speed - 1.0E-9) - 1;
            return Math.max(0, Math.min(MAX_FLIGHT_TICKS, ticks));
        }
        return MAX_FLIGHT_TICKS;
    }

    private double calcGeometricSum(int ticks) {
        return ticks <= 0 ? 0.0 : PEARL_DRAG * (1.0 - Math.pow(PEARL_DRAG, ticks)) / (1.0 - PEARL_DRAG);
    }

    private Vec calcPearlBasePos(Vec start, Vec playerVelocity, int ticks) {
        if (ticks <= 0) return start;
        double velocityMultiplier = calcGeometricSum(ticks);
        double gravityMultiplier = (ticks - velocityMultiplier) / (1.0 - PEARL_DRAG);
        return new Vec(start.x + playerVelocity.x * velocityMultiplier,
                start.y + playerVelocity.y * velocityMultiplier - PEARL_GRAVITY * gravityMultiplier,
                start.z + playerVelocity.z * velocityMultiplier);
    }

    private Vec direction(float yaw, float pitch) {
        double yawRadians = Math.toRadians(yaw);
        double pitchRadians = Math.toRadians(pitch);
        return new Vec(-Math.sin(yawRadians) * Math.cos(pitchRadians),
                -Math.sin(pitchRadians), Math.cos(yawRadians) * Math.cos(pitchRadians));
    }

    private double dot(Vec a, Vec b) {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }

    private double safeDivide(double numerator, double denominator) {
        return Math.abs(denominator) < 1.0E-12 ? Double.NaN : numerator / denominator;
    }

    private static float wrapAngle(float angle) {
        angle %= 360.0F;
        if (angle >= 180.0F) angle -= 360.0F;
        if (angle < -180.0F) angle += 360.0F;
        return angle;
    }

    private void abort() {
        if (isEnabled()) setEnabled(false);
        else onDisable();
    }

    @Override
    protected void onDisable() {
        SilentRotationManager.clear(this);
        if (mc.player != null && savedSlot >= 0 && savedSlot < 9) {
            mc.player.getInventory().setSelectedSlot(savedSlot);
        }
        state = State.IDLE;
        plan = null;
        pearlSlot = -1;
        chargeSlot = -1;
        savedSlot = -1;
        stateTicks = 0;
        ticksSincePearl = 0;
        rotationInitialized = false;
    }

    private enum State {
        IDLE, AIMING_PEARL, THROWING_PEARL, AIMING_CHARGE, WAITING_FOR_CHARGE, FINISHED
    }

    private record InterceptPlan(float pearlYaw, float pearlPitch, float chargeYaw, float chargePitch,
                                 int chargeTick, double missDistanceSquared, boolean absoluteChargeTiming) {
    }

    private record Vec(double x, double y, double z) {
        Vec add(Vec other) {
            return new Vec(x + other.x, y + other.y, z + other.z);
        }

        Vec multiply(double value) {
            return new Vec(x * value, y * value, z * value);
        }

        Vec subtract(Vec other) {
            return new Vec(x - other.x, y - other.y, z - other.z);
        }

        Vec3d toVec3d() {
            return new Vec3d(x, y, z);
        }
    }
}
