package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.NumberSetting;
import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

final class NumberWidget extends SettingWidget {

    private final NumberSetting setting;
    private boolean dragging;

    NumberWidget(NumberSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 18;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY) || dragging);
        label(context, setting.getName(), Theme.TEXT_DIM);
        rightText(context, setting.display(), Theme.TEXT);

        int trackX = x + Theme.PADDING;
        int trackW = w - Theme.PADDING * 2;
        int trackY = y + 13;
        double fraction = (setting.getDouble() - setting.getMin()) / (setting.getMax() - setting.getMin());
        Draw.rect(context, trackX, trackY, trackW, 2, Theme.TRACK);
        Draw.rect(context, trackX, trackY, (int) Math.round(trackW * fraction), 2, Theme.accent());
    }

    private void applyMouse(double mouseX) {
        double fraction = (mouseX - (x + Theme.PADDING)) / (double) (w - Theme.PADDING * 2);
        fraction = Math.max(0, Math.min(1, fraction));
        setting.set(setting.getMin() + fraction * (setting.getMax() - setting.getMin()));
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            dragging = true;
            applyMouse(mouseX);
        } else if (button == 1) {
            setting.reset();
        }
    }

    @Override
    public void drag(double mouseX) {
        if (dragging) {
            applyMouse(mouseX);
        }
    }

    @Override
    public void release() {
        dragging = false;
    }
}
