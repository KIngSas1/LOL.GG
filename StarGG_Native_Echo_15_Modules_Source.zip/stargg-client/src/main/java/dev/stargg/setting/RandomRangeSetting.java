package dev.stargg.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.concurrent.ThreadLocalRandom;

/** A Chat-V4-style random value with independently configurable minimum and maximum endpoints. */
public final class RandomRangeSetting extends Setting<RandomRangeSetting.Range> {

    public record Range(double min, double max) {
    }

    private double allowedMin;
    private double allowedMax;
    private double step;
    private String suffix = "";

    public RandomRangeSetting(String name, double defaultMin, double defaultMax,
                              double allowedMin, double allowedMax, double step) {
        super(name, new Range(defaultMin, defaultMax));
        if (allowedMin > allowedMax) {
            throw new IllegalArgumentException("allowedMin must not exceed allowedMax");
        }
        this.allowedMin = allowedMin;
        this.allowedMax = allowedMax;
        this.step = step;
        setRange(defaultMin, defaultMax);
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix == null ? "" : suffix;
    }

    public String getSuffix() {
        return suffix;
    }

    public double getMinAllowed() {
        return allowedMin;
    }

    public double getMaxAllowed() {
        return allowedMax;
    }

    /** Updates limits supplied by an external range setting. */
    public void setAllowedBounds(double min, double max, double step) {
        if (!validBounds(min, max)) {
            return;
        }
        this.allowedMin = min;
        this.allowedMax = max;
        this.step = Math.max(0.0, step);
        setRange(getMinimum(), getMaximum());
    }

    /** Updates external bounds and current endpoints without notifying the external owner. */
    public void setAllowedBoundsSilently(double min, double max, double step, double currentMin, double currentMax) {
        if (!validBounds(min, max)) {
            return;
        }
        this.allowedMin = min;
        this.allowedMax = max;
        this.step = Math.max(0.0, step);
        setRangeSilently(currentMin, currentMax);
    }

    private static boolean validBounds(double min, double max) {
        return Double.isFinite(min) && Double.isFinite(max) && min <= max;
    }

    public double getMinimum() {
        return value.min();
    }

    public double getMaximum() {
        return value.max();
    }

    public double sample() {
        double min = getMinimum();
        double max = getMaximum();
        return max <= min ? min : ThreadLocalRandom.current().nextDouble(min, Math.nextUp(max));
    }

    public void setMinimum(double min) {
        setRange(min, Math.max(min, getMaximum()));
    }

    public void setMaximum(double max) {
        setRange(Math.min(getMinimum(), max), max);
    }

    public void setRange(double min, double max) {
        super.set(normalize(min, max));
    }

    /** Mirrors the original range setting without triggering its change listener. */
    public void setRangeSilently(double min, double max) {
        setSilently(normalize(min, max));
    }

    private Range normalize(double min, double max) {
        min = snap(clamp(min));
        max = snap(clamp(max));
        if (min > max) {
            double swap = min;
            min = max;
            max = swap;
        }
        return new Range(min, max);
    }

    private double clamp(double v) {
        return Math.max(allowedMin, Math.min(allowedMax, v));
    }

    private double snap(double v) {
        if (step <= 0.0) {
            return v;
        }
        double snapped = allowedMin + Math.round((v - allowedMin) / step) * step;
        return Math.max(allowedMin, Math.min(allowedMax, snapped));
    }

    public String display(double v) {
        String formatted;
        if (step >= 1.0) {
            formatted = Long.toString(Math.round(v));
        } else if (step > 0.0 && Double.isFinite(step)) {
            int decimals = Math.max(1, (int) Math.ceil(-Math.log10(step)));
            formatted = String.format(java.util.Locale.ROOT, "%1$." + decimals + "f", v);
        } else {
            formatted = String.format(java.util.Locale.ROOT, "%.2f", v);
        }
        return suffix.isBlank() ? formatted : formatted + suffix;
    }

    @Override
    public void set(Range range) {
        if (range == null || !Double.isFinite(range.min()) || !Double.isFinite(range.max())) {
            return;
        }
        super.set(normalize(range.min(), range.max()));
    }

    @Override
    public JsonElement save() {
        JsonObject object = new JsonObject();
        object.addProperty("min", getMinimum());
        object.addProperty("max", getMaximum());
        return object;
    }

    @Override
    public void load(JsonElement json) {
        if (json == null || json.isJsonNull()) {
            return;
        }
        if (json.isJsonObject()) {
            JsonObject object = json.getAsJsonObject();
            double min = object.has("min") ? object.get("min").getAsDouble() : getMinimum();
            double max = object.has("max") ? object.get("max").getAsDouble() : getMaximum();
            setRange(min, max);
        } else if (json.isJsonArray()) {
            JsonArray array = json.getAsJsonArray();
            if (array.size() >= 2) {
                setRange(array.get(0).getAsDouble(), array.get(1).getAsDouble());
            } else if (array.size() == 1) {
                double value = array.get(0).getAsDouble();
                setRange(value, value);
            }
        } else if (json.isJsonPrimitive()) {
            JsonPrimitive primitive = json.getAsJsonPrimitive();
            if (primitive.isNumber()) {
                double value = primitive.getAsDouble();
                setRange(value, value);
            }
        }
    }
}
