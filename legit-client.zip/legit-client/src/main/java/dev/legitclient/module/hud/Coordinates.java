package dev.legitclient.module.hud;

import dev.legitclient.setting.NumberSetting;
import dev.legitclient.util.Icon;

import java.util.List;
import java.util.Locale;

public final class Coordinates extends TextHudModule {

    private final NumberSetting decimals = add(new NumberSetting("Decimals", 1, 0, 3, 1));

    public Coordinates() {
        super("Coordinates", "Your current position", 4, 52);
        icon(Icon.COORDINATES);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        if (mc.player == null) {
            return List.of();
        }
        String format = "%." + decimals.getInt() + "f";
        return List.of(String.format(Locale.ROOT, "XYZ: " + format + " " + format + " " + format,
                mc.player.getX(), mc.player.getY(), mc.player.getZ()));
    }
}
