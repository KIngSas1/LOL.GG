# Native Echo module integration status

The 15 feature instances enabled in the supplied `Ww.json` profile are registered as **native STAR.GG `Module` entries**. They appear in STAR.GG's existing Frames and Central click GUIs, use STAR.GG's module toggles/key binds/favorites/config persistence, and show their full settings through STAR.GG's setting widgets.

The actual feature logic is **not rewritten**. Each STAR.GG entry is an adapter around the matching original Echo feature object loaded from the embedded original runtime. Enable/disable and every supported setting change are forwarded to that object; Echo's original event handlers, mixins, helpers, and supporting classes execute the behavior.

## Native category placement

| STAR.GG panel | Original Echo modules |
|---|---|
| Combat | Aim Assist, Auto Mace, Mace Swap, Spear Assist, Spear Lunge, Spear Reach, Trigger Bot |
| Movement | Jump Reset, Move Fix, No Jump Delay, Sprint |
| Utility | Pot Refill |
| Client | Capes, Echo Click GUI, Targets |

`Echo Click GUI` is named that way to distinguish it from STAR.GG's own `Click GUI` module. The 15 selected Echo features do not map to STAR.GG's Visual panel according to their original Echo categories.

## Implementation details

- `EchoNativeModuleRegistry` resolves the 15 original feature instances and adds adapter instances through `ModuleManager.registerExternal`.
- `EchoNativeModule` forwards enable/disable and bridges the Echo setting objects to STAR.GG settings.
- Supported original setting types: boolean, float, integer, min/max range, mode, boolean option list, registry-backed item list, and key code.
- Dynamic values, choices, bounds, and visibility are mirrored from the original settings without making the config dirty on every tick.
- Large item lists use the paged native multi-select widget.
- STAR.GG keybind polling owns module keybinds; the matching Echo key polling is disabled to prevent double toggles.
- `Ww.json` is bundled and loaded by Echo's own profile loader before the adapter entries are registered. STAR.GG config is then loaded so a user's later STAR.GG settings can override profile defaults.
- The previous separate-GUI launch action has been removed. STAR.GG's normal module cards own these entries.

## Verification and limitation

The integration sources and runtime metadata have been inspected, and the adapter classes have been syntax-checked against a focused API stub harness. The original embedded Echo runtime classes are preserved. A full Loom/Gradle build and in-game run have **not** been verified in this environment because the Gradle wrapper could not download its distribution from `services.gradle.org` (DNS/network resolution failure). Run `gradlew.bat build` with JDK 21 and a working network or a populated Gradle wrapper cache to perform the full build.
