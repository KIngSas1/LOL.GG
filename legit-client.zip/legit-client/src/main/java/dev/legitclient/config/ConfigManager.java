package dev.legitclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.legitclient.LegitClient;
import dev.legitclient.module.Module;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 * Saves module state to {@code .minecraft/config/legitclient/config.json} and keeps
 * named profile snapshots in {@code .../profiles/<name>.json}.
 */
public final class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final long AUTOSAVE_INTERVAL_MS = 3000;

    private static volatile boolean dirty;

    /** Click GUI panel positions: category title -> {x, y}. */
    private final Map<String, int[]> panelPositions = new HashMap<>();

    private final Path directory = FabricLoader.getInstance().getConfigDir().resolve("legitclient");
    private final Path mainFile = directory.resolve("config.json");
    private final Path profileDirectory = directory.resolve("profiles");
    private long lastSave;

    /** Anything that changes a saved value calls this; the file is written shortly after. */
    public static void markDirty() {
        dirty = true;
    }

    public void tick() {
        if (dirty && System.currentTimeMillis() - lastSave > AUTOSAVE_INTERVAL_MS) {
            save();
        }
    }

    // ------------------------------------------------------------ main config

    public void load() {
        if (!Files.exists(mainFile)) {
            return;
        }
        try {
            apply(readJson(mainFile), true);
        } catch (Exception e) {
            LegitClient.LOGGER.error("Could not read {}", mainFile, e);
        }
    }

    public void save() {
        dirty = false;
        lastSave = System.currentTimeMillis();
        try {
            writeJson(mainFile, snapshot());
        } catch (IOException e) {
            LegitClient.LOGGER.error("Could not write {}", mainFile, e);
        }
    }

    // --------------------------------------------------------------- profiles

    public List<String> listProfiles() {
        List<String> names = new ArrayList<>();
        if (Files.isDirectory(profileDirectory)) {
            try (Stream<Path> files = Files.list(profileDirectory)) {
                files.map(p -> p.getFileName().toString())
                        .filter(n -> n.endsWith(".json"))
                        .map(n -> n.substring(0, n.length() - 5))
                        .sorted()
                        .forEach(names::add);
            } catch (IOException e) {
                LegitClient.LOGGER.error("Could not list profiles", e);
            }
        }
        if (names.isEmpty()) {
            names.add("default");
        }
        return names;
    }

    public void saveProfile(String name) {
        try {
            writeJson(profileDirectory.resolve(sanitize(name) + ".json"), snapshot());
        } catch (IOException e) {
            LegitClient.LOGGER.error("Could not save profile {}", name, e);
        }
    }

    public boolean loadProfile(String name) {
        Path file = profileDirectory.resolve(sanitize(name) + ".json");
        if (!Files.exists(file)) {
            return false;
        }
        try {
            apply(readJson(file), false);
            markDirty();
            return true;
        } catch (Exception e) {
            LegitClient.LOGGER.error("Could not load profile {}", name, e);
            return false;
        }
    }

    private static String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\- ]", "_");
    }

    // -------------------------------------------------------------- GUI state

    public int[] getPanelPosition(String title) {
        return panelPositions.get(title);
    }

    public void setPanelPosition(String title, int x, int y) {
        panelPositions.put(title, new int[]{x, y});
        markDirty();
    }

    // --------------------------------------------------------------- internals

    private JsonObject snapshot() {
        JsonObject root = new JsonObject();

        JsonObject modules = new JsonObject();
        for (Module module : LegitClient.modules().all()) {
            modules.add(module.getName(), module.toJson());
        }
        root.add("modules", modules);

        JsonObject gui = new JsonObject();
        panelPositions.forEach((title, pos) -> {
            JsonObject entry = new JsonObject();
            entry.addProperty("x", pos[0]);
            entry.addProperty("y", pos[1]);
            gui.add(title, entry);
        });
        root.add("gui", gui);
        return root;
    }

    private void apply(JsonObject root, boolean includeGui) {
        if (root.has("modules") && root.get("modules").isJsonObject()) {
            JsonObject modules = root.getAsJsonObject("modules");
            for (Module module : LegitClient.modules().all()) {
                JsonElement entry = modules.get(module.getName());
                if (entry != null && entry.isJsonObject()) {
                    try {
                        module.fromJson(entry.getAsJsonObject());
                    } catch (RuntimeException e) {
                        LegitClient.LOGGER.warn("Ignoring bad config for module {}", module.getName(), e);
                    }
                }
            }
        }
        if (includeGui && root.has("gui") && root.get("gui").isJsonObject()) {
            root.getAsJsonObject("gui").entrySet().forEach(e -> {
                if (e.getValue().isJsonObject()) {
                    JsonObject pos = e.getValue().getAsJsonObject();
                    if (pos.has("x") && pos.has("y")) {
                        panelPositions.put(e.getKey(), new int[]{pos.get("x").getAsInt(), pos.get("y").getAsInt()});
                    }
                }
            });
        }
    }

    private static JsonObject readJson(Path file) throws IOException {
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            return JsonParser.parseReader(reader).getAsJsonObject();
        }
    }

    private static void writeJson(Path file, JsonObject json) throws IOException {
        Files.createDirectories(file.getParent());
        try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            GSON.toJson(json, writer);
        }
    }
}
