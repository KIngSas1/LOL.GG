package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.KeySetting;
import dev.stargg.util.KeyNames;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

/** Native key-capture control for module options such as Targets' manual target key. */
final class KeySettingWidget extends SettingWidget {

    private final KeySetting setting;
    private boolean listening;

    KeySettingWidget(KeySetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return LINE;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY) || listening);
        label(context, setting.getName(), Theme.TEXT);
        String value = listening ? "[press key]" : "[" + KeyNames.of(setting.getKey()) + "]";
        rightText(context, value, listening ? Theme.accent() : Theme.TEXT_DIM);
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (listening) {
                setting.set(-1);
                releaseFocus();
            } else {
                listening = true;
                focus(this);
            }
        } else if (button == 1) {
            setting.set(-1);
        }
    }

    @Override
    protected void onFocusLost() {
        listening = false;
    }

    @Override
    public boolean keyPressed(int key) {
        if (!listening) {
            return false;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
            setting.set(-1);
        } else {
            setting.set(key);
        }
        releaseFocus();
        return true;
    }
}
