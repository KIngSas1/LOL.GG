package dev.stargg.module.combat;

import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.CombatUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/** Swaps to a hotbar spear with Lunge for the hit you are making, then swaps back. */
public final class LungeSwap extends WeaponSwapModule {

    private final BooleanSetting requireLunge = add(new BooleanSetting("Require Lunge", true));
    private final NumberSetting minLevel = add(new NumberSetting("Min Lunge level", 1.0, 1.0, 3.0, 1.0));
    private final NumberSetting minHunger = add(new NumberSetting("Min hunger", 6.0, 0.0, 20.0, 1.0));
    private final NumberSetting minDistance = add(new NumberSetting("Min distance", 2.0, 0.0, 6.0, 0.1));

    public LungeSwap() {
        super("Lunge Swap", "Swaps to your Lunge spear for a hit, then back");
        minLevel.showWhen(requireLunge::on);
    }

    private boolean qualifies(ItemStack stack) {
        if (!CombatUtil.isSpear(stack)) {
            return false;
        }
        return !requireLunge.on() || CombatUtil.enchantLevel(stack, "lunge") >= minLevel.getInt();
    }

    @Override
    protected boolean isWanted(ItemStack held) {
        return qualifies(held);
    }

    @Override
    protected int findSlot() {
        int best = -1;
        int bestLevel = -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!qualifies(stack)) {
                continue;
            }
            int level = CombatUtil.enchantLevel(stack, "lunge");
            if (level > bestLevel) {
                bestLevel = level;
                best = slot;
            }
        }
        return best;
    }

    @Override
    protected boolean shouldSwap(LivingEntity target) {
        return mc.player.getHungerManager().getFoodLevel() >= minHunger.getInt()
                && mc.player.distanceTo(target) >= minDistance.getFloat();
    }
}
