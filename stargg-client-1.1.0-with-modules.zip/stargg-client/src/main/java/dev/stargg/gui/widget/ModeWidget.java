package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.ModeSetting;
import net.minecraft.client.gui.DrawContext;

final class ModeWidget extends SettingWidget {

    private final ModeSetting setting;

    ModeWidget(ModeSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return LINE;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT);
        rightText(context, setting.get(), Theme.accent());
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setting.cycle(1);
        } else if (button == 1) {
            setting.cycle(-1);
        }
    }
}
