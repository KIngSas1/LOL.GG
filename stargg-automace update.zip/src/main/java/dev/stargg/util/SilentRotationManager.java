package dev.stargg.util;

/**
 * Holds a temporary server-facing rotation. ClientPlayerEntityMixin applies it only while the
 * movement packet is assembled, then restores the camera angles immediately afterward.
 */
public final class SilentRotationManager {

    private static Object owner;
    private static int priority = Integer.MIN_VALUE;
    private static float yaw;
    private static float pitch;

    private SilentRotationManager() {
    }

    public static synchronized void set(Object requester, float targetYaw, float targetPitch, int requestPriority) {
        if (requester == null || owner == requester || requestPriority >= priority) {
            owner = requester;
            priority = requestPriority;
            yaw = targetYaw;
            pitch = targetPitch;
        }
    }

    public static synchronized boolean isActive() {
        return owner != null;
    }

    public static synchronized float yaw() {
        return yaw;
    }

    public static synchronized float pitch() {
        return pitch;
    }

    public static synchronized void clear(Object requester) {
        if (owner == requester) {
            owner = null;
            priority = Integer.MIN_VALUE;
        }
    }
}
