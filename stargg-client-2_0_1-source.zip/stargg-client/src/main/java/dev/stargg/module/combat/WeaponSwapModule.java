package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.CombatUtil;
import dev.stargg.util.ItemFilters;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/**
 * Base for modules that briefly swap to another hotbar weapon for the hit you are already making,
 * then swap back. Subclasses decide which item to swap to and when it is worth it.
 */
public abstract class WeaponSwapModule extends Module {

    protected final MultiSelectSetting swapFrom = add(new MultiSelectSetting("Swap from", CombatUtil.WEAPON_OPTIONS, "Any"));
    protected final MultiSelectSetting targets = add(new MultiSelectSetting("Targets", CombatUtil.TARGET_OPTIONS, "Players"));
    protected final BooleanSetting ignoreFriends = add(new BooleanSetting("Ignore friends", true));
    protected final BooleanSetting notWhileUsing = add(new BooleanSetting("Not while using item", true));
    protected final BooleanSetting swapBack = add(new BooleanSetting("Swap back", true));
    protected final NumberSetting swapBackDelay = add(new NumberSetting("Swap back delay (ticks)", 2.0, 1.0, 10.0, 1.0));

    private int originalSlot = -1;
    private int restoreTicks;

    protected WeaponSwapModule(String name, String description) {
        super(name, description, Category.COMBAT);
        swapBackDelay.showWhen(swapBack::on);
    }

    /** True if the stack in hand already is what this module wants to hit with. */
    protected abstract boolean isWanted(ItemStack held);

    /** Hotbar slot to swap to, or -1 if there is nothing suitable. */
    protected abstract int findSlot();

    /** Extra per-hit conditions (fall distance, distance, hunger ...). */
    protected boolean shouldSwap(LivingEntity target) {
        return true;
    }

    @Override
    public void onAttack(Entity target) {
        if (mc.player == null || mc.currentScreen != null || !(target instanceof LivingEntity living)) {
            return;
        }
        if (!CombatUtil.isValidTarget(living, targets, ignoreFriends.on())) {
            return;
        }
        if (originalSlot >= 0) {
            // already swapped for a previous hit: keep the weapon out a little longer
            restoreTicks = swapBackDelay.getInt();
            return;
        }
        ItemStack held = mc.player.getMainHandStack();
        if (isWanted(held) || !ItemFilters.matches(held, swapFrom)) {
            return;
        }
        if (notWhileUsing.on() && mc.player.isUsingItem()) {
            return;
        }
        if (!shouldSwap(living)) {
            return;
        }
        int slot = findSlot();
        if (slot < 0) {
            return;
        }
        int previous = mc.player.getInventory().getSelectedSlot();
        if (slot == previous) {
            return;
        }
        CombatUtil.selectSlot(slot);
        if (swapBack.on()) {
            originalSlot = previous;
            restoreTicks = swapBackDelay.getInt();
        }
    }

    @Override
    public void onTick() {
        if (originalSlot >= 0 && --restoreTicks <= 0) {
            restore();
        }
    }

    @Override
    protected void onDisable() {
        restore();
    }

    private void restore() {
        if (mc.player != null && originalSlot >= 0) {
            CombatUtil.selectSlot(originalSlot);
        }
        originalSlot = -1;
        restoreTicks = 0;
    }
}
