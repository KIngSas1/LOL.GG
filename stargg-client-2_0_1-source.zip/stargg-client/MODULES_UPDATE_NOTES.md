# Module update (stargg-indev) + AutoElytra / AutoMace fix

## Modules taken from stargg-indev
Everything that differs from the 1.4.3 base was applied on top of the HUD editor / public profile version, no conflicts:
AutoMace, AutoElytra, MaceSwap, WindChargeKey, AutoPearl, PearlCatch; updated AimAssist, ShieldBreaker, Triggerbot;
ModuleManager (new attack dispatch), the attack/pearl and ClientPlayerEntity mixins, MultiSelect / RandomRange
settings and widgets, FriendManager, TargetFilters, ItemFilters, SilentRotationManager, 14 new icons.
The indev notes are kept as `INDEV_PORTING_NOTES.md`.

## AutoElytra + AutoMace: no mace hit after the elytra came off
Causes found in the code, and what changed:
1. **Swap started too late.** AutoMace only asked for the chestplate swap at 3.4 blocks. Gliding or diving at 2 to 3
   blocks per tick the player was already past the target when the swap finished.
   `AutoElytra.getEffectivePreHitRange` now grows with the closing speed (reach + 0.4 + speed x 3 ticks, max 16
   blocks); AutoMace and AutoElytra's own combat check both use it.
2. **Armor swap reset the attack cooldown.** The old swap selected the chestplate hotbar slot and used it, then
   selected the old slot again; every held-item change resets the cooldown, so AutoMace's "cooldown ready" check
   failed for 5 to 33 ticks. New setting **Swap Method** (default `Inventory`) swaps the chest slot with the hotbar
   slot by inventory click, without touching the selected slot, and completes in the same tick. `Use Item` keeps the
   old behaviour.
3. **One tick of delay in AutoMace.** The attack was prepared in one tick and executed in the next. It is now
   executed in the same tick.
4. **Swap waited for AutoElytra's own tick.** AutoMace ticks before AutoElytra, so the swap now runs immediately
   when AutoMace asks for it.
5. **Server still sees you gliding.** The server only notices the missing elytra on its next tick, and a gliding
   mace hit loses its smash bonus. AutoMace now waits 90 ms after the swap before attacking.

## Tick button in options
The target filter checkbox used a font glyph that rendered badly. It is now a 12px rounded box with a clean border,
a fill that animates to the accent color, and a pixel-drawn check mark (`Ui.check`) that fades in.

## Not verified
Not compiled with Loom and not tested in game. `clickSlot` / `SlotActionType.SWAP` are the standard Yarn calls but
were only syntax-checked here. If the server you play on rejects inventory clicks, set Swap Method to `Use Item`.
Both swap methods only look for the chestplate / elytra in the hotbar, as before.

## Combat modules added (original implementations)
Aim Assist, Trigger Bot, Auto Mace, Mace Swap, Lunge Swap, Spear Assist (`module/combat/`).
Shared helpers: `util/CombatUtil`, `util/FallTracker`; `ItemFilters` gained a "Spear" option.
