package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.ItemFilters;
import dev.stargg.util.SilentRotationManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;
import java.util.List;

/** Tracks enemy pearl trajectories and throws a pearl toward a valid predicted landing point. */
public final class AutoPearl extends Module {

    private static final String[] ITEM_OPTIONS = {
            "Swords", "Axes", "Pickaxes", "Shovels", "Hoes", "Tools", "Mace", "Trident", "Ender Pearl", "Wind Charge", "Hand"
    };

    private final NumberSetting pearlCooldown = add(new NumberSetting("Pearl cooldown", 1.0, 0.0, 15.0, 0.1));
    private final NumberSetting distanceLimit = add(new NumberSetting("Distance limit", 6.0, 0.0, 10.0, 0.1));
    private final NumberSetting angleLimit = add(new NumberSetting("Angle limit", 180.0, 30.0, 360.0, 5.0));
    private final BooleanSetting limitToItems = add(new BooleanSetting("Limit to items", true));
    private final MultiSelectSetting allowedItems = add(new MultiSelectSetting("Allowed items", ITEM_OPTIONS, "Swords", "Ender Pearl", "Hand"));
    private final NumberSetting minHealth = add(new NumberSetting("Min health", 5.0, 1.0, 20.0, 1.0));
    private final ModeSetting mode = add(new ModeSetting("Mode", "On bind", "On bind", "Aggro"));
    private final BooleanSetting silentAim = add(new BooleanSetting("Silent aim", false));
    private final NumberSetting aimSpeed = add(new NumberSetting("Aim speed", 5.0, 0.1, 15.0, 0.5));
    private final BooleanSetting verticalCheck = add(new BooleanSetting("Vertical check", false));

    private EnderPearlEntity trackedPearl;
    private Vec3d landingPosition;
    private float assistedYaw;
    private float assistedPitch;
    private boolean rotationInitialized;
    private int waitingTicks;
    private int pearlSlot = -1;
    private int savedSlot = -1;
    private long lastThrowAt;
    private int previousPearlCount;

    public AutoPearl() {
        super("Auto Pearl", "Predicts enemy pearl landings and throws a counter-pearl", Category.UTILITY);
        icon(Icon.AUTO_PEARL);
        allowedItems.showWhen(limitToItems::on);
    }

    @Override
    protected void onEnable() {
        trackedPearl = null;
        landingPosition = null;
        waitingTicks = 0;
        rotationInitialized = false;
        savedSlot = mc.player == null ? -1 : mc.player.getInventory().getSelectedSlot();
        previousPearlCount = mc.player == null ? 0 : countPearls();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            clearAim();
            return;
        }
        int pearlCount = countPearls();
        if (pearlCount < previousPearlCount) {
            lastThrowAt = System.currentTimeMillis();
        }
        previousPearlCount = pearlCount;
        if (mc.player.getHealth() < minHealth.getDouble()) {
            clearAim();
            return;
        }
        if (limitToItems.on() && !ItemFilters.matches(mc.player.getMainHandStack(), allowedItems)) {
            clearAim();
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastThrowAt < pearlCooldown.getDouble() * 1000.0) {
            return;
        }
        pearlSlot = findPearlSlot();
        if (pearlSlot < 0) {
            clearAim();
            return;
        }

        if (trackedPearl == null || !trackedPearl.isAlive() || landingPosition == null) {
            trackedPearl = findBestPearl();
            landingPosition = trackedPearl == null ? null : predictLanding(trackedPearl);
            rotationInitialized = false;
            waitingTicks = 0;
        }
        if (trackedPearl == null || landingPosition == null) {
            clearAim();
            return;
        }
        if (!isValidLanding(landingPosition)) {
            trackedPearl = null;
            landingPosition = null;
            clearAim();
            return;
        }

        float[] rotations = rotationsTo(landingPosition);
        updateAim(rotations[0], rotations[1]);
        float yawError = Math.abs(MathHelper.wrapDegrees(rotations[0] - assistedYaw));
        float pitchError = Math.abs(rotations[1] - assistedPitch);
        waitingTicks++;
        if (yawError <= 1.5F && pitchError <= 1.5F && waitingTicks >= 2) {
            throwPearl();
            lastThrowAt = now;
            trackedPearl = null;
            landingPosition = null;
            clearAim();
            if (mode.is("On bind")) {
                setEnabled(false);
            }
        }
    }

    private EnderPearlEntity findBestPearl() {
        List<EnderPearlEntity> pearls = mc.world.getEntitiesByClass(EnderPearlEntity.class,
                mc.player.getBoundingBox().expand(64.0), pearl -> pearl.isAlive() && pearl.getOwner() instanceof PlayerEntity owner && owner != mc.player);
        return pearls.stream()
                .filter(pearl -> pearl.getOwner() instanceof PlayerEntity owner && mc.player.distanceTo(owner) <= 10.0F)
                .min(Comparator.comparingDouble(pearl -> mc.player.squaredDistanceTo(pearl)))
                .orElse(null);
    }

    private Vec3d predictLanding(EnderPearlEntity pearl) {
        Vec3d position = pearl.getEntityPos();
        Vec3d velocity = pearl.getVelocity();
        for (int tick = 0; tick < 120; tick++) {
            Vec3d next = position.add(velocity);
            BlockHitResult hit = mc.world.raycast(new RaycastContext(position, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, pearl));
            if (hit.getType() != net.minecraft.util.hit.HitResult.Type.MISS) {
                return hit.getPos();
            }
            position = next;
            velocity = velocity.multiply(0.99).add(0.0, -0.03, 0.0);
        }
        return position;
    }

    private boolean isValidLanding(Vec3d landing) {
        double distance = mc.player.getEntityPos().distanceTo(landing);
        if (distance <= distanceLimit.getDouble()) {
            return false;
        }
        if (verticalCheck.on() && landing.y - mc.player.getY() >= 7.0) {
            return false;
        }
        float targetYaw = (float) (Math.toDegrees(Math.atan2(landing.z - mc.player.getZ(), landing.x - mc.player.getX())) - 90.0);
        return Math.abs(MathHelper.wrapDegrees(targetYaw - mc.player.getYaw())) <= angleLimit.getDouble() / 2.0;
    }

    private float[] rotationsTo(Vec3d target) {
        Vec3d delta = target.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        return new float[]{yaw, MathHelper.clamp(pitch, -90.0F, 90.0F)};
    }

    private void updateAim(float targetYaw, float targetPitch) {
        if (!rotationInitialized) {
            assistedYaw = mc.player.getYaw();
            assistedPitch = mc.player.getPitch();
            rotationInitialized = true;
        }
        float yawDelta = MathHelper.wrapDegrees(targetYaw - assistedYaw);
        float pitchDelta = targetPitch - assistedPitch;
        assistedYaw += MathHelper.clamp(yawDelta, -aimSpeed.getFloat(), aimSpeed.getFloat());
        assistedPitch = MathHelper.clamp(assistedPitch + MathHelper.clamp(pitchDelta, -aimSpeed.getFloat(), aimSpeed.getFloat()), -90.0F, 90.0F);
        if (silentAim.on()) {
            SilentRotationManager.set(this, assistedYaw, assistedPitch, 7);
        } else {
            SilentRotationManager.clear(this);
            mc.player.setYaw(assistedYaw);
            mc.player.setPitch(assistedPitch);
        }
    }

    private void throwPearl() {
        int oldSlot = mc.player.getInventory().getSelectedSlot();
        mc.player.getInventory().setSelectedSlot(pearlSlot);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        mc.player.getInventory().setSelectedSlot(oldSlot);
    }

    private int countPearls() {
        int count = 0;
        for (int slot = 0; slot < 36; slot++) {
            net.minecraft.item.ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isOf(net.minecraft.item.Items.ENDER_PEARL)) count += stack.getCount();
        }
        return count;
    }

    private int findPearlSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(net.minecraft.item.Items.ENDER_PEARL)) {
                return slot;
            }
        }
        return -1;
    }

    private void clearAim() {
        SilentRotationManager.clear(this);
        rotationInitialized = false;
        waitingTicks = 0;
    }

    @Override
    protected void onDisable() {
        clearAim();
        trackedPearl = null;
        landingPosition = null;
        if (mc.player != null && savedSlot >= 0 && savedSlot < 9) {
            mc.player.getInventory().setSelectedSlot(savedSlot);
        }
        savedSlot = -1;
        previousPearlCount = 0;
    }
}
