package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.ColorSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** Label + one row of color swatches, spread so the first lines up with the label and the last with the right edge. */
final class ColorWidget extends SettingWidget {

    private static final int SWATCH = 7;

    private final ColorSetting setting;

    ColorWidget(ColorSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 30;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    private int span() {
        return w - Theme.PADDING * 2 - SWATCH;
    }

    private int swatchX(int index) {
        int count = ColorSetting.PRESETS.size();
        return x + Theme.PADDING + Math.round(span() * index / (float) (count - 1));
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT);
        rightText(context, setting.get(), Theme.TEXT_DIM);

        int sy = y + LINE + 1;
        List<ColorSetting.Preset> presets = ColorSetting.PRESETS;
        for (int i = 0; i < presets.size(); i++) {
            ColorSetting.Preset preset = presets.get(i);
            int sx = swatchX(i);
            boolean selected = preset.name().equalsIgnoreCase(setting.get());
            if (selected) {
                Ui.roundRect(context, sx - 1, sy - 1, SWATCH + 2, SWATCH + 2, 2, Theme.TEXT_BRIGHT);
            }
            Ui.roundRect(context, sx, sy, SWATCH, SWATCH, 2, preset.argb());
            if (selected) {
                // a dot in a contrasting color, so the selection is visible on every swatch (including white)
                Draw.rect(context, sx + 2, sy + 2, 3, 3, Theme.isLight(preset.argb()) ? 0xFF141414 : 0xFFFFFFFF);
            }
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button != 0 || mouseY < y + LINE) {
            return;
        }
        int count = ColorSetting.PRESETS.size();
        double position = (mouseX - (x + Theme.PADDING) - SWATCH / 2.0) / span() * (count - 1);
        int index = (int) Math.round(Math.max(0, Math.min(count - 1, position)));
        setting.set(ColorSetting.PRESETS.get(index).name());
    }
}
