package dev.legitclient.gui;

import dev.legitclient.gui.widget.SettingWidget;
import dev.legitclient.module.Module;
import dev.legitclient.setting.Setting;
import dev.legitclient.util.Draw;
import dev.legitclient.util.KeyNames;
import dev.legitclient.util.Ui;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A module row. Left click toggles; the three dots (or right click) slide the settings open.
 * Enabled modules are filled with the accent color; a bound key shows as a small badge.
 */
final class ModuleButton {

    private static final int DOTS_AREA = 22;

    private final Module module;
    private final List<SettingWidget> widgets = new ArrayList<>();
    private boolean expanded;
    private float expandAnimation;
    private float enabledAnimation;

    private int x;
    private int y;
    private int w;

    ModuleButton(Module module) {
        this.module = module;
        for (Setting<?> setting : module.getSettings()) {
            widgets.add(SettingWidget.create(setting));
        }
        widgets.add(SettingWidget.bind(module));
        widgets.add(SettingWidget.bindMode(module));
    }

    Module getModule() {
        return module;
    }

    boolean matches(String filter) {
        return filter.isEmpty() || module.getName().toLowerCase(Locale.ROOT).contains(filter);
    }

    void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    private int settingsHeight() {
        int h = 0;
        for (SettingWidget widget : widgets) {
            if (widget.isVisible()) {
                h += widget.height();
            }
        }
        return h;
    }

    /** Current (animated) height of the row including the visible part of its settings. */
    int height() {
        return Theme.MODULE_HEIGHT + Math.round(settingsHeight() * expandAnimation);
    }

    boolean rowHovered(double mouseX, double mouseY) {
        return Draw.inside(mouseX, mouseY, x, y, w, Theme.MODULE_HEIGHT);
    }

    void render(DrawContext context, int x, int y, int w, int mouseX, int mouseY) {
        this.x = x;
        this.y = y;
        this.w = w;

        boolean hovered = rowHovered(mouseX, mouseY);
        boolean toggleable = module.isToggleable();
        enabledAnimation = Theme.approach(enabledAnimation, module.isEnabled() && toggleable ? 1f : 0f);
        expandAnimation = Theme.approach(expandAnimation, expanded ? 1f : 0f);

        int accent = hovered ? Draw.blend(Theme.accent(), 0xFFFFFFFF, 0.08f) : Theme.accent();
        int background = Draw.blend(hovered ? Theme.ROW_HOVER : Theme.ROW, accent, enabledAnimation);
        Draw.rect(context, x, y, w, Theme.MODULE_HEIGHT, Theme.bg(background));

        int textColor = Draw.blend(hovered ? Theme.TEXT_BRIGHT : Theme.TEXT, Theme.TEXT_BRIGHT, enabledAnimation);

        // key badge, left of the dots
        int badgeWidth = 0;
        if (module.getKey() > 0) {
            String key = KeyNames.of(module.getKey());
            badgeWidth = Ui.width(key) + 8;
            int badgeX = x + w - DOTS_AREA + 2 - badgeWidth;
            int badgeColor = Draw.blend(Theme.BADGE, Draw.blend(accent, 0xFFFFFFFF, 0.18f), enabledAnimation);
            Draw.rounded(context, badgeX, y + 4, badgeWidth, Theme.MODULE_HEIGHT - 8, 2, badgeColor);
            Ui.textCentered(context, key, badgeX, y, badgeWidth, Theme.MODULE_HEIGHT, textColor);
            badgeWidth += 4;
        }

        String name = Ui.trim(module.getName(), w - Theme.PADDING - DOTS_AREA - badgeWidth);
        Ui.textMiddle(context, name, x + Theme.PADDING, y, Theme.MODULE_HEIGHT, textColor);

        int dotsColor = expanded ? Theme.TEXT_BRIGHT : Draw.blend(hovered ? Theme.TEXT : Theme.TEXT_DIM, Theme.TEXT_BRIGHT, enabledAnimation);
        Ui.icon(context, Ui.Tex.DOTS, x + w - 17, y + (Theme.MODULE_HEIGHT - 12) / 2, 12, dotsColor);

        if (expandAnimation > 0.001f) {
            int top = y + Theme.MODULE_HEIGHT;
            context.enableScissor(x, top, x + w, y + height());
            int cursor = top;
            for (SettingWidget widget : widgets) {
                if (widget.isVisible()) {
                    widget.render(context, x, cursor, w, mouseX, mouseY);
                    cursor += widget.height();
                }
            }
            context.disableScissor();
        }
    }

    /** @return true if the click landed on this button or one of its settings. */
    boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (rowHovered(mouseX, mouseY)) {
            // Left click on the dots (or right click anywhere) expands: touch screens have no right click.
            boolean dots = mouseX >= x + w - DOTS_AREA;
            if (button == 1 || (button == 0 && (dots || !module.isToggleable()))) {
                expanded = !expanded;
            } else if (button == 0) {
                module.toggle();
            }
            return true;
        }
        if (expanded && expandAnimation > 0.99f) {
            for (SettingWidget widget : widgets) {
                if (widget.isVisible() && widget.hit(mouseX, mouseY)) {
                    widget.click(mouseX, mouseY, button);
                    return true;
                }
            }
        }
        return false;
    }

    void mouseDragged(double mouseX) {
        if (expanded) {
            widgets.forEach(widget -> widget.drag(mouseX));
        }
    }

    void mouseReleased() {
        widgets.forEach(SettingWidget::release);
    }
}
