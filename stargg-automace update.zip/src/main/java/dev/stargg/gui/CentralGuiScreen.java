package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.config.ConfigManager;
import dev.stargg.gui.widget.SettingWidget;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.module.client.ClickGuiModule;
import dev.stargg.module.client.HudEditorModule;
import dev.stargg.module.client.ProfilesModule;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The "Central" click GUI: one dark window in the middle of the screen.
 *
 * <ul>
 *   <li>Title bar with the logo, the active profile and a close button.</li>
 *   <li>A row of buttons: <b>Home</b> (the modules), <b>Profiles</b>, <b>Search</b>, <b>HUD Editor</b> and, on the
 *       right, <b>Client settings</b> (gear) and <b>Reload profile</b>.</li>
 *   <li>Home: <b>Favorites</b> and the categories as a text list on the left, the modules of the selected one as
 *       cards on the right ({@link ModuleCard}); every card opens to all of its settings. The favorites' icons also
 *       sit under the list as quick switches.</li>
 *   <li>Profiles: active profile, unsaved-changes state, Save, auto-save and a list to load from.</li>
 * </ul>
 *
 * <p>The layout is switched with Client &gt; Click GUI &gt; GUI style (Frames / Central). Like
 * {@link ClickGuiScreen}, the Minecraft input-event types are confined to this class.
 */
public final class CentralGuiScreen extends Screen {

    private enum View {
        HOME,
        PROFILES
    }

    /** A clickable rectangle registered while rendering; clicks are tested against the last frame's list. */
    private record Btn(int x, int y, int w, int h, boolean enabled, Runnable action) {
    }

    // colors (the cards are in ModuleCard)
    private static final int WINDOW = 0xFF0F0E10;
    private static final int TITLE = 0xFF141315;
    private static final int NAV = 0xFF19181B;
    private static final int NAV_HOVER = 0xFF1F1E21;
    private static final int NAV_ACTIVE = 0xFF252428;
    private static final int SCROLL = 0xFF48474B;
    private static final int WARNING = 0xFFE0A030;
    private static final int ERROR = 0xFFE05A5A;

    private static final int MAX_W = 460;
    private static final int MAX_H = 300;
    private static final int MARGIN = 8;
    private static final int TITLE_H = 24;
    private static final int SIDE_PAD = 14;
    private static final int NAV_H = 26;
    private static final int NAV_GAP = 4;
    private static final int SIDEBAR_W = 100;
    private static final int ROW_H = 23;
    private static final int RADIUS = 5;
    private static final int SEARCH_H = 22;
    private static final int SEARCH_MAX_LENGTH = 24;
    private static final int FAVORITE_TILE = 18;
    private static final int FAVORITE_GAP = 4;

    private static final int PROFILE_ROW_H = 24;
    private static final int BUTTON_H = 20;

    private final Map<Category, List<ModuleCard>> cards = new EnumMap<>(Category.class);
    private final Map<Module, ModuleCard> cardByModule = new HashMap<>();
    private final List<Btn> clickables = new ArrayList<>();
    private final List<Btn> profileRows = new ArrayList<>();
    private final List<String> profileRowNames = new ArrayList<>();

    private View view = View.HOME;
    /** The selected sidebar entry; {@code null} is "Favorites". */
    private Category category;
    private boolean searchOpen;
    private boolean searchFocused;
    private String query = "";
    private int scroll;

    private List<String> profiles = List.of();
    private String selectedProfile;
    private boolean modified;
    private int profileScroll;
    private long lastRefresh;

    private String status = "";
    private boolean statusError;
    private long statusUntil;
    private long reloadArmedUntil;

    // layout of the last frame
    private int wx;
    private int wy;
    private int ww;
    private int wh;
    private int lx;
    private int ly;
    private int lw;
    private int lh;
    private int searchX;
    private int searchY;
    private int searchW;

    public CentralGuiScreen() {
        super(Text.literal("Click GUI"));
        for (Category c : Category.values()) {
            List<ModuleCard> list = new ArrayList<>();
            for (Module module : StarGG.modules().inCategory(c)) {
                ModuleCard card = new ModuleCard(module, () -> ClickGuiModule.isFavorite(module), () -> ClickGuiModule.toggleFavorite(module));
                list.add(card);
                cardByModule.put(module, card);
            }
            cards.put(c, list);
        }
        category = ClickGuiModule.favoriteModules().isEmpty() ? Category.values()[0] : null;
        refreshProfiles();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        refreshProfiles();
    }

    private ConfigManager config() {
        return StarGG.config();
    }

    // -------------------------------------------------------------- state

    private void refreshProfiles() {
        profiles = config().listProfiles();
        modified = config().isModified();
        lastRefresh = System.currentTimeMillis();
        if (selectedProfile == null || !profiles.contains(selectedProfile)) {
            selectedProfile = config().getActiveProfile();
        }
    }

    private void flash(String message, boolean error) {
        status = message;
        statusError = error;
        statusUntil = System.currentTimeMillis() + 3000;
    }

    private void openHome() {
        SettingWidget.releaseFocus();
        view = View.HOME;
    }

    private void openProfiles() {
        SettingWidget.releaseFocus();
        searchFocused = false;
        view = View.PROFILES;
        refreshProfiles();
    }

    private void toggleSearch() {
        SettingWidget.releaseFocus();
        view = View.HOME;
        searchOpen = !searchOpen;
        searchFocused = searchOpen;
        if (!searchOpen) {
            query = "";
        }
        scroll = 0;
    }

    private void openCategory(Category target) {
        SettingWidget.releaseFocus();
        view = View.HOME;
        category = target;
        searchOpen = false;
        searchFocused = false;
        query = "";
        scroll = 0;
    }

    /** Gear button: the Client category with the Click GUI settings (GUI style, accent, opacity) open. */
    private void openClientSettings() {
        openCategory(Category.CLIENT);
        int offset = 0;
        for (ModuleCard card : cards.get(Category.CLIENT)) {
            if (card.getModule() instanceof ClickGuiModule) {
                card.setExpanded(true);
                scroll = offset;
                return;
            }
            offset += card.height() + ModuleCard.GAP;
        }
    }

    /** Reload button: loads the active profile again. Asks for a second click while there are unsaved changes. */
    private void reloadProfile() {
        String active = config().getActiveProfile();
        long now = System.currentTimeMillis();
        refreshProfiles();
        if (modified && now > reloadArmedUntil) {
            reloadArmedUntil = now + 3000;
            flash("Unsaved changes will be lost - click reload again to reload " + active, false);
            return;
        }
        reloadArmedUntil = 0;
        if (config().loadProfile(active)) {
            flash("Reloaded " + active, false);
        } else {
            flash("Could not reload " + active, true);
        }
        refreshProfiles();
    }

    private String filter() {
        return query.toLowerCase(Locale.ROOT).trim();
    }

    /** The cards currently listed: every match while searching, else the favorites or the selected category. */
    private List<ModuleCard> visibleCards() {
        String filter = filter();
        List<ModuleCard> result = new ArrayList<>();
        if (!filter.isEmpty()) {
            for (Category c : Category.values()) {
                for (ModuleCard card : cards.get(c)) {
                    if (card.matches(filter)) {
                        result.add(card);
                    }
                }
            }
        } else if (category == null) {
            for (Module module : ClickGuiModule.favoriteModules()) {
                ModuleCard card = cardByModule.get(module);
                if (card != null) {
                    result.add(card);
                }
            }
        } else {
            result.addAll(cards.get(category));
        }
        return result;
    }

    // ------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        clickables.clear();
        profileRows.clear();
        profileRowNames.clear();

        ww = Math.min(MAX_W, width - MARGIN * 2);
        wh = Math.min(MAX_H, height - MARGIN * 2);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2;

        context.fill(0, 0, width, height, 0x70000000);
        Ui.roundRect(context, wx, wy, ww, wh, RADIUS, Theme.bg(WINDOW));

        renderTitleBar(context, mouseX, mouseY);
        renderNav(context, mouseX, mouseY);

        int bodyY = wy + TITLE_H + 10 + NAV_H + 12;
        if (view == View.HOME) {
            renderSidebar(context, mouseX, mouseY, bodyY);
            renderModules(context, mouseX, mouseY, bodyY);
        } else {
            renderProfiles(context, mouseX, mouseY, bodyY);
        }
        renderToast(context);
    }

    // ---- title bar and navigation

    private void renderTitleBar(DrawContext context, int mouseX, int mouseY) {
        // top corners are rounded like the window, the bottom edge is straight
        context.enableScissor(wx, wy, wx + ww, wy + TITLE_H);
        Ui.roundRect(context, wx, wy, ww, TITLE_H + RADIUS, RADIUS, Theme.bg(TITLE));
        context.disableScissor();

        Ui.icon(context, Ui.Tex.LOGO, wx + SIDE_PAD, wy + (TITLE_H - Ui.Tex.LOGO.size) / 2, Theme.TEXT_BRIGHT);
        int titleX = wx + SIDE_PAD + 17;
        int titleY = Ui.middleY(wy, TITLE_H);
        Ui.textBold(context, "STAR", titleX, titleY, Theme.TEXT_BRIGHT);
        Ui.textBold(context, ".GG", titleX + Ui.widthBold("STAR"), titleY, Theme.accent());

        int closeW = TITLE_H;
        int closeX = wx + ww - closeW - 6;
        boolean closeHover = Draw.inside(mouseX, mouseY, closeX, wy, closeW, TITLE_H);
        Ui.icon(context, Ui.Tex.CLOSE, closeX + (closeW - 12) / 2, wy + (TITLE_H - 12) / 2, closeHover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        clickables.add(new Btn(closeX, wy, closeW, TITLE_H, true, this::close));

        String profile = Ui.trim(ClickGuiModule.profileName(), 90);
        int chipW = Ui.width(profile) + 12;
        int chipX = closeX - 8 - chipW;
        Ui.roundRect(context, chipX, wy + (TITLE_H - 14) / 2, chipW, 14, 4, NAV);
        Ui.textCentered(context, profile, chipX, wy + (TITLE_H - 14) / 2, chipW, 14, Theme.TEXT_DIM);
    }

    private void renderNav(DrawContext context, int mouseX, int mouseY) {
        int navY = wy + TITLE_H + 10;
        int x = wx + SIDE_PAD;

        // Home: icon + label
        String home = "Home";
        int homeW = 12 + Ui.width(home) + 8 + 14 + 12;
        boolean homeActive = view == View.HOME && !searchOpen;
        boolean homeHover = Draw.inside(mouseX, mouseY, x, navY, homeW, NAV_H);
        Ui.roundRect(context, x, navY, homeW, NAV_H, RADIUS, homeActive ? NAV_ACTIVE : (homeHover ? NAV_HOVER : NAV));
        int homeColor = homeActive ? Theme.TEXT_BRIGHT : (homeHover ? Theme.TEXT : Theme.TEXT_DIM);
        Ui.icon(context, Ui.Tex.HOME, x + 12, navY + (NAV_H - 12) / 2, homeColor);
        Ui.textBold(context, home, x + 12 + 12 + 8, Ui.middleY(navY, NAV_H), homeColor);
        clickables.add(new Btn(x, navY, homeW, NAV_H, true, () -> {
            searchOpen = false;
            searchFocused = false;
            query = "";
            openHome();
        }));
        x += homeW + NAV_GAP;

        iconButton(context, mouseX, mouseY, Ui.Tex.ADD_WINDOW, x, navY, view == View.PROFILES, this::openProfiles);
        x += NAV_H + NAV_GAP;
        iconButton(context, mouseX, mouseY, Ui.Tex.SEARCH, x, navY, searchOpen && view == View.HOME, this::toggleSearch);
        x += NAV_H + NAV_GAP;
        iconButton(context, mouseX, mouseY, Ui.Tex.CODE, x, navY, false, HudEditorModule::open);

        // right side: reload profile, client settings
        int right = wx + ww - SIDE_PAD - NAV_H;
        iconButton(context, mouseX, mouseY, Ui.Tex.REFRESH, right, navY, false, this::reloadProfile);
        right -= NAV_H + NAV_GAP;
        iconButton(context, mouseX, mouseY, Ui.Tex.GEAR, right, navY,
                view == View.HOME && category == Category.CLIENT && !searchOpen, this::openClientSettings);
    }

    private void iconButton(DrawContext context, int mouseX, int mouseY, Ui.Tex icon, int x, int y, boolean active, Runnable action) {
        boolean hovered = Draw.inside(mouseX, mouseY, x, y, NAV_H, NAV_H);
        Ui.roundRect(context, x, y, NAV_H, NAV_H, RADIUS, active ? NAV_ACTIVE : (hovered ? NAV_HOVER : NAV));
        Ui.icon(context, icon, x + (NAV_H - icon.size) / 2, y + (NAV_H - icon.size) / 2,
                active ? Theme.TEXT_BRIGHT : (hovered ? Theme.TEXT : Theme.TEXT_DIM));
        clickables.add(new Btn(x, y, NAV_H, NAV_H, true, action));
    }

    // ---- Home: sidebar

    private void renderSidebar(DrawContext context, int mouseX, int mouseY, int bodyY) {
        int sx = wx + SIDE_PAD;
        int rowY = bodyY;
        boolean searching = searchOpen && !filter().isEmpty();

        // "Favorites" is the first entry, then the categories
        List<Category> entries = new ArrayList<>();
        entries.add(null);
        for (Category c : Category.values()) {
            entries.add(c);
        }
        for (Category entry : entries) {
            String title = entry == null ? "Favorites" : entry.title();
            boolean selected = !searching && entry == category;
            boolean hovered = Draw.inside(mouseX, mouseY, sx, rowY, SIDEBAR_W, ROW_H);
            int color = selected ? Theme.TEXT_BRIGHT : (hovered ? Theme.TEXT : Theme.TEXT_DIM);
            int textY = Ui.middleY(rowY, ROW_H) - (selected ? 2 : 0);
            if (selected) {
                Ui.textBold(context, title, sx, textY, color);
                Ui.roundRect(context, sx, textY + Ui.CAP_HEIGHT + 4, 14, 2, 1, Theme.accent());
            } else {
                Ui.text(context, title, sx, textY, color);
            }
            clickables.add(new Btn(sx, rowY, SIDEBAR_W, ROW_H, true, () -> openCategory(entry)));
            rowY += ROW_H;
        }

        // favorites as small icon tiles: click to switch the module
        List<Module> favorites = ClickGuiModule.favoriteModules();
        int columns = Math.max(1, (SIDEBAR_W + FAVORITE_GAP) / (FAVORITE_TILE + FAVORITE_GAP));
        int tileY = rowY + 10;
        int limit = wy + wh - 12;
        for (int i = 0; i < favorites.size(); i++) {
            int col = i % columns;
            int row = i / columns;
            int tx = sx + col * (FAVORITE_TILE + FAVORITE_GAP);
            int ty = tileY + row * (FAVORITE_TILE + FAVORITE_GAP);
            if (ty + FAVORITE_TILE > limit) {
                break;
            }
            Module module = favorites.get(i);
            boolean on = module.isEnabled() && module.isToggleable();
            boolean hovered = Draw.inside(mouseX, mouseY, tx, ty, FAVORITE_TILE, FAVORITE_TILE);
            Ui.roundRect(context, tx, ty, FAVORITE_TILE, FAVORITE_TILE, 4, on ? NAV_ACTIVE : (hovered ? NAV_HOVER : NAV));
            module.getIcon().draw(context, tx + 3, ty + 3, FAVORITE_TILE - 6, on || hovered);
            clickables.add(new Btn(tx, ty, FAVORITE_TILE, FAVORITE_TILE, module.isToggleable(), module::toggle));
        }
    }

    // ---- Home: module cards

    private void renderModules(DrawContext context, int mouseX, int mouseY, int bodyY) {
        lx = wx + SIDE_PAD + SIDEBAR_W + 10;
        lw = wx + ww - SIDE_PAD - 8 - lx;
        ly = bodyY;

        if (searchOpen) {
            searchX = lx;
            searchY = bodyY;
            searchW = lw;
            Ui.roundRect(context, searchX, searchY, searchW, SEARCH_H, RADIUS, NAV);
            Ui.icon(context, Ui.Tex.SEARCH, searchX + 8, searchY + (SEARCH_H - Ui.Tex.SEARCH.size) / 2,
                    searchFocused ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
            int textX = searchX + 24;
            if (query.isEmpty() && !searchFocused) {
                Ui.textMiddle(context, "Search all modules...", textX, searchY, SEARCH_H, Theme.TEXT_FAINT);
            } else {
                String shown = Ui.trim(query, searchW - 36);
                Ui.textMiddle(context, shown, textX, searchY, SEARCH_H, Theme.TEXT_BRIGHT);
                if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                    Draw.rect(context, textX + Ui.width(shown) + 1, searchY + 5, 1, SEARCH_H - 10, Theme.TEXT_BRIGHT);
                }
            }
            ly = bodyY + SEARCH_H + 6;
        }
        lh = wy + wh - 12 - ly;

        List<ModuleCard> list = visibleCards();
        int contentHeight = 0;
        for (ModuleCard card : list) {
            contentHeight += card.height() + ModuleCard.GAP;
        }
        int maxScroll = Math.max(0, contentHeight - ModuleCard.GAP - lh);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        context.enableScissor(lx, ly, lx + lw, ly + lh);
        int cursor = ly - scroll;
        for (ModuleCard card : list) {
            card.render(context, lx, cursor, lw, mouseX, mouseY);
            cursor += card.height() + ModuleCard.GAP;
        }
        if (list.isEmpty()) {
            String first;
            String second = null;
            if (!filter().isEmpty()) {
                first = "No modules match \"" + query + "\"";
            } else {
                first = "No favorites yet";
                second = "Open a module's menu (the three dots) and switch on Favorite.";
            }
            Ui.textCentered(context, Ui.trim(first, lw), lx, ly + 8, lw, 14, Theme.TEXT_DIM);
            if (second != null) {
                Ui.textCentered(context, Ui.trim(second, lw), lx, ly + 24, lw, 14, Theme.TEXT_FAINT);
            }
        }
        context.disableScissor();

        if (maxScroll > 0) {
            int thumbH = Math.max(18, lh * lh / (contentHeight - ModuleCard.GAP));
            int thumbY = ly + (int) ((long) (lh - thumbH) * scroll / maxScroll);
            Ui.roundRect(context, lx + lw + 4, thumbY, 3, thumbH, 1, SCROLL);
        }

        renderTooltip(context, mouseX, mouseY, list);
    }

    private void renderTooltip(DrawContext context, int mouseX, int mouseY, List<ModuleCard> list) {
        if (!Draw.inside(mouseX, mouseY, lx, ly, lw, lh)) {
            return;
        }
        for (ModuleCard card : list) {
            if (card.rowHovered(mouseX, mouseY)) {
                String text = card.getModule().getDescription();
                int w = Ui.width(text) + 12;
                int x = Math.min(mouseX + 10, width - w - 2);
                int y = Math.min(mouseY + 10, height - 20);
                Ui.roundRect(context, x, y, w, 16, 3, 0xF0151515);
                Ui.textMiddle(context, text, x + 6, y, 16, Theme.TEXT);
                return;
            }
        }
    }

    // ---- Profiles

    private void renderProfiles(DrawContext context, int mouseX, int mouseY, int bodyY) {
        if (System.currentTimeMillis() - lastRefresh > 1000) {
            refreshProfiles();
        }
        String active = config().getActiveProfile();
        boolean builtIn = ConfigManager.DEFAULT_PROFILE.equalsIgnoreCase(active);

        int px = wx + SIDE_PAD;
        int pw = ww - SIDE_PAD * 2;
        int y = bodyY;

        // active profile card
        int cardH = 38;
        Ui.roundRect(context, px, y, pw, cardH, RADIUS, Theme.bg(ModuleCard.CARD));
        Ui.textMiddle(context, "Active profile", px + 10, y + 3, 12, Theme.TEXT_FAINT);
        Ui.textBold(context, Ui.trim(active, pw / 2), px + 10, Ui.middleY(y + 16, 16), Theme.TEXT_BRIGHT);
        int saveW = 56;
        int saveX = px + pw - 10 - saveW;
        int btnY = y + (cardH - BUTTON_H) / 2;
        actionButton(context, mouseX, mouseY, "Save", saveX, btnY, saveW, BUTTON_H, !builtIn && modified, () -> saveActive(active));
        String badge = modified ? "Unsaved changes" : "Saved";
        int badgeW = Ui.width(badge) + 10;
        int badgeX = saveX - 8 - badgeW;
        Ui.roundRect(context, badgeX, btnY + 3, badgeW, BUTTON_H - 6, 3, NAV_ACTIVE);
        Ui.textCentered(context, badge, badgeX, btnY + 3, badgeW, BUTTON_H - 6, modified ? WARNING : Theme.TEXT_DIM);
        y += cardH + 4;

        // auto-save row
        boolean auto = config().isAutoSaveProfile() && !builtIn;
        int autoH = 24;
        boolean autoHover = !builtIn && Draw.inside(mouseX, mouseY, px, y, pw, autoH);
        Ui.roundRect(context, px, y, pw, autoH, RADIUS, Theme.bg(autoHover ? ModuleCard.CARD_HOVER : ModuleCard.CARD));
        Ui.textMiddle(context, builtIn ? "Auto-save (not for the default profile)" : "Auto-save changes to this profile",
                px + 10, y, autoH, builtIn ? Theme.TEXT_FAINT : Theme.TEXT);
        int pillW = 20;
        int pillH = 10;
        int pillX = px + pw - 10 - pillW;
        int pillY = y + (autoH - pillH) / 2;
        Ui.roundRect(context, pillX, pillY, pillW, pillH, pillH / 2, auto ? Theme.accent() : Theme.TRACK);
        Ui.roundRect(context, auto ? pillX + pillW - 9 : pillX + 1, pillY + 1, 8, 8, 4, 0xFFFFFFFF);
        clickables.add(new Btn(px, y, pw, autoH, !builtIn, () -> {
            config().setAutoSaveProfile(!config().isAutoSaveProfile());
            refreshProfiles();
        }));
        y += autoH + 10;

        // bottom buttons
        int buttonsY = wy + wh - 12 - BUTTON_H;
        int halfW = (pw - 6) / 2;
        actionButton(context, mouseX, mouseY, "Load selected", px, buttonsY, halfW, BUTTON_H, selectedProfile != null, this::loadSelected);
        actionButton(context, mouseX, mouseY, "Profile manager", px + halfW + 6, buttonsY, pw - halfW - 6, BUTTON_H, true, ProfilesModule::open);

        // profile list
        Ui.text(context, "PROFILES  (double-click to load)", px, Ui.middleY(y, 14), Theme.TEXT_FAINT);
        y += 18;
        int listBottom = buttonsY - 8;
        int visibleRows = Math.max(1, (listBottom - y) / PROFILE_ROW_H);
        profileScroll = Math.max(0, Math.min(profileScroll, Math.max(0, profiles.size() - visibleRows)));
        for (int i = 0; i < visibleRows && profileScroll + i < profiles.size(); i++) {
            String name = profiles.get(profileScroll + i);
            int rowY = y + i * PROFILE_ROW_H;
            int rowH = PROFILE_ROW_H - 3;
            boolean isSelected = name.equals(selectedProfile);
            boolean hovered = Draw.inside(mouseX, mouseY, px, rowY, pw, rowH);
            int bg = isSelected ? Draw.blend(ModuleCard.CARD, Theme.accent(), 0.25f) : (hovered ? ModuleCard.CARD_HOVER : ModuleCard.CARD);
            Ui.roundRect(context, px, rowY, pw, rowH, RADIUS, Theme.bg(bg));
            Ui.textMiddle(context, Ui.trim(name, pw - 90), px + 10, rowY, rowH, isSelected ? Theme.TEXT_BRIGHT : Theme.TEXT);
            if (name.equals(active)) {
                int w = Ui.width("Active") + 10;
                Ui.roundRect(context, px + pw - 10 - w, rowY + 4, w, rowH - 8, 3, Theme.accent());
                Ui.textCentered(context, "Active", px + pw - 10 - w, rowY + 4, w, rowH - 8, Theme.onAccent());
            }
            profileRows.add(new Btn(px, rowY, pw, rowH, true, null));
            profileRowNames.add(name);
        }
    }

    private void actionButton(DrawContext context, int mouseX, int mouseY, String label, int x, int y, int w, int h, boolean enabled, Runnable action) {
        boolean hovered = enabled && Draw.inside(mouseX, mouseY, x, y, w, h);
        Ui.roundRect(context, x, y, w, h, RADIUS, hovered ? NAV_ACTIVE : NAV);
        Ui.textCentered(context, label, x, y, w, h, !enabled ? Theme.TEXT_FAINT : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT));
        clickables.add(new Btn(x, y, w, h, enabled, action));
    }

    private void renderToast(DrawContext context) {
        if (System.currentTimeMillis() >= statusUntil || status.isEmpty()) {
            return;
        }
        String shown = Ui.trim(status, ww - SIDE_PAD * 2 - 20);
        int w = Ui.width(shown) + 20;
        int x = wx + (ww - w) / 2;
        // above the bottom buttons on the Profiles page, near the bottom edge of the list on Home
        int y = wy + wh - 12 - 18 - (view == View.PROFILES ? BUTTON_H + 4 : 0);
        Ui.roundRect(context, x, y, w, 18, RADIUS, 0xF0252428);
        Ui.textCentered(context, shown, x, y, w, 18, statusError ? ERROR : Theme.TEXT);
    }

    private void loadSelected() {
        if (selectedProfile == null) {
            return;
        }
        if (config().loadProfile(selectedProfile)) {
            flash("Loaded " + selectedProfile, false);
        } else {
            flash("Could not load " + selectedProfile, true);
        }
        refreshProfiles();
    }

    private void saveActive(String active) {
        if (config().saveProfile(active)) {
            flash("Saved " + active, false);
        } else {
            flash("Could not save " + active, true);
        }
        refreshProfiles();
    }

    // ------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        SettingWidget.releaseFocus();

        if (!Draw.inside(mouseX, mouseY, wx, wy, ww, wh)) {
            searchFocused = false;
            return true; // clicks outside the window do nothing (Escape closes)
        }

        if (button == 0) {
            for (int i = clickables.size() - 1; i >= 0; i--) {
                Btn btn = clickables.get(i);
                if (btn.enabled() && Draw.inside(mouseX, mouseY, btn.x(), btn.y(), btn.w(), btn.h())) {
                    searchFocused = false; // the search button focuses it again itself
                    btn.action().run();
                    return true;
                }
            }
        }

        if (view == View.HOME) {
            if (searchOpen && button == 0 && Draw.inside(mouseX, mouseY, searchX, searchY, searchW, SEARCH_H)) {
                searchFocused = true;
                return true;
            }
            searchFocused = false;
            if (Draw.inside(mouseX, mouseY, lx, ly, lw, lh)) {
                for (ModuleCard card : visibleCards()) {
                    if (card.mouseClicked(mouseX, mouseY, button)) {
                        return true;
                    }
                }
            }
        } else if (button == 0) {
            for (int i = 0; i < profileRows.size(); i++) {
                Btn row = profileRows.get(i);
                if (Draw.inside(mouseX, mouseY, row.x(), row.y(), row.w(), row.h())) {
                    selectedProfile = profileRowNames.get(i);
                    if (doubled) {
                        loadSelected();
                    }
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (view == View.HOME) {
            for (ModuleCard card : visibleCards()) {
                card.mouseDragged(click.x());
            }
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        for (List<ModuleCard> list : cards.values()) {
            list.forEach(ModuleCard::mouseReleased);
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (view == View.HOME) {
            scroll = Math.max(0, scroll - (int) (verticalAmount * 20)); // clamped on the next frame
        } else {
            profileScroll = Math.max(0, profileScroll - (int) Math.signum(verticalAmount));
        }
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (!searchFocused || view != View.HOME) {
            return super.charTyped(input);
        }
        int codePoint = input.codepoint();
        if (!Character.isISOControl(codePoint) && query.length() < SEARCH_MAX_LENGTH) {
            query += new String(Character.toChars(codePoint));
            scroll = 0;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        SettingWidget focused = SettingWidget.getFocused();
        if (focused != null && focused.keyPressed(key)) {
            return true;
        }

        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) {
                    query = query.substring(0, query.length() - 1);
                    scroll = 0;
                }
            } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                query = "";
                scroll = 0;
                searchOpen = false;
                searchFocused = false;
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
            }
            return true; // typing must not trigger the GUI's close key
        }

        ClickGuiModule module = StarGG.modules().get(ClickGuiModule.class);
        if (key == GLFW.GLFW_KEY_ESCAPE || (module.getKey() > 0 && key == module.getKey())) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void tick() {
        // "GUI style" was switched back to Frames (Client > Click GUI > GUI style): hand over to the frames GUI.
        if (!ClickGuiModule.centralSelected()) {
            StarGG.modules().get(ClickGuiModule.class).swapScreen();
        }
    }

    @Override
    public void removed() {
        SettingWidget.releaseFocus();
        searchFocused = false;
        ClickGuiModule module = StarGG.modules().get(ClickGuiModule.class);
        if (!module.isSwapping()) {
            module.setEnabled(false);
            StarGG.config().save();
        }
    }
}
