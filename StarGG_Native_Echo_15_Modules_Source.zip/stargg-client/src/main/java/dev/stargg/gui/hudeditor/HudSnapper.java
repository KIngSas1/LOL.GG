package dev.stargg.gui.hudeditor;

import java.util.ArrayList;
import java.util.List;

/**
 * Snapping used while dragging a HUD element in the editor.
 *
 * <p>Behaviour (ported from the chat v4 HUD editor):
 * <ul>
 *   <li>the left / center / right edges (and top / middle / bottom edges) of the dragged element are compared
 *       with the same edges of every other visible element, whose box is grown by {@link #EXPAND} so two snapped
 *       elements keep a small gap, and with the screen center lines (and screen edges);</li>
 *   <li>an edge within {@link #TOLERANCE} units of a target is pulled onto it;</li>
 *   <li>a snap is sticky: it holds until the cursor has moved more than {@link #RELEASE} units from where the
 *       snap started, then the element follows the cursor again;</li>
 *   <li>each active snap produces a guide line between the two aligned elements (full screen for the center
 *       lines).</li>
 * </ul>
 */
public final class HudSnapper {

    public static final int TOLERANCE = 2;
    public static final int RELEASE = 5;
    public static final int EXPAND = 2;

    /** A box on screen. */
    public record Box(int x, int y, int w, int h) {
    }

    /** A guide line to draw, both corners inclusive. */
    public record Guide(int x1, int y1, int x2, int y2) {
    }

    /** One position an edge can snap to, remembering the box it came from (null for the screen). */
    private record Target(int pos, Box source) {
    }

    private static final class Axis {
        boolean stuck;
        int stuckRaw;
        int delta;
        Target target;
        int edgeOffset;

        void reset() {
            stuck = false;
            target = null;
        }
    }

    private final Axis ax = new Axis();
    private final Axis ay = new Axis();
    private final List<Guide> guides = new ArrayList<>();

    public void reset() {
        ax.reset();
        ay.reset();
        guides.clear();
    }

    /** Guide lines of the last {@link #snap} call. */
    public List<Guide> guides() {
        return guides;
    }

    /**
     * @param rawX   where the element would be without snapping
     * @param others every other visible element
     * @return {x, y} of the element after snapping
     */
    public int[] snap(int rawX, int rawY, int w, int h, List<Box> others, int screenW, int screenH) {
        guides.clear();

        List<Target> xs = new ArrayList<>();
        List<Target> ys = new ArrayList<>();
        xs.add(new Target(0, null));
        xs.add(new Target(screenW / 2, null));
        xs.add(new Target(screenW, null));
        ys.add(new Target(0, null));
        ys.add(new Target(screenH / 2, null));
        ys.add(new Target(screenH, null));
        for (Box o : others) {
            int l = o.x() - EXPAND;
            int r = o.x() + o.w() + EXPAND;
            int t = o.y() - EXPAND;
            int b = o.y() + o.h() + EXPAND;
            xs.add(new Target(l, o));
            xs.add(new Target((l + r) / 2, o));
            xs.add(new Target(r, o));
            ys.add(new Target(t, o));
            ys.add(new Target((t + b) / 2, o));
            ys.add(new Target(b, o));
        }

        int x = resolve(ax, rawX, new int[]{0, w / 2, w}, xs);
        int y = resolve(ay, rawY, new int[]{0, h / 2, h}, ys);

        if (ax.stuck && ax.target != null) {
            guides.add(guide(true, x + ax.edgeOffset, x, y, w, h, ax.target.source(), screenH));
        }
        if (ay.stuck && ay.target != null) {
            guides.add(guide(false, y + ay.edgeOffset, x, y, w, h, ay.target.source(), screenW));
        }
        return new int[]{x, y};
    }

    private static int resolve(Axis axis, int raw, int[] edges, List<Target> targets) {
        if (axis.stuck) {
            if (Math.abs(raw - axis.stuckRaw) <= RELEASE) {
                return axis.stuckRaw + axis.delta;
            }
            axis.reset();
        }
        int bestDelta = 0;
        Target best = null;
        int bestEdge = 0;
        for (int edge : edges) {
            for (Target target : targets) {
                int delta = target.pos() - (raw + edge);
                if (Math.abs(delta) <= TOLERANCE && (best == null || Math.abs(delta) < Math.abs(bestDelta))) {
                    bestDelta = delta;
                    best = target;
                    bestEdge = edge;
                }
            }
        }
        if (best == null) {
            return raw;
        }
        axis.stuck = true;
        axis.stuckRaw = raw;
        axis.delta = bestDelta;
        axis.target = best;
        axis.edgeOffset = bestEdge;
        return raw + bestDelta;
    }

    /** Guide line along an aligned edge, spanning the dragged element and the element it aligned with. */
    private static Guide guide(boolean vertical, int line, int x, int y, int w, int h, Box source, int screenSpan) {
        if (source == null) {
            return vertical ? new Guide(line, 0, line, screenSpan) : new Guide(0, line, screenSpan, line);
        }
        if (vertical) {
            return new Guide(line, Math.min(y, source.y()), line, Math.max(y + h, source.y() + source.h()));
        }
        return new Guide(Math.min(x, source.x()), line, Math.max(x + w, source.x() + source.w()), line);
    }
}
