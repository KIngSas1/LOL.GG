# HUD editor + public profiles (ported from chat v4)

Both systems were re-implemented on StarGG's own `DrawContext` / `Ui` / `Theme` stack. chat v4's versions sit on its own
GUI framework and, for profiles, on its own network protocol, so the files could not be dropped in as they are.

## HUD editor  (`gui/HudEditorScreen.java`, `gui/hudeditor/*`)
Replaces the old editor; `HudEditorModule` and every caller are unchanged.
- Selected element: dashed frame, name label, close button (turns the element off) and settings button beside it.
  The buttons move to the left side when the element sits at the right screen edge.
- Settings button / right-click: anchored settings popup next to the button (flips side when it does not fit),
  built from the click GUI's own setting widgets, scrollable, with a "Reset position" row.
- Dragging snaps to other elements' edges/centers and to the screen center lines/edges (2 unit tolerance, other
  elements grown by 2), sticky until the cursor moves 5 units, green guide lines. Hold Shift for free movement.
- Element window: Favorite / All / HUD / Game tabs, search, on/off switch per element, right-click = favorite,
  Reset all, Done. Window position and favorites are saved in `config/stargg/hud_editor.json`.
- Kept from the old editor: arrow-key nudging (Shift = 10) and R to reset the selected element.
- Dropped: the bottom toolbar and the grid (chat v4 has neither).

## Public profiles  (`publicprofile/*`, `gui/PublicProfilesScreen.java`)
Opened with the new "Public profiles" button on the Profiles screen.
- Browse with search, Top Rated / Most Downloaded / Newest sorting and tag filters.
- Details: description, tags, downloads, like/dislike counts, share code (copy), "Add to profiles" / "Add and load",
  reviews with like/dislike, owner replies, delete.
- Owner actions: update data from current settings (bumps version), list/unlist, delete.
- Publish: pick current settings or a saved profile, name, description, tags, listed publicly, hide my name.
- Import by share code from the browse screen.

### Backend
The UI only talks to `PublicProfileService`. The bundled `LocalPublicProfileService` stores one JSON file per profile in
`config/stargg/public_profiles/`, so it works offline; put that folder on a shared drive or copy files to exchange
profiles. For a real online list, implement `PublicProfileService` against your own server and install it with
`PublicProfiles.setService(...)` at startup. chat v4's own profile traffic goes through its private protocol to its own
servers and was deliberately not carried over.

## Not verified
The code was type-checked against stubs of the Minecraft/Fabric API, not compiled with Loom and not run in game.
Build with `gradlew build` first and check the new screens in game.
