# LegitClient (Fabric 1.21.11)

A small client-side Fabric mod: **click GUI + legit modules + settings**.
No accounts, no tokens, no injection, no cheats — it is a normal Fabric mod.

## Build the jar

Requirements: **JDK 21**.

```
./gradlew build          # Windows: gradlew.bat build
```

The jar is `build/libs/legitclient-1.0.0.jar`. Put it in `.minecraft/mods` together with
**Fabric Loader** and **Fabric API** for 1.21.11.
To test from your IDE: `./gradlew runClient`.

Pushing the project to GitHub also builds the jar automatically (`.github/workflows/build.yml`).

> If Gradle can't resolve a version, open <https://fabricmc.net/develop>, pick 1.21.11 and copy the
> `yarn_mappings`, `loader_version`, `loom_version` and `fabric_version` lines into `gradle.properties`.

## Use it

* **Right Shift** opens the click GUI. The main panel (left) opens/closes one panel per category; the gear and *Profiles* jump to the theme/profile settings; the top search bar filters modules by name. Rebind it in the GUI: *Client > Click GUI > Bind*.
* Tap a module = toggle. Tap the **+/-** on its row (or right click) = open its settings.
* In the settings: **Bind** (click, then press a key; click again or Backspace clears) and **Bind mode** (Toggle / Hold).
* Tap the arrow on a panel header (or right click it) to collapse it, drag the header to move the panel.
* Drag empty space (or use the mouse wheel) to scroll when panels are taller than the screen. **X** (top right) closes the GUI.
* While the GUI is open, drag any enabled **HUD element** to reposition it.
* Config is saved to `.minecraft/config/legitclient/config.json`.
  The *Click GUI* module has Load / Save / New **profile** buttons (`.../profiles/*.json`).

## Mobile (MojoLauncher / PojavLauncher, LTW / OpenGL ES 3)

Normal Fabric mod; it only draws through Minecraft's own `DrawContext` (no raw OpenGL, no custom shaders),
so it does not depend on the renderer.

1. Put `legitclient-1.0.0.jar` and **Fabric API** in the 1.21.11 Fabric profile's `mods` folder (Java 21).
2. In the MojoLauncher control editor add a button that sends **Right Shift** (or any key you bound the
   Click GUI to). Do the same for any module you want to toggle/hold by key (e.g. C for Zoom).
3. The GUI works with taps and drags: tap = toggle, tap **+/-** = settings, drag empty space = scroll,
   **X** (top right) = close. A GUI scale of 2-3 fits best.
4. CPS / Keystrokes read Minecraft's attack/use key state, so they work with touch controls.

## Modules

| Category | Modules |
|----------|---------|
| HUD | Watermark, FPS, CPS, Ping, Coordinates, Compass, Clock, Keystrokes, Armor Status, Potion Effects, Module List |
| Visual | Fullbright, Zoom (hold C), No Hurt Cam, Weather Changer |
| Utility | Toggle Sprint |
| Client | Click GUI (accent color, opacity, background dim, profiles) |

## Project layout

```
dev.legitclient
├─ LegitClient            entry point (events -> ModuleManager)
├─ module/                Module, Category, BindMode, ModuleManager   <- register modules here
│  ├─ hud/                HudModule, TextHudModule + HUD modules
│  ├─ visual/ utility/ client/
├─ setting/               Boolean / Number / Mode / Color / Action settings
├─ config/                ConfigManager (JSON + profiles)
├─ gui/                   ClickGuiScreen, Panel, ModuleButton, Theme, widget/
│                         (icons: util/Icon + assets/legitclient/textures/gui/icons)
├─ mixin/                 the only places that touch Minecraft internals
└─ util/                  Draw helpers, ClickTracker, KeyNames
```

## Icons

Icons are 32x32 PNGs in `src/main/resources/assets/legitclient/textures/gui/icons/` (taken from the original
client's textures). Each icon has a bright file (`name.png`) and a dimmed one (`name_dim.png`, used while a
module is off). To add one: put both files there, add a constant to `util/Icon.java`, and call
`icon(Icon.YOUR_ICON)` in the module's constructor (modules without it show their category icon).
The mod-list icon is `assets/legitclient/icon.png`.

## Adding a module

1. Create a class (pick a package, or add a new `Category` value for a new panel):

```java
public final class Example extends Module {

    private final BooleanSetting loud = add(new BooleanSetting("Loud", false));
    private final NumberSetting amount = add(new NumberSetting("Amount", 5, 1, 10, 1));
    private final ModeSetting style = add(new ModeSetting("Style", "A", "A", "B"));

    public Example() {
        super("Example", "What it does", Category.UTILITY);
        // defaultBind(GLFW.GLFW_KEY_H, BindMode.TOGGLE);  // optional default key
        // enabledByDefault();                              // optional
        amount.showWhen(loud::on);                          // optional: hide a setting
    }

    @Override protected void onEnable()  { }
    @Override protected void onDisable() { }
    @Override public void onTick()       { /* every tick while enabled */ }
}
```

2. Add one line in `ModuleManager.init()`: `register(new Example());`

That is all — the GUI row, settings widgets, key bind and config saving come for free.

**HUD element:** extend `TextHudModule` and return lines from `buildLines()` (see `Fps.java`, 15 lines),
or extend `HudModule` for custom drawing (see `Keystrokes.java`).

**Needs a vanilla hook?** Add a small mixin in `mixin/` and list it in
`legitclient.mixins.json`. Keep the module logic in the module and only a flag/static getter in the mixin
(see `NoHurtCam` + `GameRendererMixin`).

## If something doesn't compile

This project was written without access to the 1.21.11 jars, so a few Minecraft method names may need a
one-line fix on your machine. The places that touch version-specific API are small:

* `gui/ClickGuiScreen.java` – input signatures (`Click`, `KeyInput`)
* `LegitClient.java` – `HudElementRegistry` (older Fabric API: `HudRenderCallback.EVENT`)
* `util/Draw.java` and `util/Icon.java` – `DrawContext` calls (`Icon.draw` is the only texture call)
* `mixin/*` – injectors use `require = 0`, so a target that no longer exists only logs a warning and that
  module does nothing instead of crashing the game.


## GUI assets

Icons in `textures/gui/ui/` are original, drawn for this project. Text uses Poppins (`assets/legitclient/font/`, SIL OFL 1.1, see `OFL-NOTICE.txt`).
