package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.CombatUtil;
import dev.stargg.util.ItemFilters;
import dev.stargg.util.MouseAim;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Smoothly pulls the camera toward the best nearby target. */
public final class AimAssist extends Module {

    private final NumberSetting range = add(new NumberSetting("Range", 4.5, 1.0, 8.0, 0.1));
    private final NumberSetting fov = add(new NumberSetting("FOV", 90.0, 10.0, 360.0, 5.0));
    private final NumberSetting yawSpeed = add(new NumberSetting("Yaw speed", 6.0, 0.5, 40.0, 0.5));
    private final NumberSetting pitchSpeed = add(new NumberSetting("Pitch speed", 4.0, 0.5, 40.0, 0.5));
    private final NumberSetting smoothing = add(new NumberSetting("Smoothing", 4.0, 1.0, 20.0, 0.5));
    private final RandomRangeSetting speedJitter = add(new RandomRangeSetting("Speed variance (%)", 80.0, 100.0, 10.0, 100.0, 1.0));
    private final BooleanSetting mouseLike = add(new BooleanSetting("Mouse-like movement", true));
    private final NumberSetting rampUp = add(new NumberSetting("Ease-in (ms)", 60.0, 0.0, 300.0, 10.0));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Crosshair", "Crosshair", "Distance", "Health"));
    private final ModeSetting aimPoint = add(new ModeSetting("Aim point", "Nearest", "Nearest", "Head", "Body", "Feet"));
    private final BooleanSetting vertical = add(new BooleanSetting("Vertical aim", true));
    private final BooleanSetting stickyTarget = add(new BooleanSetting("Sticky target", true));
    private final BooleanSetting stopOnTarget = add(new BooleanSetting("Stop on target", true));
    private final BooleanSetting onlyWhileAttacking = add(new BooleanSetting("Only while attacking", true));
    private final BooleanSetting ignoreBreaking = add(new BooleanSetting("Not while breaking blocks", true));
    private final MultiSelectSetting weapons = add(new MultiSelectSetting("Weapons", CombatUtil.WEAPON_OPTIONS, "Any"));
    private final MultiSelectSetting targets = add(new MultiSelectSetting("Targets", CombatUtil.TARGET_OPTIONS, "Players"));
    private final BooleanSetting ignoreFriends = add(new BooleanSetting("Ignore friends", true));

    private final MouseAim mouse = new MouseAim();
    private LivingEntity current;
    private boolean aiming;
    private float speedScale = 1.0F;

    public AimAssist() {
        super("Aim Assist", "Smoothly aims the camera at nearby targets", Category.COMBAT);
        rampUp.showWhen(mouseLike::on);
    }

    @Override
    public void onTick() {
        aiming = false;
        if (mc.player == null || mc.world == null || mc.currentScreen != null) {
            current = null;
            return;
        }
        if (onlyWhileAttacking.on() && !mc.options.attackKey.isPressed()) {
            current = null;
            return;
        }
        if (ignoreBreaking.on() && mc.interactionManager != null && mc.interactionManager.isBreakingBlock()) {
            return;
        }
        if (!ItemFilters.matches(mc.player.getMainHandStack(), weapons)) {
            current = null;
            return;
        }

        List<LivingEntity> candidates = CombatUtil.targetsInRange(range.getDouble(), targets, ignoreFriends.on());
        boolean keep = stickyTarget.on() && current != null && candidates.contains(current)
                && CombatUtil.angleTo(current.getBoundingBox().getCenter()) <= fov.getDouble() / 2.0;
        if (!keep) {
            current = CombatUtil.best(candidates, priority.get(), fov.getDouble());
        }
        if (current == null) {
            return;
        }
        if (stopOnTarget.on() && mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == current) {
            return;
        }

        speedScale = (float) (speedJitter.sample() / 100.0);
        aiming = true;
    }

    /** Runs every rendered frame so the camera moves smoothly at any FPS. */
    @Override
    public void onFrame() {
        if (!aiming || current == null || mc.player == null || mc.currentScreen != null || !current.isAlive()) {
            mouse.reset();
            return;
        }
        if (stopOnTarget.on() && mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == current) {
            return;
        }
        Vec3d point = CombatUtil.aimPoint(current, aimPoint.get());
        float[] wanted = CombatUtil.rotationsTo(point);
        mouse.step(mc, wanted[0], vertical.on() ? wanted[1] : mc.player.getPitch(),
                yawSpeed.getFloat() * speedScale, pitchSpeed.getFloat() * speedScale,
                smoothing.getFloat(), mouseLike.on() ? rampUp.getFloat() : 0.0F, mouseLike.on());
    }

    @Override
    protected void onDisable() {
        current = null;
        aiming = false;
        mouse.reset();
    }
}
