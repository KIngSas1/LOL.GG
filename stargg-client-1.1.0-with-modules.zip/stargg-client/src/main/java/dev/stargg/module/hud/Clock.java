package dev.stargg.module.hud;

import dev.stargg.setting.BooleanSetting;
import dev.stargg.util.Icon;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class Clock extends TextHudModule {

    private final BooleanSetting hours24 = add(new BooleanSetting("24 hour", true));
    private final BooleanSetting seconds = add(new BooleanSetting("Seconds", false));

    public Clock() {
        super("Clock", "Your computer's time", 4, 76);
        icon(Icon.CLOCK);
    }

    @Override
    protected List<String> buildLines() {
        String pattern = (hours24.on() ? "HH:mm" : "hh:mm") + (seconds.on() ? ":ss" : "") + (hours24.on() ? "" : " a");
        return List.of(LocalTime.now().format(DateTimeFormatter.ofPattern(pattern)));
    }
}
