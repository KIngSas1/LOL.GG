package dev.stargg.module.hud;

import dev.stargg.StarGG;
import dev.stargg.gui.Theme;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Icon;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Shows the names of all enabled modules (the classic "array list"), right-aligned under a
 * header with the client logo and name.
 */
public final class ModuleList extends HudModule {

    private static final String STAR = "STAR";
    private static final String GG = ".GG";
    private static final int ROW_HEIGHT = 12;
    private static final int HEADER_HEIGHT = 16;
    private static final int BAR_WIDTH = 2;
    private static final int ROW_PAD = 4;
    private static final int LOGO_GAP = 4;

    private final BooleanSetting showHud = add(new BooleanSetting("Show HUD modules", false));
    private final ModeSetting sort = add(new ModeSetting("Sort", "Length", "Length", "Alphabetical"));
    private final BooleanSetting header = add(new BooleanSetting("Logo header", true));
    private final BooleanSetting bar = add(new BooleanSetting("Accent bar", true));

    private List<String> names = List.of();
    private int rowsWidth;

    public ModuleList() {
        super("Module List", "Lists the enabled modules", -4, 4, true);
        icon(Icon.LIST);
    }

    @Override
    protected void prepare() {
        List<String> list = new ArrayList<>();
        for (Module module : StarGG.modules().all()) {
            boolean hidden = module == this
                    || module.getCategory() == Category.CLIENT
                    || (module.getCategory() == Category.HUD && !showHud.on());
            if (module.isEnabled() && !hidden) {
                list.add(module.getName());
            }
        }
        if (sort.is("Length")) {
            list.sort(Comparator.comparingInt(Draw::width).reversed());
        } else {
            list.sort(String::compareToIgnoreCase);
        }
        names = list;
        rowsWidth = 0;
        for (String name : names) {
            rowsWidth = Math.max(rowsWidth, Draw.width(name));
        }
    }

    private int rowExtra() {
        return ROW_PAD * 2 + (bar.on() ? BAR_WIDTH : 0);
    }

    private int headerWidth() {
        return Ui.Tex.LOGO.size + LOGO_GAP + Ui.widthTitle(STAR) + Ui.widthTitle(GG) + ROW_PAD * 2;
    }

    @Override
    protected int contentWidth() {
        int rows = names.isEmpty() ? 0 : rowsWidth + rowExtra();
        return Math.max(rows, header.on() ? headerWidth() : 0);
    }

    @Override
    protected int contentHeight() {
        return (header.on() ? HEADER_HEIGHT : 0) + names.size() * ROW_HEIGHT;
    }

    @Override
    protected void draw(DrawContext context, int x, int y) {
        int w = Math.max(contentWidth(), 30);
        int right = x + w;
        int cursorY = y;

        if (header.on()) {
            int textWidth = Ui.widthTitle(STAR) + Ui.widthTitle(GG);
            int startX = right - ROW_PAD - textWidth - LOGO_GAP - Ui.Tex.LOGO.size;
            Ui.icon(context, Ui.Tex.LOGO, startX, cursorY + (HEADER_HEIGHT - Ui.Tex.LOGO.size) / 2, 0xFFFFFFFF);
            int textX = startX + Ui.Tex.LOGO.size + LOGO_GAP;
            int textY = Ui.middleYTitle(cursorY, HEADER_HEIGHT);
            Ui.textTitle(context, STAR, textX, textY, 0xFFFFFFFF, shadow.on());
            Ui.textTitle(context, GG, textX + Ui.widthTitle(STAR), textY, Theme.accent(), shadow.on());
            cursorY += HEADER_HEIGHT;
            if (!names.isEmpty()) {
                // divider between the header and the list
                Draw.rect(context, x + 2, cursorY - 1, w - 4, 1, Draw.withAlpha(Theme.accent(), 0x90));
            }
        }

        int accent = Theme.accent();
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            int rowY = cursorY + i * ROW_HEIGHT;
            int textRight = right - ROW_PAD - (bar.on() ? BAR_WIDTH : 0);
            Draw.text(context, name, textRight - Draw.width(name), Ui.middleY(rowY, ROW_HEIGHT), textColor(), shadow.on());
            if (bar.on()) {
                Draw.rect(context, right - BAR_WIDTH, rowY + 1, BAR_WIDTH, ROW_HEIGHT - 2, accent);
            }
        }
    }
}
