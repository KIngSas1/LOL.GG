package dev.stargg.module.combat;

import dev.stargg.StarGG;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.module.utility.AutoMace;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.ItemFilters;
import dev.stargg.util.TargetFilters;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

import java.util.Random;

/** Crosshair trigger with Chat V4's delay, target, cooldown and item-filter options. */
public final class Triggerbot extends Module {

    private static final String[] TARGET_OPTIONS = {
            "Players", "Mobs", "Peaceful", "Neutral", "Ignore naked", "Ignore invisible", "Ignore behind walls"
    };
    private static final String[] ITEM_OPTIONS = {
            "Swords", "Axes", "Pickaxes", "Shovels", "Hoes", "Tools", "Mace", "Trident", "Ender Pearl", "Wind Charge", "Hand"
    };

    private final MultiSelectSetting targetFilter = add(new MultiSelectSetting("Target settings", TARGET_OPTIONS, "Players"));
    private final RandomRangeSetting extraDelay = add(new RandomRangeSetting("Extra delay", 0.0, 0.0, -20.0, 20.0, 0.1));
    private final RandomRangeSetting mouseOverDelay = add(new RandomRangeSetting("Mouse over delay", 0.0, 0.0, 0.0, 200.0, 10.0));
    private final BooleanSetting requireMouseDown = add(new BooleanSetting("Require mouse down", false));
    private final BooleanSetting ignoreActivationClick = add(new BooleanSetting("Ignore activation click", false));
    private final BooleanSetting airCrits = add(new BooleanSetting("Air crits", false));
    private final BooleanSetting shieldCheck = add(new BooleanSetting("Shield check", false));
    private final BooleanSetting selectFirstHit = add(new BooleanSetting("Select first hit", false));
    private final NumberSetting targetMissChance = add(new NumberSetting("Target miss chance", 0.0, 0.0, 100.0, 1.0));
    private final NumberSetting earlyHitChance = add(new NumberSetting("Early hit chance", 0.0, 0.0, 100.0, 1.0));
    private final BooleanSetting limitToItems = add(new BooleanSetting("Limit to items", false));
    private final MultiSelectSetting allowedItems = add(new MultiSelectSetting("Allowed items", ITEM_OPTIONS));

    private final Random random = new Random();
    private int hoveredEntityId = -1;
    private long hoveredSince;
    private double rolledExtraDelay;
    private double rolledMouseOverDelay;
    private long cooldownReadySince;
    private boolean missRollResult;
    private boolean wasAttackDown;
    private boolean receivedFirstHit;
    private float lastHealth = -1.0F;
    private boolean earlyRollMade;
    private boolean earlyHitActive;
    private float earlyHitThreshold = 1.0F;

    public Triggerbot() {
        super("Triggerbot", "Automatically attacks valid targets under the crosshair", Category.COMBAT);
        icon(Icon.TRIGGERBOT);
        ignoreActivationClick.showWhen(requireMouseDown::on);
        allowedItems.showWhen(limitToItems::on);
    }

    @Override
    protected void onEnable() {
        receivedFirstHit = false;
        lastHealth = mc.player == null ? -1.0F : mc.player.getHealth();
        wasAttackDown = false;
        resetHover();
        rollTargetDelays();
        missRollResult = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            resetHover();
            wasAttackDown = false;
            return;
        }

        float health = mc.player.getHealth();
        if (lastHealth >= 0.0F && health < lastHealth && hoveredEntityId != -1) {
            receivedFirstHit = true;
        }
        lastHealth = health;

        boolean attackDown = mc.options.attackKey.isPressed();
        boolean justPressed = attackDown && !wasAttackDown;
        wasAttackDown = attackDown;
        if (justPressed) {
            missRollResult = currentTarget() != null && random.nextDouble() * 100.0 < targetMissChance.getDouble();
        }
        if (requireMouseDown.on() && !attackDown) {
            resetHover();
            return;
        }
        if (ignoreActivationClick.on() && requireMouseDown.on() && justPressed) {
            boolean alreadyOnTargetAndReady = currentTarget() != null && hoveredEntityId != -1
                    && mc.player.getAttackCooldownProgress(0.5F) >= 1.0F;
            if (!alreadyOnTargetAndReady) {
                resetHover();
                return;
            }
        }
        if (limitToItems.on() && !ItemFilters.matches(mc.player.getMainHandStack(), allowedItems)) {
            resetHover();
            return;
        }

        LivingEntity target = currentTarget();
        if (target == null) {
            resetHover();
            maybeMissOnEmptyCrosshair();
            return;
        }
        if (shieldCheck.on() && target instanceof PlayerEntity playerTarget && playerTarget.isBlocking()) {
            ShieldBreaker breaker = StarGG.modules().get(ShieldBreaker.class);
            AutoMace autoMace = StarGG.modules().get(AutoMace.class);
            boolean canBreak = breaker != null && breaker.canBreakShield()
                    || autoMace != null && autoMace.canBreakShield(playerTarget);
            if (!canBreak) {
                resetHover();
                return;
            }
        }
        if (airCrits.on() && (mc.player.isOnGround() || mc.player.fallDistance <= 0.0F || mc.player.isTouchingWater())) {
            resetHover();
            return;
        }

        long now = System.currentTimeMillis();
        if (hoveredEntityId != target.getId()) {
            hoveredEntityId = target.getId();
            hoveredSince = now;
            if (selectFirstHit.on()) receivedFirstHit = false;
            rollTargetDelays();
            cooldownReadySince = 0L;
            earlyRollMade = false;
            earlyHitActive = false;
            earlyHitThreshold = 1.0F;
            return;
        }
        if (selectFirstHit.on() && !receivedFirstHit) {
            return;
        }
        if (now - hoveredSince < (long) rolledMouseOverDelay) {
            return;
        }

        float cooldown = mc.player.getAttackCooldownProgress(0.5F);
        boolean ready = cooldown >= 1.0F;
        if (!ready && earlyHitChance.getDouble() > 0.0) {
            if (!earlyRollMade && cooldown >= 0.70F) {
                earlyRollMade = true;
                earlyHitActive = random.nextDouble() * 100.0 < earlyHitChance.getDouble();
                earlyHitThreshold = 0.75F + random.nextFloat() * 0.10F;
            }
            ready = earlyHitActive && cooldown >= earlyHitThreshold;
        }
        if (!ready && rolledExtraDelay < 0.0) {
            float threshold = (float) Math.max(0.0, 1.0 + rolledExtraDelay * 0.05);
            ready = cooldown >= threshold;
        }
        if (!ready) {
            cooldownReadySince = 0L;
            return;
        }
        if (rolledExtraDelay > 0.0) {
            if (cooldownReadySince == 0L) {
                cooldownReadySince = now;
            }
            if (now - cooldownReadySince < rolledExtraDelay * 50.0) {
                return;
            }
        }

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        cooldownReadySince = 0L;
        earlyRollMade = false;
        earlyHitActive = false;
        // The mouse-over timer is per target acquisition; only the attack cooldown delay is re-rolled.
        rolledExtraDelay = extraDelay.sample();
    }

    private LivingEntity currentTarget() {
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) {
            return null;
        }
        Entity entity = hit.getEntity();
        if (!(entity instanceof LivingEntity living)
                || !TargetFilters.matches(living, targetFilter, mc)) {
            return null;
        }
        return living;
    }

    private void maybeMissOnEmptyCrosshair() {
        if (!missRollResult || mc.player.getAttackCooldownProgress(0.5F) < 1.0F) {
            return;
        }
        mc.player.swingHand(Hand.MAIN_HAND);
        missRollResult = false;
    }

    private void rollTargetDelays() {
        rolledExtraDelay = extraDelay.sample();
        rolledMouseOverDelay = mouseOverDelay.sample();
    }

    @Override
    protected void onDisable() {
        resetHover();
        rollTargetDelays();
        missRollResult = false;
        wasAttackDown = false;
        receivedFirstHit = false;
        earlyRollMade = false;
        earlyHitActive = false;
    }

    private void resetHover() {
        hoveredEntityId = -1;
        hoveredSince = 0L;
        cooldownReadySince = 0L;
        receivedFirstHit = false;
    }
}
