package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.CombatUtil;
import dev.stargg.util.MouseAim;
import dev.stargg.util.SilentRotationManager;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Aims a spear at the best target (leading its movement), and can auto-charge and auto-jab. */
public final class SpearAssist extends Module {

    private final NumberSetting range = add(new NumberSetting("Range", 8.0, 2.0, 16.0, 0.5));
    private final NumberSetting fov = add(new NumberSetting("FOV", 90.0, 10.0, 360.0, 5.0));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Crosshair", "Crosshair", "Distance", "Health"));
    private final ModeSetting aimPoint = add(new ModeSetting("Aim point", "Body", "Body", "Head", "Feet", "Nearest"));
    private final NumberSetting aimSpeed = add(new NumberSetting("Aim speed", 12.0, 1.0, 60.0, 0.5));
    private final NumberSetting smoothing = add(new NumberSetting("Smoothing", 2.0, 1.0, 10.0, 0.5));
    private final BooleanSetting prediction = add(new BooleanSetting("Prediction", true));
    private final NumberSetting predictionTicks = add(new NumberSetting("Prediction ticks", 2.0, 0.0, 8.0, 0.5));
    private final BooleanSetting mouseLike = add(new BooleanSetting("Mouse-like movement", true));
    private final NumberSetting rampUp = add(new NumberSetting("Ease-in (ms)", 60.0, 0.0, 300.0, 10.0));
    private final BooleanSetting silentAim = add(new BooleanSetting("Silent aim", false));
    private final BooleanSetting requireSpear = add(new BooleanSetting("Require spear", true));
    private final BooleanSetting onlyWhileCharging = add(new BooleanSetting("Only while charging", true));
    private final BooleanSetting autoCharge = add(new BooleanSetting("Auto charge", false));
    private final NumberSetting chargeRange = add(new NumberSetting("Charge range", 6.0, 2.0, 16.0, 0.5));
    private final BooleanSetting autoJab = add(new BooleanSetting("Auto jab", false));
    private final NumberSetting jabRange = add(new NumberSetting("Jab range", 3.0, 1.0, 6.0, 0.1));
    private final NumberSetting minCooldown = add(new NumberSetting("Min cooldown", 0.9, 0.0, 1.0, 0.05));
    private final RandomRangeSetting jabDelay = add(new RandomRangeSetting("Jab delay (ms)", 20.0, 60.0, 0.0, 500.0, 5.0));
    private final MultiSelectSetting targets = add(new MultiSelectSetting("Targets", CombatUtil.TARGET_OPTIONS, "Players"));
    private final BooleanSetting ignoreFriends = add(new BooleanSetting("Ignore friends", true));

    private final MouseAim mouse = new MouseAim();
    private Vec3d framePoint;
    private int lastTargetId = -1;
    private Vec3d lastTargetPos;
    private boolean forcingUse;
    private float aimYaw;
    private float aimPitch;
    private boolean aimInit;
    private long nextJabAt;

    public SpearAssist() {
        super("Spear Assist", "Aims, charges and jabs with the spear", Category.COMBAT);
        predictionTicks.showWhen(prediction::on);
        mouseLike.showWhen(() -> !silentAim.on());
        rampUp.showWhen(() -> mouseLike.on() && !silentAim.on());
        chargeRange.showWhen(autoCharge::on);
        jabRange.showWhen(autoJab::on);
        minCooldown.showWhen(autoJab::on);
        jabDelay.showWhen(autoJab::on);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            idle();
            return;
        }
        boolean spear = CombatUtil.isSpear(mc.player.getMainHandStack());
        if (requireSpear.on() && !spear) {
            idle();
            return;
        }

        List<LivingEntity> candidates = CombatUtil.targetsInRange(range.getDouble(), targets, ignoreFriends.on());
        LivingEntity target = CombatUtil.best(candidates, priority.get(), fov.getDouble());
        if (target == null) {
            idle();
            return;
        }
        Vec3d velocity = trackVelocity(target);
        float distance = mc.player.distanceTo(target);

        if (autoCharge.on() && spear && distance <= chargeRange.getFloat()) {
            mc.options.useKey.setPressed(true);
            forcingUse = true;
        } else {
            releaseUse();
        }

        boolean charging = spear && mc.player.isUsingItem() || forcingUse;
        if (!onlyWhileCharging.on() || charging) {
            aimAt(target, velocity);
        } else {
            SilentRotationManager.clear(this);
            aimInit = false;
            framePoint = null;
        }

        if (autoJab.on() && spear && !mc.player.isUsingItem() && distance <= jabRange.getFloat()
                && mc.player.getAttackCooldownProgress(0.5F) >= minCooldown.getFloat()) {
            long now = System.currentTimeMillis();
            if (nextJabAt == 0L) {
                nextJabAt = now + (long) jabDelay.sample();
            }
            if (now >= nextJabAt) {
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
                nextJabAt = 0L;
            }
        }
    }

    private Vec3d trackVelocity(LivingEntity target) {
        Vec3d position = target.getEntityPos();
        Vec3d velocity = target.getId() == lastTargetId && lastTargetPos != null
                ? position.subtract(lastTargetPos) : Vec3d.ZERO;
        lastTargetId = target.getId();
        lastTargetPos = position;
        return velocity;
    }

    private void aimAt(LivingEntity target, Vec3d velocity) {
        Vec3d point = CombatUtil.aimPoint(target, aimPoint.get());
        if (prediction.on()) {
            point = point.add(velocity.multiply(predictionTicks.getDouble()));
        }
        if (silentAim.on()) {
            framePoint = null;
            mouse.reset();
            float[] wanted = CombatUtil.rotationsTo(point);
            float speed = aimSpeed.getFloat();
            if (!aimInit) {
                aimYaw = mc.player.getYaw();
                aimPitch = mc.player.getPitch();
                aimInit = true;
            }
            float[] next = CombatUtil.stepRotation(aimYaw, aimPitch, wanted[0], wanted[1], speed, speed, smoothing.getFloat());
            aimYaw = next[0];
            aimPitch = next[1];
            SilentRotationManager.set(this, aimYaw, aimPitch, 6);
        } else {
            SilentRotationManager.clear(this);
            aimInit = false;
            framePoint = point;
        }
    }

    /** Camera aiming runs every rendered frame so it moves like a real mouse. */
    @Override
    public void onFrame() {
        if (framePoint == null || mc.player == null || mc.currentScreen != null) {
            mouse.reset();
            return;
        }
        float[] wanted = CombatUtil.rotationsTo(framePoint);
        float speed = aimSpeed.getFloat();
        mouse.step(mc, wanted[0], wanted[1], speed, speed, smoothing.getFloat(),
                mouseLike.on() ? rampUp.getFloat() : 0.0F, mouseLike.on());
    }

    private void releaseUse() {
        if (forcingUse) {
            mc.options.useKey.setPressed(false);
            forcingUse = false;
        }
    }

    private void idle() {
        framePoint = null;
        mouse.reset();
        releaseUse();
        SilentRotationManager.clear(this);
        aimInit = false;
        lastTargetId = -1;
        lastTargetPos = null;
        nextJabAt = 0L;
    }

    @Override
    protected void onDisable() {
        idle();
    }
}
