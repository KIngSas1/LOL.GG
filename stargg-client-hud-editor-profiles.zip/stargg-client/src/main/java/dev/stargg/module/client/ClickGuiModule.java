package dev.stargg.module.client;

import dev.stargg.StarGG;
import dev.stargg.gui.ClickGuiScreen;
import dev.stargg.module.BindMode;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.ColorSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import org.lwjgl.glfw.GLFW;

/** Opens the click GUI and holds its look settings (accent color, opacity). */
public final class ClickGuiModule extends Module {

    private static ClickGuiModule instance;

    private final ColorSetting accentColor = add(new ColorSetting("Accent", "Teal"));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 92, 50, 100, 1));

    private ClickGuiScreen screen;

    public ClickGuiModule() {
        super("Click GUI", "Opens this menu and changes its look", Category.CLIENT);
        icon(Icon.CLICK_GUI);
        defaultBind(GLFW.GLFW_KEY_RIGHT_SHIFT, BindMode.TOGGLE);
        instance = this;
    }

    // ------------------------------------------------------------ static look-up

    public static int accent() {
        return instance == null ? 0xFF0E9E85 : instance.accentColor.argb();
    }

    public static int panelAlpha() {
        return instance == null ? 235 : (int) Math.round(instance.opacity.getDouble() / 100.0 * 255.0);
    }

    /** Name of the active profile (shown in the GUI). */
    public static String profileName() {
        return StarGG.config().getActiveProfile();
    }

    // -------------------------------------------------------------- behaviour

    @Override
    public boolean isToggleable() {
        return false;
    }

    @Override
    protected boolean savesEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        if (screen == null) {
            screen = new ClickGuiScreen();
        }
        if (mc.currentScreen != screen) {
            mc.setScreen(screen);
        }
    }
}
