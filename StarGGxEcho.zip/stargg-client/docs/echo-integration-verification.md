# Echo integration verification

- `Ww.json` has 87 module records and 15 entries with `enabled: true`.
- The allow-list in `EchoFeatureFilterMixin` matches all 15 enabled original class identities.
- All 15 allowed classes are present in the embedded runtime.
- The embedded runtime contains the same 626 `.class` files as the uploaded `echoclient.jar`; every class file is byte-for-byte identical.
- The embedded runtime has the same 878 archive entry names as the uploaded JAR. Only `fabric.mod.json` content was changed to give the nested runtime its own mod ID, client environment, matching 1.21.11 metadata, and no reference to the missing `echo.accesswidener`.
- The original Echo mixin config, original support classes, assets, and 13 nested library JARs are retained.
- The bundled `src/main/resources/echo/Ww.json` is byte-for-byte identical to the supplied profile.
- A focused Java harness tested the feature-filter logic against a manager with immutable category lists. It retained exactly 15 features and rebuilt both feature and category indexes successfully.
- The modified bridge, profile bootstrap, and feature-filter Java files passed `javac` syntax checks using API stubs.

## Not verified

The full Loom/Gradle project build and an in-game Fabric 1.21.11 launch could not be run here. The Gradle 9.2.0 distribution was not cached and this environment could not resolve `services.gradle.org`. The first full build and in-game test must still be run on a machine with network access and JDK 21.
