package dev.stargg.setting;

import com.google.gson.JsonElement;
import dev.stargg.config.ConfigManager;

import java.util.Objects;
import java.util.function.BooleanSupplier;

/**
 * Base class for every module option. A setting holds a value, knows how to
 * save/load itself and can hide itself in the GUI depending on other settings.
 */
public abstract class Setting<T> {

    private final String name;
    private final T defaultValue;
    protected T value;
    private BooleanSupplier visibility = () -> true;

    protected Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public T get() {
        return value;
    }

    public void set(T newValue) {
        if (!Objects.equals(value, newValue)) {
            value = newValue;
            ConfigManager.markDirty();
        }
    }

    public void reset() {
        set(defaultValue);
    }

    /** Only show this setting in the GUI while the condition is true. */
    public void showWhen(BooleanSupplier condition) {
        this.visibility = condition;
    }

    public boolean isVisible() {
        return visibility.getAsBoolean();
    }

    /** @return JSON to persist, or {@code null} if this setting is not saved. */
    public abstract JsonElement save();

    public abstract void load(JsonElement json);
}
