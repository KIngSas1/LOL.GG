package dev.stargg.util;

import dev.stargg.setting.MultiSelectSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Set;

/** Entity filtering equivalent to the Players/Mobs/Peaceful/Neutral and ignore toggles in Chat V4. */
public final class TargetFilters {

    private TargetFilters() {
    }

    public static boolean matches(LivingEntity target, MultiSelectSetting filter, MinecraftClient client) {
        if (target == null || client.player == null || !target.isAlive() || target == client.player) {
            return false;
        }

        Set<String> selected = filter.getSelected();
        boolean player = target instanceof PlayerEntity;
        boolean hostile = target instanceof HostileEntity;
        boolean peaceful = target instanceof PassiveEntity;
        boolean neutral = target instanceof MobEntity && !hostile && !peaceful && !player;

        boolean categoryMatch = player && selected.contains("Players")
                || hostile && selected.contains("Mobs")
                || peaceful && selected.contains("Peaceful")
                || neutral && selected.contains("Neutral");
        if (!categoryMatch) {
            return false;
        }

        if (player && selected.contains("Ignore naked") && !hasArmor((PlayerEntity) target)) {
            return false;
        }
        if (selected.contains("Ignore invisible") && target.isInvisible()) {
            return false;
        }
        return !selected.contains("Ignore behind walls") || client.player.canSee(target);
    }

    private static boolean hasArmor(PlayerEntity player) {
        return !player.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
                || !player.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                || !player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !player.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }
}
