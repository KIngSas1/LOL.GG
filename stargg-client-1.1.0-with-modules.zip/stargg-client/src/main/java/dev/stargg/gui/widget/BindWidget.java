package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.module.Module;
import dev.stargg.util.KeyNames;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

/** Click, then press a key to bind. Esc cancels, Backspace/Delete or a second click clears. */
final class BindWidget extends SettingWidget {

    private final Module module;
    private boolean listening;

    BindWidget(Module module) {
        this.module = module;
    }

    @Override
    public int height() {
        return LINE;
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, "Bind", Theme.TEXT);
        String value = listening ? "[...]" : "[" + KeyNames.of(module.getKey()) + "]";
        rightText(context, value, listening ? Theme.accent() : Theme.TEXT_DIM);
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (listening) {
                // tapping again while listening clears the bind (no Backspace needed on mobile)
                module.setKey(-1);
                releaseFocus();
            } else {
                listening = true;
                focus(this);
            }
        } else if (button == 1) {
            module.setKey(-1);
        }
    }

    @Override
    protected void onFocusLost() {
        listening = false;
    }

    @Override
    public boolean keyPressed(int key) {
        if (!listening) {
            return false;
        }
        if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
            module.setKey(-1);
        } else if (key != GLFW.GLFW_KEY_ESCAPE) {
            module.setKey(key);
        }
        releaseFocus();
        return true;
    }
}
