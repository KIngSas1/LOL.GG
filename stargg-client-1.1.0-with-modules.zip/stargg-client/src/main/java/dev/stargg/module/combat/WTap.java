package dev.stargg.module.combat;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.concurrent.ThreadLocalRandom;

/** Releases forward briefly after a successful player attack, then restores the key. */
public final class WTap extends Module {

    private final NumberSetting chance = add(new NumberSetting("Chance", 90, 0, 100, 1));
    private final NumberSetting releaseDelay = add(new NumberSetting("Release delay", 0, 0, 250, 10));
    private final NumberSetting rePressDelay = add(new NumberSetting("Re-press delay", 50, 0, 250, 10));
    private final BooleanSetting playersOnly = add(new BooleanSetting("Players only", true));

    private boolean pendingRelease;
    private boolean pendingRePress;
    private boolean restoreForward;
    private long releaseAt;
    private long rePressAt;

    public WTap() {
        super("W-Tap", "Briefly releases forward after attacking to reset sprint", Category.COMBAT);
        icon(Icon.COMBAT);
    }

    @Override
    public void onAttack(Entity target) {
        if (mc.player == null || mc.currentScreen != null || !(target instanceof LivingEntity living) || !living.isAlive()) {
            return;
        }
        if (playersOnly.on() && !(target instanceof PlayerEntity)) {
            return;
        }
        if (pendingRelease || pendingRePress || ThreadLocalRandom.current().nextInt(100) >= chance.getInt()) {
            return;
        }
        restoreForward = mc.options.forwardKey.isPressed();
        releaseAt = System.currentTimeMillis() + releaseDelay.getInt();
        pendingRelease = true;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) {
            restoreForwardKey();
            return;
        }
        long now = System.currentTimeMillis();
        if (pendingRelease && now >= releaseAt) {
            mc.options.forwardKey.setPressed(false);
            pendingRelease = false;
            pendingRePress = true;
            rePressAt = now + rePressDelay.getInt();
        } else if (pendingRePress && now >= rePressAt) {
            mc.options.forwardKey.setPressed(restoreForward);
            pendingRePress = false;
        }
    }

    private void restoreForwardKey() {
        if (mc.player != null && (pendingRelease || pendingRePress)) {
            mc.options.forwardKey.setPressed(restoreForward);
        }
        pendingRelease = false;
        pendingRePress = false;
    }

    @Override
    protected void onDisable() {
        restoreForwardKey();
    }
}
