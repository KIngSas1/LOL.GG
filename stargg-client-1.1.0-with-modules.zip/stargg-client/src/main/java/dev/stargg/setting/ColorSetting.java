package dev.stargg.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

/** A color picked from a fixed palette. The value is the preset's name. */
public final class ColorSetting extends Setting<String> {

    public record Preset(String name, int argb) {
    }

    public static final List<Preset> PRESETS = List.of(
            new Preset("Teal", 0xFF0E9E85),
            new Preset("White", 0xFFFFFFFF),
            new Preset("Red", 0xFFFF5555),
            new Preset("Orange", 0xFFFFAA33),
            new Preset("Yellow", 0xFFFFFF55),
            new Preset("Green", 0xFF55FF55),
            new Preset("Cyan", 0xFF55FFFF),
            new Preset("Blue", 0xFF5599FF),
            new Preset("Purple", 0xFFAA66FF),
            new Preset("Pink", 0xFFFF77CC)
    );

    public ColorSetting(String name, String defaultPreset) {
        super(name, defaultPreset);
    }

    /** @return the selected color as 0xAARRGGBB (alpha is always 255). */
    public int argb() {
        for (Preset p : PRESETS) {
            if (p.name().equalsIgnoreCase(value)) {
                return p.argb();
            }
        }
        return PRESETS.get(0).argb();
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement json) {
        if (json != null && json.isJsonPrimitive()) {
            String saved = json.getAsString();
            for (Preset p : PRESETS) {
                if (p.name().equalsIgnoreCase(saved)) {
                    set(p.name());
                    return;
                }
            }
        }
    }
}
