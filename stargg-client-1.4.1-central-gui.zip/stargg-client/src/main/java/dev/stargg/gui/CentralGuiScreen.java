package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.config.ConfigManager;
import dev.stargg.gui.widget.SettingWidget;
import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.module.client.ClickGuiModule;
import dev.stargg.module.client.HudEditorModule;
import dev.stargg.module.client.ProfilesModule;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * The "Central" click GUI: one window in the middle of the screen instead of a panel per category.
 *
 * <ul>
 *   <li><b>Modules</b> tab: categories in a sidebar, the modules of the selected category in a scrolling list
 *       and a search box that looks through every category. Every module row expands to <em>all</em> of its
 *       settings plus Bind / Bind mode (the same {@link ModuleButton} the Frames GUI uses).</li>
 *   <li><b>Profiles</b> tab: the active profile, unsaved-changes state, auto-save, and a list to load from.
 *       The full manager (create, rename, share, ...) is one button away.</li>
 *   <li>Header buttons: HUD Editor, switch back to the Frames GUI, close.</li>
 * </ul>
 *
 * <p>Like {@link ClickGuiScreen}, the Minecraft input-event types are confined to this class.
 */
public final class CentralGuiScreen extends Screen {

    private enum Tab {
        MODULES("Modules"),
        PROFILES("Profiles");

        private final String title;

        Tab(String title) {
            this.title = title;
        }
    }

    /** A clickable rectangle registered while rendering; clicks are tested against the last frame's list. */
    private record Btn(int x, int y, int w, int h, boolean enabled, Runnable action) {
    }

    private static final int MAX_W = 440;
    private static final int MAX_H = 270;
    private static final int MARGIN = 8;
    private static final int HEADER_H = 28;
    private static final int SIDEBAR_W = 92;
    private static final int SEARCH_H = 24;
    private static final int SIDEBAR_ROW_H = 22;
    private static final int SEARCH_MAX_LENGTH = 24;
    private static final int PAD = 8;

    private static final int PROFILE_ROW_H = 22;
    private static final int BUTTON_H = 20;
    private static final int WARNING = 0xFFE0A030;
    private static final int ERROR = 0xFFE05A5A;

    private final Map<Category, List<ModuleButton>> buttons = new EnumMap<>(Category.class);
    private final List<Btn> clickables = new ArrayList<>();
    private final List<Btn> profileRows = new ArrayList<>();
    private final List<String> profileRowNames = new ArrayList<>();

    private Tab tab = Tab.MODULES;
    private Category category = Category.values()[0];
    private String query = "";
    private boolean searchFocused;
    private int scroll;

    private List<String> profiles = List.of();
    private String selectedProfile;
    private boolean modified;
    private int profileScroll;
    private long lastRefresh;
    private String status = "";
    private boolean statusError;
    private long statusUntil;

    // window layout of the last frame
    private int wx;
    private int wy;
    private int ww;
    private int wh;
    // list viewport of the Modules tab (last frame), used for scrolling and hit testing
    private int vx;
    private int vy;
    private int vw;
    private int vh;
    private int contentHeight;
    // search box of the last frame
    private int sx;
    private int sy;
    private int sw;

    public CentralGuiScreen() {
        super(Text.literal("Click GUI"));
        for (Category c : Category.values()) {
            List<ModuleButton> list = new ArrayList<>();
            for (Module module : StarGG.modules().inCategory(c)) {
                list.add(new ModuleButton(module));
            }
            buttons.put(c, list);
        }
        refreshProfiles();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    protected void init() {
        refreshProfiles();
    }

    private ConfigManager config() {
        return StarGG.config();
    }

    // -------------------------------------------------------------- state

    private void refreshProfiles() {
        profiles = config().listProfiles();
        modified = config().isModified();
        lastRefresh = System.currentTimeMillis();
        if (selectedProfile == null || !profiles.contains(selectedProfile)) {
            selectedProfile = config().getActiveProfile();
        }
    }

    private void flash(String message, boolean error) {
        status = message;
        statusError = error;
        statusUntil = System.currentTimeMillis() + 3000;
    }

    private void openTab(Tab target) {
        SettingWidget.releaseFocus();
        searchFocused = false;
        tab = target;
        if (target == Tab.PROFILES) {
            refreshProfiles();
        }
    }

    private void openCategory(Category target) {
        SettingWidget.releaseFocus();
        category = target;
        query = "";
        searchFocused = false;
        scroll = 0;
    }

    private void switchToFrames() {
        ClickGuiModule.selectStyle(ClickGuiModule.STYLE_FRAMES);
        StarGG.modules().get(ClickGuiModule.class).swapScreen();
    }

    private String filter() {
        return query.toLowerCase(Locale.ROOT).trim();
    }

    /** The module rows currently listed: the whole selected category, or every match while searching. */
    private List<ModuleButton> visibleButtons() {
        String filter = filter();
        if (filter.isEmpty()) {
            return buttons.get(category);
        }
        List<ModuleButton> result = new ArrayList<>();
        for (Category c : Category.values()) {
            for (ModuleButton button : buttons.get(c)) {
                if (button.matches(filter)) {
                    result.add(button);
                }
            }
        }
        return result;
    }

    // ------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        clickables.clear();
        profileRows.clear();
        profileRowNames.clear();

        ww = Math.min(MAX_W, width - MARGIN * 2);
        wh = Math.min(MAX_H, height - MARGIN * 2);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2;

        context.fill(0, 0, width, height, 0x70000000);
        Draw.rect(context, wx, wy, ww, wh, Theme.bg(Theme.SETTING_ROW));

        renderHeader(context, mouseX, mouseY);
        if (tab == Tab.MODULES) {
            renderModules(context, mouseX, mouseY);
        } else {
            renderProfiles(context, mouseX, mouseY);
        }
    }

    // ---- header: logo, tabs, shortcuts, close

    private void renderHeader(DrawContext context, int mouseX, int mouseY) {
        Draw.rect(context, wx, wy, ww, HEADER_H, Theme.bg(Theme.HEADER));
        Draw.rect(context, wx, wy + HEADER_H - 1, ww, 1, Theme.DIVIDER);

        Ui.icon(context, Ui.Tex.LOGO, wx + PAD, wy + (HEADER_H - Ui.Tex.LOGO.size) / 2, Theme.TEXT_BRIGHT);
        int titleX = wx + PAD + 17;
        int titleY = Ui.middleY(wy, HEADER_H);
        Ui.textBold(context, "STAR", titleX, titleY, Theme.TEXT_BRIGHT);
        Ui.textBold(context, ".GG", titleX + Ui.widthBold("STAR"), titleY, Theme.accent());

        // tabs
        int tabX = titleX + Ui.widthBold("STAR") + Ui.widthBold(".GG") + 16;
        for (Tab t : Tab.values()) {
            int tabW = Ui.widthBold(t.title) + 20;
            boolean selected = t == tab;
            boolean hovered = Draw.inside(mouseX, mouseY, tabX, wy, tabW, HEADER_H);
            int color = selected ? Theme.TEXT_BRIGHT : (hovered ? Theme.TEXT : Theme.TEXT_DIM);
            Ui.textBold(context, t.title, tabX + 10, Ui.middleY(wy, HEADER_H), color);
            if (selected) {
                Draw.rect(context, tabX, wy + HEADER_H - 2, tabW, 2, Theme.accent());
            }
            clickables.add(new Btn(tabX, wy, tabW, HEADER_H, true, () -> openTab(t)));
            tabX += tabW;
        }

        // close (far right)
        int closeW = 26;
        int closeX = wx + ww - closeW;
        boolean closeHover = Draw.inside(mouseX, mouseY, closeX, wy, closeW, HEADER_H - 1);
        Ui.textCentered(context, "X", closeX, wy, closeW, HEADER_H, closeHover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        clickables.add(new Btn(closeX, wy, closeW, HEADER_H, true, this::close));

        // shortcuts, right to left
        int right = closeX - 4;
        int btnY = wy + (HEADER_H - 18) / 2;
        int framesW = Ui.width("Frames GUI") + 16;
        right -= framesW;
        smallButton(context, mouseX, mouseY, "Frames GUI", right, btnY, framesW, 18, this::switchToFrames);
        if (ww >= 380) {
            int hudW = Ui.width("HUD Editor") + 16;
            right -= hudW + 4;
            smallButton(context, mouseX, mouseY, "HUD Editor", right, btnY, hudW, 18, HudEditorModule::open);
        }
    }

    private void smallButton(DrawContext context, int mouseX, int mouseY, String label, int x, int y, int w, int h, Runnable action) {
        boolean hovered = Draw.inside(mouseX, mouseY, x, y, w, h);
        Ui.roundRect(context, x, y, w, h, 3, Theme.bg(hovered ? Theme.ROW_HOVER : Theme.ROW));
        Ui.textCentered(context, label, x, y, w, h, hovered ? Theme.TEXT_BRIGHT : Theme.TEXT);
        clickables.add(new Btn(x, y, w, h, true, action));
    }

    // ---- Modules tab

    private void renderModules(DrawContext context, int mouseX, int mouseY) {
        int bodyY = wy + HEADER_H;
        int bodyH = wh - HEADER_H;
        boolean searching = !filter().isEmpty();

        // sidebar with the categories
        Draw.rect(context, wx, bodyY, SIDEBAR_W, bodyH, Theme.bg(Theme.HEADER));
        Draw.rect(context, wx + SIDEBAR_W - 1, bodyY, 1, bodyH, Theme.DIVIDER);
        int rowY = bodyY + 4;
        for (Category c : Category.values()) {
            boolean selected = !searching && c == category;
            boolean hovered = Draw.inside(mouseX, mouseY, wx, rowY, SIDEBAR_W - 1, SIDEBAR_ROW_H);
            if (selected || hovered) {
                Draw.rect(context, wx, rowY, SIDEBAR_W - 1, SIDEBAR_ROW_H, Theme.bg(selected ? Theme.ROW : Theme.ROW_HOVER));
            }
            if (selected) {
                Draw.rect(context, wx, rowY, 2, SIDEBAR_ROW_H, Theme.accent());
            }
            int color = selected ? Theme.accent() : (hovered ? Theme.TEXT : Theme.TEXT_DIM);
            Ui.icon(context, c.tex(), wx + PAD + 2, rowY + (SIDEBAR_ROW_H - c.tex().size) / 2, color);
            Ui.textMiddle(context, c.title(), wx + PAD + 19, rowY, SIDEBAR_ROW_H, color);
            clickables.add(new Btn(wx, rowY, SIDEBAR_W - 1, SIDEBAR_ROW_H, true, () -> openCategory(c)));
            rowY += SIDEBAR_ROW_H;
        }
        // active profile at the bottom of the sidebar
        String profile = Ui.trim(ClickGuiModule.profileName(), SIDEBAR_W - PAD * 2 - 8);
        int badgeW = Ui.width(profile) + 10;
        int badgeY = wy + wh - 22;
        Ui.roundRect(context, wx + PAD, badgeY, badgeW, 14, 2, Theme.bg(Theme.BADGE));
        Ui.textCentered(context, profile, wx + PAD, badgeY, badgeW, 14, Theme.TEXT_DIM);

        // search box
        sx = wx + SIDEBAR_W;
        sy = bodyY;
        sw = ww - SIDEBAR_W;
        Draw.rect(context, sx, sy, sw, SEARCH_H, Theme.bg(Theme.HEADER));
        Draw.rect(context, sx, sy + SEARCH_H - 1, sw, 1, Theme.DIVIDER);
        boolean searchHover = Draw.inside(mouseX, mouseY, sx, sy, sw, SEARCH_H);
        Ui.icon(context, Ui.Tex.SEARCH, sx + PAD, sy + (SEARCH_H - Ui.Tex.SEARCH.size) / 2,
                searchHover || searchFocused ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        int textX = sx + PAD + 16;
        if (query.isEmpty() && !searchFocused) {
            Ui.textMiddle(context, "Search all modules...", textX, sy, SEARCH_H, Theme.TEXT_FAINT);
        } else {
            String shown = Ui.trim(query, sw - PAD * 2 - 20);
            Ui.textMiddle(context, shown, textX, sy, SEARCH_H, Theme.TEXT_BRIGHT);
            if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                Draw.rect(context, textX + Ui.width(shown) + 1, sy + 6, 1, SEARCH_H - 12, Theme.TEXT_BRIGHT);
            }
        }

        // module list
        vx = sx;
        vy = sy + SEARCH_H;
        vw = sw;
        vh = wh - HEADER_H - SEARCH_H;
        List<ModuleButton> list = visibleButtons();
        contentHeight = 0;
        for (ModuleButton button : list) {
            contentHeight += button.height();
        }
        int maxScroll = Math.max(0, contentHeight - vh);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        context.enableScissor(vx, vy, vx + vw, vy + vh);
        int rowW = vw - (maxScroll > 0 ? 5 : 0);
        int cursor = vy - scroll;
        for (ModuleButton button : list) {
            button.render(context, vx, cursor, rowW, mouseX, mouseY);
            cursor += button.height();
        }
        if (list.isEmpty()) {
            Ui.textCentered(context, "No modules match \"" + query + "\"", vx, vy, vw, 40, Theme.TEXT_FAINT);
        }
        context.disableScissor();

        if (maxScroll > 0) {
            int thumbH = Math.max(16, vh * vh / contentHeight);
            int thumbY = vy + (int) ((long) (vh - thumbH) * scroll / maxScroll);
            Draw.rect(context, vx + vw - 3, vy, 2, vh, Theme.bg(Theme.TRACK));
            Draw.rect(context, vx + vw - 3, thumbY, 2, thumbH, Theme.accent());
        }

        renderTooltip(context, mouseX, mouseY, list);
    }

    private void renderTooltip(DrawContext context, int mouseX, int mouseY, List<ModuleButton> list) {
        if (!Draw.inside(mouseX, mouseY, vx, vy, vw, vh)) {
            return;
        }
        for (ModuleButton button : list) {
            if (button.rowHovered(mouseX, mouseY)) {
                String text = button.getModule().getDescription();
                int w = Ui.width(text) + 12;
                int x = Math.min(mouseX + 10, width - w - 2);
                int y = Math.min(mouseY + 10, height - 20);
                Ui.roundRect(context, x, y, w, 16, 3, 0xF0151515);
                Ui.textMiddle(context, text, x + 6, y, 16, Theme.TEXT);
                return;
            }
        }
    }

    // ---- Profiles tab

    private void renderProfiles(DrawContext context, int mouseX, int mouseY) {
        if (System.currentTimeMillis() - lastRefresh > 1000) {
            refreshProfiles();
        }
        String active = config().getActiveProfile();
        boolean builtIn = ConfigManager.DEFAULT_PROFILE.equalsIgnoreCase(active);

        int px = wx + PAD;
        int pw = ww - PAD * 2;
        int y = wy + HEADER_H + PAD;

        // active profile card
        int cardH = 38;
        Draw.rect(context, px, y, pw, cardH, Theme.bg(Theme.ROW));
        Ui.textMiddle(context, "Active profile", px + PAD, y + 3, 12, Theme.TEXT_FAINT);
        Ui.textBold(context, Ui.trim(active, pw / 2), px + PAD, Ui.middleY(y + 16, 16), Theme.TEXT_BRIGHT);
        int saveW = 56;
        int saveX = px + pw - PAD - saveW;
        int btnY = y + (cardH - BUTTON_H) / 2;
        actionButton(context, mouseX, mouseY, "Save", saveX, btnY, saveW, BUTTON_H, !builtIn && modified, () -> saveActive(active));
        String badge = modified ? "Unsaved changes" : "Saved";
        int badgeW = Ui.width(badge) + 10;
        int badgeX = saveX - 8 - badgeW;
        Ui.roundRect(context, badgeX, btnY + 3, badgeW, BUTTON_H - 6, 2, Theme.bg(Theme.BADGE));
        Ui.textCentered(context, badge, badgeX, btnY + 3, badgeW, BUTTON_H - 6, modified ? WARNING : Theme.TEXT_DIM);
        y += cardH + 4;

        // auto-save row
        boolean auto = config().isAutoSaveProfile() && !builtIn;
        int autoH = 22;
        boolean autoHover = !builtIn && Draw.inside(mouseX, mouseY, px, y, pw, autoH);
        Draw.rect(context, px, y, pw, autoH, Theme.bg(autoHover ? Theme.SETTING_HOVER : Theme.ROW));
        Ui.textMiddle(context, builtIn ? "Auto-save (not for the default profile)" : "Auto-save changes to this profile",
                px + PAD, y, autoH, builtIn ? Theme.TEXT_FAINT : Theme.TEXT);
        int pillW = 20;
        int pillH = 10;
        int pillX = px + pw - PAD - pillW;
        int pillY = y + (autoH - pillH) / 2;
        Ui.roundRect(context, pillX, pillY, pillW, pillH, pillH / 2, auto ? Theme.accent() : Theme.TRACK);
        Ui.roundRect(context, auto ? pillX + pillW - 9 : pillX + 1, pillY + 1, 8, 8, 4, 0xFFFFFFFF);
        clickables.add(new Btn(px, y, pw, autoH, !builtIn, () -> {
            config().setAutoSaveProfile(!config().isAutoSaveProfile());
            refreshProfiles();
        }));
        y += autoH + 4;

        // bottom area: buttons + status line
        int buttonsY = wy + wh - PAD - BUTTON_H;
        int statusY = buttonsY - 16;
        int halfW = (pw - 6) / 2;
        actionButton(context, mouseX, mouseY, "Load selected", px, buttonsY, halfW, BUTTON_H, selectedProfile != null, this::loadSelected);
        actionButton(context, mouseX, mouseY, "Profile manager", px + halfW + 6, buttonsY, pw - halfW - 6, BUTTON_H, true, ProfilesModule::open);
        if (System.currentTimeMillis() < statusUntil) {
            Ui.textMiddle(context, Ui.trim(status, pw), px, statusY, 14, statusError ? ERROR : Theme.TEXT_DIM);
        }

        // profile list
        Draw.rect(context, px, y, pw, 14, Theme.bg(Theme.DIVIDER));
        Ui.textMiddle(context, "PROFILES  (double-click to load)", px + PAD, y, 14, Theme.TEXT_FAINT);
        y += 14;
        int visibleRows = Math.max(1, (statusY - y) / PROFILE_ROW_H);
        profileScroll = Math.max(0, Math.min(profileScroll, Math.max(0, profiles.size() - visibleRows)));
        for (int i = 0; i < visibleRows && profileScroll + i < profiles.size(); i++) {
            String name = profiles.get(profileScroll + i);
            int rowY = y + i * PROFILE_ROW_H;
            boolean isSelected = name.equals(selectedProfile);
            boolean hovered = Draw.inside(mouseX, mouseY, px, rowY, pw, PROFILE_ROW_H);
            int bg = isSelected ? Draw.blend(Theme.ROW, Theme.accent(), 0.22f) : (hovered ? Theme.ROW_HOVER : Theme.ROW);
            Draw.rect(context, px, rowY, pw, PROFILE_ROW_H, Theme.bg(bg));
            Ui.textMiddle(context, Ui.trim(name, pw - 80), px + PAD, rowY, PROFILE_ROW_H, isSelected ? Theme.TEXT_BRIGHT : Theme.TEXT);
            if (name.equals(active)) {
                int w = Ui.width("Active") + 10;
                Ui.roundRect(context, px + pw - PAD - w, rowY + 4, w, PROFILE_ROW_H - 8, 2, Theme.accent());
                Ui.textCentered(context, "Active", px + pw - PAD - w, rowY + 4, w, PROFILE_ROW_H - 8, Theme.onAccent());
            }
            profileRows.add(new Btn(px, rowY, pw, PROFILE_ROW_H, true, null));
            profileRowNames.add(name);
        }
        if (profiles.size() > visibleRows) {
            int trackH = visibleRows * PROFILE_ROW_H;
            int thumbH = Math.max(12, trackH * visibleRows / profiles.size());
            int maxScroll = profiles.size() - visibleRows;
            int thumbY = y + (trackH - thumbH) * profileScroll / maxScroll;
            Draw.rect(context, px + pw - 2, y, 2, trackH, Theme.bg(Theme.TRACK));
            Draw.rect(context, px + pw - 2, thumbY, 2, thumbH, Theme.accent());
        }
    }

    private void actionButton(DrawContext context, int mouseX, int mouseY, String label, int x, int y, int w, int h, boolean enabled, Runnable action) {
        boolean hovered = enabled && Draw.inside(mouseX, mouseY, x, y, w, h);
        Ui.roundRect(context, x, y, w, h, 3, Theme.bg(hovered ? Theme.ROW_HOVER : Theme.ROW));
        Ui.textCentered(context, label, x, y, w, h, !enabled ? Theme.TEXT_FAINT : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT));
        clickables.add(new Btn(x, y, w, h, enabled, action));
    }

    private void loadSelected() {
        if (selectedProfile == null) {
            return;
        }
        if (config().loadProfile(selectedProfile)) {
            flash("Loaded " + selectedProfile, false);
        } else {
            flash("Could not load " + selectedProfile, true);
        }
        refreshProfiles();
    }

    private void saveActive(String active) {
        if (config().saveProfile(active)) {
            flash("Saved " + active, false);
        } else {
            flash("Could not save " + active, true);
        }
        refreshProfiles();
    }

    // ------------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        int button = click.button();

        SettingWidget.releaseFocus();

        if (!Draw.inside(mouseX, mouseY, wx, wy, ww, wh)) {
            searchFocused = false;
            return true; // clicks outside the window do nothing (Escape closes)
        }

        if (button == 0) {
            for (int i = clickables.size() - 1; i >= 0; i--) {
                Btn btn = clickables.get(i);
                if (btn.enabled() && Draw.inside(mouseX, mouseY, btn.x(), btn.y(), btn.w(), btn.h())) {
                    searchFocused = false;
                    btn.action().run();
                    return true;
                }
            }
        }

        if (tab == Tab.MODULES) {
            if (button == 0 && Draw.inside(mouseX, mouseY, sx, sy, sw, SEARCH_H)) {
                searchFocused = true;
                return true;
            }
            searchFocused = false;
            if (Draw.inside(mouseX, mouseY, vx, vy, vw, vh)) {
                for (ModuleButton moduleButton : visibleButtons()) {
                    if (moduleButton.mouseClicked(mouseX, mouseY, button)) {
                        return true;
                    }
                }
            }
        } else if (button == 0) {
            for (int i = 0; i < profileRows.size(); i++) {
                Btn row = profileRows.get(i);
                if (Draw.inside(mouseX, mouseY, row.x(), row.y(), row.w(), row.h())) {
                    selectedProfile = profileRowNames.get(i);
                    if (doubled) {
                        loadSelected();
                    }
                    return true;
                }
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (tab == Tab.MODULES) {
            for (ModuleButton moduleButton : visibleButtons()) {
                moduleButton.mouseDragged(click.x());
            }
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        for (List<ModuleButton> list : buttons.values()) {
            list.forEach(ModuleButton::mouseReleased);
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (tab == Tab.MODULES) {
            scroll = Math.max(0, scroll - (int) (verticalAmount * 20)); // clamped on the next frame
        } else {
            profileScroll = Math.max(0, profileScroll - (int) Math.signum(verticalAmount));
        }
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (!searchFocused || tab != Tab.MODULES) {
            return super.charTyped(input);
        }
        int codePoint = input.codepoint();
        if (!Character.isISOControl(codePoint) && query.length() < SEARCH_MAX_LENGTH) {
            query += new String(Character.toChars(codePoint));
            scroll = 0;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();

        SettingWidget focused = SettingWidget.getFocused();
        if (focused != null && focused.keyPressed(key)) {
            return true;
        }

        if (searchFocused) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) {
                    query = query.substring(0, query.length() - 1);
                    scroll = 0;
                }
            } else if (key == GLFW.GLFW_KEY_ESCAPE) {
                query = "";
                scroll = 0;
                searchFocused = false;
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                searchFocused = false;
            }
            return true; // typing must not trigger the GUI's close key
        }

        ClickGuiModule module = StarGG.modules().get(ClickGuiModule.class);
        if (key == GLFW.GLFW_KEY_ESCAPE || (module.getKey() > 0 && key == module.getKey())) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void tick() {
        // "GUI style" was switched back to Frames (e.g. in the Client category): hand over to the frames GUI.
        if (!ClickGuiModule.centralSelected()) {
            StarGG.modules().get(ClickGuiModule.class).swapScreen();
        }
    }

    @Override
    public void removed() {
        SettingWidget.releaseFocus();
        searchFocused = false;
        ClickGuiModule module = StarGG.modules().get(ClickGuiModule.class);
        if (!module.isSwapping()) {
            module.setEnabled(false);
            StarGG.config().save();
        }
    }
}
