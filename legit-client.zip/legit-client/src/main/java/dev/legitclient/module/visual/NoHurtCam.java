package dev.legitclient.module.visual;

import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.util.Icon;

/** Removes the camera shake when you take damage (see {@code GameRendererMixin}). */
public final class NoHurtCam extends Module {

    private static NoHurtCam instance;

    public NoHurtCam() {
        super("No Hurt Cam", "Disables the camera tilt when you get hurt", Category.VISUAL);
        icon(Icon.HURT_CAM);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }
}
