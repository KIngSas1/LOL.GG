package dev.stargg.module.visual;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;

/**
 * Raises the gamma option so dark areas are fully lit. The actual override
 * lives in {@code SimpleOptionMixin}; nothing is written to your options file.
 */
public final class Fullbright extends Module {

    private static Fullbright instance;

    private final NumberSetting gamma = add(new NumberSetting("Gamma", 12, 2, 30, 1));

    public Fullbright() {
        super("Fullbright", "Makes everything fully bright", Category.VISUAL);
        icon(Icon.FULLBRIGHT);
        instance = this;
    }

    public static boolean isActive() {
        return instance != null && instance.isEnabled();
    }

    public static double gamma() {
        return instance == null ? 1.0 : instance.gamma.getDouble();
    }
}
