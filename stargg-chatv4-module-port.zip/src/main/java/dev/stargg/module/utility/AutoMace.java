package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.setting.RandomRangeSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.ItemFilters;
import dev.stargg.util.SilentRotationManager;
import dev.stargg.util.TargetFilters;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Automatic mace selection, falling attacks, aim assist and Elytra swap support. */
public final class AutoMace extends Module {

    private static final String[] TARGET_OPTIONS = {
            "Players", "Mobs", "Peaceful", "Neutral", "Ignore naked", "Ignore invisible", "Ignore behind walls"
    };
    private static final String[] ITEM_OPTIONS = {
            "Swords", "Axes", "Pickaxes", "Shovels", "Hoes", "Tools", "Mace", "Trident", "Ender Pearl", "Wind Charge", "Hand"
    };

    private final MultiSelectSetting targetFilter = add(new MultiSelectSetting("Target settings", TARGET_OPTIONS, "Players"));
    private final BooleanSetting aim = add(new BooleanSetting("Aim", false));
    private final BooleanSetting silentAim = add(new BooleanSetting("Silent aim", false));
    private final NumberSetting aimRange = add(new NumberSetting("Aim range", 6.0, 2.0, 10.0, 0.1));
    private final BooleanSetting attack = add(new BooleanSetting("Attack", false));
    private final RandomRangeSetting extraDelay = add(new RandomRangeSetting("Extra delay", 0.0, 0.0, -20.0, 20.0, 0.1));
    private final BooleanSetting autoUnequipElytra = add(new BooleanSetting("Auto unequip Elytra", false));
    private final BooleanSetting reEquipElytra = add(new BooleanSetting("Re-equip Elytra", false));
    private final BooleanSetting smashOnly = add(new BooleanSetting("Smash only", true));
    private final ModeSetting maceSelection = add(new ModeSetting("Mace selection", "Manual", "Manual", "Auto"));
    private final ModeSetting maceType = add(new ModeSetting("Mace type", "Density", "Density", "Breach"));
    private final BooleanSetting stunSlam = add(new BooleanSetting("Stun slam", false));
    private final NumberSetting chance = add(new NumberSetting("Chance", 100.0, 0.0, 100.0, 1.0));
    private final BooleanSetting limitToItems = add(new BooleanSetting("Limit to items", false));
    private final MultiSelectSetting allowedItems = add(new MultiSelectSetting("Allowed items", ITEM_OPTIONS, "Swords"));

    private final Random random = new Random();
    private int savedSlot = -1;
    private int maceSlot = -1;
    private int actionDelay;
    private int restoreDelay;
    private LivingEntity pendingTarget;
    private boolean attackPending;
    private boolean internalAttack;
    private boolean restorePending;
    private boolean stunPending;
    private boolean stunHitSent;
    private int stunWaitTicks;
    private int elytraSwapSlot = -1;
    private boolean elytraUnequipped;
    private float previousVerticalVelocity;
    private float assistedYaw;
    private float assistedPitch;
    private boolean aimRotationInitialized;
    private long cooldownReadySince;
    private int delayTargetId = -1;
    private double appliedExtraDelay;

    public AutoMace() {
        super("Auto Mace", "Swaps to a mace for falling smash attacks", Category.UTILITY);
        icon(Icon.AUTO_MACE);
        silentAim.showWhen(aim::on);
        aimRange.showWhen(aim::on);
        extraDelay.showWhen(attack::on);
        reEquipElytra.showWhen(autoUnequipElytra::on);
        maceType.showWhen(() -> maceSelection.is("Manual"));
        chance.showWhen(stunSlam::on);
        allowedItems.showWhen(limitToItems::on);
        appliedExtraDelay = extraDelay.sample();
    }

    @Override
    protected void onEnable() {
        appliedExtraDelay = extraDelay.sample();
        cooldownReadySince = 0L;
        delayTargetId = -1;
    }

    public boolean canBreakShield(PlayerEntity target) {
        return isEnabled() && stunSlam.on() && mc.player != null
                && (!limitToItems.on() || ItemFilters.matches(mc.player.getMainHandStack(), allowedItems))
                && mc.player.getMainHandStack().getItem() instanceof AxeItem
                && target != null && TargetFilters.matches(target, targetFilter, mc)
                && findMaceSlot(target) >= 0;
    }

    /** Called by the attack mixin; consumes an eligible manual hit while swapping to the mace. */
    public boolean interceptAttack(Entity entity) {
        if (!isEnabled() || internalAttack || attackPending || restorePending || stunPending || mc.player == null
                || !(entity instanceof LivingEntity living) || !TargetFilters.matches(living, targetFilter, mc)) {
            return false;
        }
        if (limitToItems.on() && !ItemFilters.matches(mc.player.getMainHandStack(), allowedItems)) {
            return false;
        }
        if (smashOnly.on() && !isFallingForSmash()) {
            return false;
        }
        int found = findMaceSlot(living);
        if (found < 0 || found == mc.player.getInventory().getSelectedSlot()) {
            return false;
        }
        startMaceAttack(living, found, true);
        return true;
    }

    @Override
    public void onAttack(Entity target) {
        if (!isEnabled() || !stunSlam.on() || stunPending || mc.player == null
                || !(target instanceof PlayerEntity playerTarget) || !TargetFilters.matches(playerTarget, targetFilter, mc)
                || !playerTarget.isBlocking()
                || !(mc.player.getMainHandStack().getItem() instanceof AxeItem)
                || random.nextDouble() * 100.0 >= chance.getDouble()) {
            return;
        }
        int found = findMaceSlot(playerTarget);
        if (found >= 0) {
            pendingTarget = playerTarget;
            maceSlot = found;
            savedSlot = mc.player.getInventory().getSelectedSlot();
            stunPending = true;
            stunHitSent = false;
            stunWaitTicks = 0;
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            releaseAll();
            SilentRotationManager.clear(this);
            aimRotationInitialized = false;
            return;
        }

        handleStunSlam();
        handlePendingAttack();
        handleElytra();

        if (aim.on() && !attackPending && !restorePending && mc.player.fallDistance > 0.0F) {
            LivingEntity target = findAimTarget();
            if (target != null) {
                aimAt(target);
            } else {
                SilentRotationManager.clear(this);
                aimRotationInitialized = false;
            }
        } else {
            SilentRotationManager.clear(this);
            aimRotationInitialized = false;
        }

        if (!attack.on() || attackPending || restorePending || stunPending) {
            return;
        }
        if (limitToItems.on() && !ItemFilters.matches(mc.player.getMainHandStack(), allowedItems)) {
            return;
        }
        if (smashOnly.on() && !isFallingForSmash()) {
            return;
        }
        LivingEntity target = aim.on() ? findAimTarget() : crosshairTarget();
        if (target == null || mc.player.distanceTo(target) > (aim.on() ? aimRange.getDouble() : 4.5)) {
            return;
        }
        if (delayTargetId != target.getId()) {
            delayTargetId = target.getId();
            appliedExtraDelay = extraDelay.sample();
            cooldownReadySince = 0L;
        }
        long now = System.currentTimeMillis();
        float cooldown = mc.player.getAttackCooldownProgress(0.5F);
        float threshold = appliedExtraDelay < 0.0
                ? (float) Math.max(0.0, 1.0 + appliedExtraDelay * 0.05) : 1.0F;
        if (cooldown < threshold) {
            cooldownReadySince = 0L;
            return;
        }
        if (appliedExtraDelay > 0.0) {
            if (cooldownReadySince == 0L) cooldownReadySince = now;
            if (now - cooldownReadySince < appliedExtraDelay * 50.0) return;
        }
        int found = findMaceSlot(target);
        if (found < 0) {
            return;
        }
        startMaceAttack(target, found, false);
        cooldownReadySince = 0L;
        delayTargetId = -1;
    }

    private void handlePendingAttack() {
        if (attackPending) {
            if (pendingTarget == null || !pendingTarget.isAlive()) {
                restoreSlot();
                return;
            }
            if (actionDelay > 0) {
                actionDelay--;
                return;
            }
            if (mc.player.getAttackCooldownProgress(0.5F) < 1.0F) {
                return;
            }
            internalAttack = true;
            try {
                mc.interactionManager.attackEntity(mc.player, pendingTarget);
                mc.player.swingHand(Hand.MAIN_HAND);
            } finally {
                internalAttack = false;
            }
            attackPending = false;
            restorePending = true;
            restoreDelay = 1;
            return;
        }
        if (restorePending) {
            if (restoreDelay > 0) {
                restoreDelay--;
            } else {
                restoreSlot();
            }
        }
    }

    private void handleStunSlam() {
        if (!stunPending) {
            return;
        }
        if (pendingTarget == null || !pendingTarget.isAlive() || ++stunWaitTicks > 8) {
            resetStun();
            return;
        }
        if (!stunHitSent) {
            // The original manual axe hit is allowed to break the shield first.
            if (pendingTarget.isBlocking()) {
                return;
            }
            if (mc.player.getAttackCooldownProgress(0.5F) < 1.0F) {
                return;
            }
            mc.player.getInventory().setSelectedSlot(maceSlot);
            internalAttack = true;
            try {
                mc.interactionManager.attackEntity(mc.player, pendingTarget);
                mc.player.swingHand(Hand.MAIN_HAND);
            } finally {
                internalAttack = false;
            }
            stunHitSent = true;
            restoreDelay = 1;
        } else if (restoreDelay-- <= 0) {
            restoreSlot();
            resetStun();
        }
    }

    private void startMaceAttack(LivingEntity target, int foundMace, boolean manual) {
        pendingTarget = target;
        savedSlot = mc.player.getInventory().getSelectedSlot();
        maceSlot = foundMace;
        actionDelay = 0;
        mc.player.getInventory().setSelectedSlot(maceSlot);
        attackPending = true;
        restorePending = false;
    }

    private LivingEntity findAimTarget() {
        if (mc.player == null || mc.world == null) return null;
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity entity : mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(aimRange.getDouble()),
                candidate -> candidate instanceof LivingEntity && candidate.isAlive())) {
            if (entity instanceof LivingEntity living
                    && TargetFilters.matches(living, targetFilter, mc)
                    && mc.player.distanceTo(living) <= aimRange.getDouble()) {
                double distance = mc.player.squaredDistanceTo(living);
                if (distance < bestDistance) {
                    best = living;
                    bestDistance = distance;
                }
            }
        }
        return best;
    }

    private LivingEntity crosshairTarget() {
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity living
                && TargetFilters.matches(living, targetFilter, mc)) {
            return living;
        }
        return null;
    }

    private void aimAt(LivingEntity target) {
        Vec3d diff = target.getBoundingBox().getCenter().subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, horizontal));
        if (!aimRotationInitialized) {
            assistedYaw = mc.player.getYaw();
            assistedPitch = mc.player.getPitch();
            aimRotationInitialized = true;
        }
        float yawDelta = MathHelper.wrapDegrees(yaw - assistedYaw);
        float pitchDelta = pitch - assistedPitch;
        assistedYaw += MathHelper.clamp(yawDelta, -6.0F, 6.0F);
        assistedPitch = MathHelper.clamp(assistedPitch + MathHelper.clamp(pitchDelta, -6.0F, 6.0F), -90.0F, 90.0F);
        if (silentAim.on()) {
            SilentRotationManager.set(this, assistedYaw, assistedPitch, 5);
        } else {
            SilentRotationManager.clear(this);
            mc.player.setYaw(assistedYaw);
            mc.player.setPitch(assistedPitch);
        }
    }

    private int findMaceSlot(LivingEntity target) {
        int selected = mc.player.getInventory().getSelectedSlot();
        int bestSlot = -1;
        double bestScore = -1.0;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isEmpty() || !Registries.ITEM.getId(stack.getItem()).getPath().equals("mace")) {
                continue;
            }
            int density = enchantmentLevel(stack, "density");
            int breach = enchantmentLevel(stack, "breach");
            if (maceSelection.is("Manual")) {
                boolean matchesType = maceType.is("Density") ? density > 0 : breach > 0;
                if (!matchesType) continue;
                if (slot == selected) return slot;
                if (bestSlot < 0) bestSlot = slot;
                continue;
            }
            if (density == 0 && breach == 0) continue;
            double armor = armorPieces(target);
            double score = density * (Math.max(1.0, mc.player.fallDistance) + 1.0)
                    + breach * (armor * 2.0 + 1.0);
            if (slot == selected) score += 0.001;
            if (score > bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    /** Reads the enchantment component's registry-key text without depending on a version-specific registry API. */
    private int enchantmentLevel(ItemStack stack, String enchantment) {
        String components = stack.getComponents().toString().toLowerCase(Locale.ROOT);
        if (!components.contains(enchantment)) return 0;
        Matcher matcher = Pattern.compile("(?:minecraft:)?" + Pattern.quote(enchantment) + "\\s*[=:>]\\s*(\\d+)")
                .matcher(components);
        return matcher.find() ? Integer.parseInt(matcher.group(1)) : 1;
    }

    private int armorPieces(LivingEntity entity) {
        if (!(entity instanceof PlayerEntity player)) return 0;
        int count = 0;
        if (!player.getEquippedStack(EquipmentSlot.HEAD).isEmpty()) count++;
        if (!player.getEquippedStack(EquipmentSlot.CHEST).isEmpty()) count++;
        if (!player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()) count++;
        if (!player.getEquippedStack(EquipmentSlot.FEET).isEmpty()) count++;
        return count;
    }

    private boolean isFallingForSmash() {
        return !mc.player.isOnGround() && mc.player.fallDistance >= 1.5F && mc.player.getVelocity().y < 0.0;
    }

    private void handleElytra() {
        if (!autoUnequipElytra.on()) {
            return;
        }
        if (!elytraUnequipped && mc.player.fallDistance >= 1.0F
                && mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            int chestplateSlot = findChestplateSlot();
            if (chestplateSlot >= 0) {
                swapChestSlot(chestplateSlot);
                elytraSwapSlot = chestplateSlot;
                elytraUnequipped = true;
            }
        }
        if (elytraUnequipped && reEquipElytra.on() && mc.player.getVelocity().y > 0.35 && previousVerticalVelocity <= 0.35) {
            swapChestSlot(elytraSwapSlot);
            elytraUnequipped = false;
            elytraSwapSlot = -1;
        }
        previousVerticalVelocity = (float) mc.player.getVelocity().y;
    }

    private int findChestplateSlot() {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            String path = Registries.ITEM.getId(stack.getItem()).getPath();
            if (path.endsWith("_chestplate") && !stack.isEmpty()) {
                return slot;
            }
        }
        return -1;
    }

    private void swapChestSlot(int hotbarSlot) {
        if (hotbarSlot < 0 || hotbarSlot > 8 || mc.interactionManager == null) return;
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, 6, hotbarSlot,
                net.minecraft.screen.slot.SlotActionType.SWAP, mc.player);
    }

    private void restoreSlot() {
        if (mc.player != null && savedSlot >= 0 && savedSlot < 9) {
            mc.player.getInventory().setSelectedSlot(savedSlot);
        }
        savedSlot = -1;
        maceSlot = -1;
        pendingTarget = null;
        attackPending = false;
        restorePending = false;
        actionDelay = 0;
        restoreDelay = 0;
    }

    private void resetStun() {
        stunPending = false;
        stunHitSent = false;
        stunWaitTicks = 0;
        if (mc.player != null && savedSlot >= 0) {
            mc.player.getInventory().setSelectedSlot(savedSlot);
        }
        savedSlot = -1;
        maceSlot = -1;
        pendingTarget = null;
    }

    private void releaseAll() {
        restoreSlot();
        resetStun();
    }

    @Override
    protected void onDisable() {
        releaseAll();
        SilentRotationManager.clear(this);
        if (mc.player != null && elytraUnequipped && reEquipElytra.on()) {
            swapChestSlot(elytraSwapSlot);
        }
        cooldownReadySince = 0L;
        delayTargetId = -1;
        elytraUnequipped = false;
        elytraSwapSlot = -1;
    }
}
