package dev.legitclient.module.hud;

import dev.legitclient.util.Draw;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/**
 * A HUD element that is just a few lines of text. Implement {@link #buildLines()}
 * and you are done — see {@code Fps} for the smallest example.
 */
public abstract class TextHudModule extends HudModule {

    private static final int LINE_HEIGHT = 10;

    private List<String> lines = List.of();
    private int cachedWidth;

    protected TextHudModule(String name, String description, int defaultX, int defaultY) {
        super(name, description, defaultX, defaultY);
    }

    /** The text lines to show this frame. */
    protected abstract List<String> buildLines();

    /** Right-align the lines inside the box (used by the module list). */
    protected boolean alignRight() {
        return false;
    }

    @Override
    protected final void prepare() {
        lines = buildLines();
        cachedWidth = 0;
        for (String line : lines) {
            cachedWidth = Math.max(cachedWidth, Draw.width(line));
        }
    }

    @Override
    protected final int contentWidth() {
        return cachedWidth;
    }

    @Override
    protected final int contentHeight() {
        return lines.size() * LINE_HEIGHT - 1;
    }

    @Override
    protected final void draw(DrawContext context, int x, int y) {
        int lineY = y;
        for (String line : lines) {
            int lineX = alignRight() ? x + Math.max(cachedWidth, 30) - Draw.width(line) : x;
            text(context, line, lineX, lineY);
            lineY += LINE_HEIGHT;
        }
    }
}
