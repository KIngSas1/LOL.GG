package dev.legitclient.module.hud;

import dev.legitclient.util.Icon;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class PotionEffects extends TextHudModule {

    public PotionEffects() {
        super("Potion Effects", "Active status effects with their remaining time", 4, 92);
        icon(Icon.POTION);
        enabledByDefault();
    }

    @Override
    protected List<String> buildLines() {
        if (mc.player == null) {
            return List.of();
        }
        List<StatusEffectInstance> effects = new ArrayList<>(mc.player.getStatusEffects());
        effects.sort(Comparator.comparingInt(StatusEffectInstance::getDuration).reversed());

        List<String> lines = new ArrayList<>();
        for (StatusEffectInstance effect : effects) {
            String name = effect.getEffectType().value().getName().getString();
            if (effect.getAmplifier() > 0) {
                name += " " + (effect.getAmplifier() + 1);
            }
            lines.add(name + " " + formatDuration(effect));
        }
        return lines;
    }

    private static String formatDuration(StatusEffectInstance effect) {
        if (effect.isInfinite()) {
            return "**:**";
        }
        int seconds = effect.getDuration() / 20;
        return String.format("%d:%02d", seconds / 60, seconds % 60);
    }
}
