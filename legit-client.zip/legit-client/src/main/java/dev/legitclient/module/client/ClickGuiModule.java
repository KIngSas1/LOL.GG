package dev.legitclient.module.client;

import dev.legitclient.LegitClient;
import dev.legitclient.config.ConfigManager;
import dev.legitclient.gui.ClickGuiScreen;
import dev.legitclient.module.BindMode;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.setting.ActionSetting;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.setting.ColorSetting;
import dev.legitclient.setting.ModeSetting;
import dev.legitclient.setting.NumberSetting;
import dev.legitclient.util.Icon;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Opens the click GUI and holds the client-wide settings (theme and config profiles). */
public final class ClickGuiModule extends Module {

    private static ClickGuiModule instance;

    private final ColorSetting accentColor = add(new ColorSetting("Accent", "Blue"));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 92, 50, 100, 1));
    private final BooleanSetting dim = add(new BooleanSetting("Dim background", true));

    private final ModeSetting profile = add(new ModeSetting("Profile", "default", "default").transientValue());
    private final ActionSetting loadProfile = add(new ActionSetting("Load profile", this::loadSelectedProfile));
    private final ActionSetting saveProfile = add(new ActionSetting("Save profile", this::saveSelectedProfile));
    private final ActionSetting newProfile = add(new ActionSetting("New profile", this::createProfile));

    private ClickGuiScreen screen;

    public ClickGuiModule() {
        super("Click GUI", "Opens this menu and changes its look", Category.CLIENT);
        icon(Icon.CLICK_GUI);
        defaultBind(GLFW.GLFW_KEY_RIGHT_SHIFT, BindMode.TOGGLE);
        instance = this;
    }

    // ------------------------------------------------------------ static look-up

    public static int accent() {
        return instance == null ? 0xFF5599FF : instance.accentColor.argb();
    }

    public static int panelAlpha() {
        return instance == null ? 235 : (int) Math.round(instance.opacity.getDouble() / 100.0 * 255.0);
    }

    public static boolean dimBackground() {
        return instance == null || instance.dim.on();
    }

    // -------------------------------------------------------------- behaviour

    @Override
    public boolean isToggleable() {
        return false;
    }

    @Override
    protected boolean savesEnabledState() {
        return false;
    }

    @Override
    protected void onEnable() {
        refreshProfiles();
        if (screen == null) {
            screen = new ClickGuiScreen();
        }
        if (mc.currentScreen != screen) {
            mc.setScreen(screen);
        }
    }

    // ---------------------------------------------------------------- profiles

    private void refreshProfiles() {
        profile.setModes(LegitClient.config().listProfiles());
    }

    private void loadSelectedProfile() {
        LegitClient.config().loadProfile(profile.get());
    }

    private void saveSelectedProfile() {
        LegitClient.config().saveProfile(profile.get());
        refreshProfiles();
    }

    private void createProfile() {
        ConfigManager config = LegitClient.config();
        List<String> existing = config.listProfiles();
        int number = 1;
        while (existing.contains("profile-" + number)) {
            number++;
        }
        String name = "profile-" + number;
        config.saveProfile(name);
        refreshProfiles();
        profile.set(name);
    }
}
