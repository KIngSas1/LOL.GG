package dev.stargg.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public final class NumberSetting extends Setting<Double> {

    private double min;
    private double max;
    private double step;
    private String suffix = "";

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix == null ? "" : suffix;
    }

    public String getSuffix() {
        return suffix;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    /** Updates limits supplied by an external setting while preserving its current value. */
    public void setBounds(double min, double max, double step) {
        if (!validBounds(min, max)) {
            return;
        }
        this.min = min;
        this.max = max;
        this.step = Math.max(0.0, step);
        set(value);
    }

    /** Updates external bounds and clamps the mirrored value without firing its change listener. */
    public void setBoundsSilently(double min, double max, double step) {
        if (!validBounds(min, max)) {
            return;
        }
        this.min = min;
        this.max = max;
        this.step = Math.max(0.0, step);
        setSilently(normalize(value));
    }

    private static boolean validBounds(double min, double max) {
        return Double.isFinite(min) && Double.isFinite(max) && min <= max;
    }

    private double normalize(double newValue) {
        double v = Math.max(min, Math.min(max, newValue));
        if (step > 0.0) {
            v = min + Math.round((v - min) / step) * step;
            v = Math.max(min, Math.min(max, v));
        }
        return v;
    }

    /** Mirrors an external value without invoking its change listener. */
    public void setValueSilently(double newValue) {
        if (Double.isFinite(newValue)) {
            setSilently(normalize(newValue));
        }
    }

    public double getDouble() {
        return value;
    }

    public float getFloat() {
        return value.floatValue();
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    /** Clamps to [min, max] and snaps to the step size. */
    @Override
    public void set(Double newValue) {
        if (newValue == null || !Double.isFinite(newValue)) {
            return;
        }
        super.set(normalize(newValue));
    }

    /** Text shown next to the slider, e.g. "4" or "1.5". */
    public String display() {
        String formatted;
        if (step >= 1) {
            formatted = Integer.toString(getInt());
        } else if (step > 0.0 && Double.isFinite(step)) {
            int decimals = Math.max(1, (int) Math.ceil(-Math.log10(step)));
            formatted = String.format(java.util.Locale.ROOT, "%." + decimals + "f", value);
        } else {
            formatted = String.format(java.util.Locale.ROOT, "%.2f", value);
        }
        return suffix.isBlank() ? formatted : formatted + suffix;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement json) {
        if (json != null && json.isJsonPrimitive()) {
            set(json.getAsDouble());
        }
    }
}
