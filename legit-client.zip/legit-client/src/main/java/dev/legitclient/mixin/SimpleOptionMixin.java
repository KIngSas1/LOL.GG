package dev.legitclient.mixin;

import dev.legitclient.module.visual.Fullbright;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fullbright: reports a huge value for the gamma option while the module is on. */
@Mixin(SimpleOption.class)
public abstract class SimpleOptionMixin<T> {

    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true, require = 0)
    @SuppressWarnings("unchecked")
    private void legitclient$fullbright(CallbackInfoReturnable<T> cir) {
        if (!Fullbright.isActive()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.options != null && (Object) this == client.options.getGamma()) {
            cir.setReturnValue((T) Double.valueOf(Fullbright.gamma()));
        }
    }
}
