package dev.legitclient.gui.widget;

import dev.legitclient.gui.Theme;
import dev.legitclient.setting.ModeSetting;
import net.minecraft.client.gui.DrawContext;

final class ModeWidget extends SettingWidget {

    private final ModeSetting setting;

    ModeWidget(ModeSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return 14;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT_DIM);
        rightText(context, setting.get(), Theme.accent());
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 0) {
            setting.cycle(1);
        } else if (button == 1) {
            setting.cycle(-1);
        }
    }
}
