package dev.stargg.util;

import dev.stargg.StarGG;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Closes the profile's saved GUI-open flag before Echo Click GUI is exposed as a native STAR.GG entry. */
public final class EchoModuleBridge {

    private EchoModuleBridge() {
    }

    /** Keeps the profile's settings and bind while preventing its saved GUI-open flag from opening on boot. */
    public static void closeOriginalClickGui() {
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) {
                loader = EchoModuleBridge.class.getClassLoader();
            }

            Class<?> echoMain = Class.forName("hack.echo.o", true, loader);
            Field managerField = echoMain.getField("featureManager");
            Object manager = managerField.get(null);
            if (manager == null) {
                throw new IllegalStateException("Echo feature manager is not initialized yet");
            }

            Class<?> clickGuiType = Class.forName("hack.echo.gm", true, loader);
            Method lookup = manager.getClass().getMethod("getFeatureByClass", Class.class);
            Object clickGui = lookup.invoke(manager, clickGuiType);
            if (clickGui == null) {
                throw new IllegalStateException("Original Echo Click GUI module was not registered");
            }

            Method setEnabled = clickGui.getClass().getMethod("setEnabled", boolean.class);
            setEnabled.invoke(clickGui, false);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            StarGG.LOGGER.error("Could not close the original Echo GUI after profile load", exception);
        }
    }
}
