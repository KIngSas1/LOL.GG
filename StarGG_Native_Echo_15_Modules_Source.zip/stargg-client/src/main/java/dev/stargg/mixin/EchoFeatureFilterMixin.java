package dev.stargg.mixin;

import dev.stargg.StarGG;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Keeps the original Echo feature implementations, but limits the embedded runtime's
 * registry to the 15 entries enabled in the supplied Ww.json profile.
 *
 * The original category lists are unmodifiable after initialization, so this mixin
 * rebuilds the category cache instead of trying to mutate those lists in place.
 */
@Mixin(targets = "hack.echo.gP", remap = false)
public abstract class EchoFeatureFilterMixin {

    private static final Set<String> STARGG$ALLOWED_FEATURES = Set.of(
            "hack.echo.a2", // Aim Assist
            "hack.echo.ac", // Auto Mace
            "hack.echo.g0", // Capes
            "hack.echo.gm", // Click GUI
            "hack.echo.aW", // Jump Reset
            "hack.echo.gA", // Mace Swap
            "hack.echo.bO", // Move Fix
            "hack.echo.cv", // No Jump Delay
            "hack.echo.aQ", // Pot Refill
            "hack.echo.ce", // Spear Assist
            "hack.echo.ha", // Spear Lunge
            "hack.echo.eI", // Spear Reach
            "hack.echo.dg", // Sprint
            "hack.echo.aP", // Targets
            "hack.echo.b_"  // Trigger Bot
    );

    @Inject(method = "initialize", at = @At("TAIL"), remap = false)
    private void stargg$filterToWwEnabledModules(CallbackInfo ci) {
        try {
            Class<?> managerClass = this.getClass();

            Field featuresField = managerClass.getDeclaredField("features");
            Field categoriesField = managerClass.getDeclaredField("categoryCache");
            Field cacheField = managerClass.getDeclaredField("featureCache");
            featuresField.setAccessible(true);
            categoriesField.setAccessible(true);
            cacheField.setAccessible(true);

            Object featuresObject = featuresField.get(this);
            Object categoriesObject = categoriesField.get(this);
            Object cacheObject = cacheField.get(this);
            if (!(featuresObject instanceof Collection<?> registeredFeatures)
                    || !(categoriesObject instanceof Map<?, ?> rawCategories)
                    || !(cacheObject instanceof Map<?, ?> rawFeatureCache)) {
                throw new IllegalStateException("Echo feature manager fields have unexpected runtime types");
            }

            int registeredBeforeFiltering = registeredFeatures.size();
            List<Object> retainedFeatures = new ArrayList<>();
            for (Object feature : registeredFeatures) {
                if (feature != null && STARGG$ALLOWED_FEATURES.contains(feature.getClass().getName())) {
                    retainedFeatures.add(feature);
                }
            }

            // Build all replacement indexes before mutating the original manager.
            ClassLoader loader = managerClass.getClassLoader();
            Class<?> categoryType = Class.forName("hack.echo.fO", true, loader);
            Object[] categoryConstants = categoryType.getEnumConstants();
            if (categoryConstants == null) {
                throw new IllegalStateException("Echo category type is not an enum");
            }

            Map<Object, List<Object>> grouped = new LinkedHashMap<>();
            for (Object category : categoryConstants) {
                grouped.put(category, new ArrayList<>());
            }

            Map<Object, Object> newFeatureCache = new LinkedHashMap<>();
            for (Object feature : retainedFeatures) {
                Method getCategory = feature.getClass().getMethod("getCategory");
                Object category = getCategory.invoke(feature);
                List<Object> categoryFeatures = grouped.get(category);
                if (categoryFeatures == null) {
                    throw new IllegalStateException("Unknown Echo category for " + feature.getClass().getName());
                }
                categoryFeatures.add(feature);
                newFeatureCache.put(feature.getClass(), feature);
            }

            // The source collection is a CopyOnWriteArrayList; removeIf is safe here.
            @SuppressWarnings("unchecked")
            Collection<Object> mutableFeatures = (Collection<Object>) registeredFeatures;
            mutableFeatures.removeIf(feature -> feature == null
                    || !STARGG$ALLOWED_FEATURES.contains(feature.getClass().getName()));

            @SuppressWarnings("unchecked")
            Map<Object, Object> featureCache = (Map<Object, Object>) rawFeatureCache;
            featureCache.clear();
            featureCache.putAll(newFeatureCache);

            @SuppressWarnings("unchecked")
            Map<Object, Object> categoryCache = (Map<Object, Object>) rawCategories;
            categoryCache.clear();
            for (Map.Entry<Object, List<Object>> entry : grouped.entrySet()) {
                categoryCache.put(entry.getKey(), Collections.unmodifiableList(entry.getValue()));
            }

            int retained = retainedFeatures.size();
            StarGG.LOGGER.info("Echo module filter retained {}/{} Ww.json modules ({} registered before filtering)",
                    retained, STARGG$ALLOWED_FEATURES.size(), registeredBeforeFiltering);
            if (retained != STARGG$ALLOWED_FEATURES.size()) {
                StarGG.LOGGER.error("Echo module filter expected {} original module classes but found {}. "
                                + "Check the embedded Echo runtime version.",
                        STARGG$ALLOWED_FEATURES.size(), retained);
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            StarGG.LOGGER.error("Could not filter the embedded Echo feature registry", exception);
        }
    }
}
