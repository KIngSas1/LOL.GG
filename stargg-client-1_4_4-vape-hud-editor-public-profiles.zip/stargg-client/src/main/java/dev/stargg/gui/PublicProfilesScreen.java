package dev.stargg.gui;

import dev.stargg.StarGG;
import dev.stargg.config.ConfigManager;
import dev.stargg.publicprofile.PublicProfile;
import dev.stargg.publicprofile.PublicProfileReview;
import dev.stargg.publicprofile.PublicProfileService;
import dev.stargg.publicprofile.PublicProfileSortMode;
import dev.stargg.publicprofile.PublicProfiles;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.function.Consumer;

/**
 * Public profiles, ported from the chat v4 public profile system: browse listed profiles (search, sort, tag
 * filter), open one to see its details and reviews, add it to your own profiles, rate and review it, and publish
 * one of your own profiles with a share code. Where the profiles are stored is decided by the
 * {@link PublicProfileService} in use.
 */
public final class PublicProfilesScreen extends Screen {

    private static final int PAD = 10;
    private static final int HEADER_H = 26;
    private static final int FIELD_H = 20;
    private static final int BTN_H = 20;
    private static final int CARD_H = 38;
    private static final int CARD_GAP = 3;
    private static final int FOOTER_H = 44;
    private static final int LIKE = 0xFF5CCB7A;
    private static final int DISLIKE = 0xFFE05A5A;

    private enum View { BROWSE, DETAILS, PUBLISH }

    /** A text input. */
    private static final class Field {
        final int max;
        final boolean code;
        String text = "";

        Field(int max, boolean code) {
            this.max = max;
            this.code = code;
        }

        boolean accepts(int cp) {
            if (cp < 32 || cp > 126 || text.length() >= max) {
                return false;
            }
            return !code || Character.isLetterOrDigit(cp);
        }

        void append(int cp) {
            if (accepts(cp)) {
                text += code ? String.valueOf((char) cp).toUpperCase(Locale.ROOT) : String.valueOf((char) cp);
            }
        }
    }

    private record Region(int x, int y, int w, int h, boolean enabled, Runnable action) {
    }

    private final PublicProfileService service = PublicProfiles.service();
    private final List<Region> regions = new ArrayList<>();
    private final List<Region> pending = new ArrayList<>();

    private View view = View.BROWSE;

    // browse
    private final Field search = new Field(24, false);
    private final Field code = new Field(8, true);
    private PublicProfileSortMode sort = PublicProfileSortMode.RATED;
    private final List<String> activeTags = new ArrayList<>();
    private List<String> allTags = List.of();
    private List<PublicProfile> results = List.of();
    private int listScroll;
    private boolean queryDirty = true;
    private long queryAt;
    private int queryToken;
    private int loading;

    // details
    private PublicProfile detail;
    private int detailScroll;
    private int detailContent;
    private final Field reviewField = new Field(200, false);
    private boolean reviewLiked = true;
    private long replyTarget = -1;
    private final Field replyField = new Field(200, false);

    // publish
    private List<String> sources = List.of();
    private int sourceIndex;
    private final Field pubName = new Field(32, false);
    private final Field pubDesc = new Field(120, false);
    private final Field pubTags = new Field(48, false);
    private boolean pubListed = true;
    private boolean pubAnonymous;

    private Field focus;
    private String status = "";
    private boolean statusError;
    private long statusUntil;
    private String armedKey = "";
    private long armedUntil;

    private int px;
    private int py;
    private int pw;
    private int ph;

    public PublicProfilesScreen() {
        super(Text.literal("Public Profiles"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    // ------------------------------------------------------------------ async

    private static String messageOf(Throwable error) {
        Throwable t = error instanceof CompletionException && error.getCause() != null ? error.getCause() : error;
        return t.getMessage() == null ? "Something went wrong" : t.getMessage();
    }

    private <T> void async(CompletableFuture<T> future, Consumer<T> onSuccess) {
        loading++;
        future.whenComplete((value, error) -> mc().execute(() -> {
            loading--;
            if (error != null) {
                flash(messageOf(error), true);
            } else {
                onSuccess.accept(value);
            }
        }));
    }

    private void refresh() {
        queryDirty = false;
        int token = ++queryToken;
        service.search(search.text, activeTags, sort).whenComplete((list, error) -> mc().execute(() -> {
            if (token != queryToken) {
                return;
            }
            if (error != null) {
                flash(messageOf(error), true);
                return;
            }
            results = list;
            listScroll = 0;
        }));
    }

    private void loadTags() {
        service.search("", null, PublicProfileSortMode.RATED).whenComplete((list, error) -> mc().execute(() -> {
            if (error != null) {
                return;
            }
            Map<String, Integer> counts = new HashMap<>();
            for (PublicProfile profile : list) {
                for (String tag : profile.tags) {
                    counts.merge(tag.toLowerCase(Locale.ROOT), 1, Integer::sum);
                }
            }
            List<String> tags = new ArrayList<>(counts.keySet());
            tags.sort((a, b) -> counts.get(b) - counts.get(a));
            allTags = tags.size() > 12 ? new ArrayList<>(tags.subList(0, 12)) : tags;
        }));
    }

    @Override
    protected void init() {
        loadTags();
    }

    private void flash(String message, boolean error) {
        status = message;
        statusError = error;
        statusUntil = System.currentTimeMillis() + 3000;
    }

    private boolean confirm(String key) {
        long now = System.currentTimeMillis();
        if (key.equals(armedKey) && now < armedUntil) {
            armedKey = "";
            return true;
        }
        armedKey = key;
        armedUntil = now + 3000;
        return false;
    }

    private boolean armed(String key) {
        return key.equals(armedKey) && System.currentTimeMillis() < armedUntil;
    }

    // ----------------------------------------------------------------- layout

    private void layout() {
        pw = Math.min(330, width - 8);
        ph = Math.min(300, height - 8);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        layout();
        pending.clear();
        if (queryDirty && System.currentTimeMillis() >= queryAt && view == View.BROWSE) {
            refresh();
        }

        Ui.roundRect(context, px, py, pw, ph, 5, Theme.bg(Theme.ROW));
        Ui.roundRect(context, px, py, pw, HEADER_H, 5, Theme.bg(Theme.HEADER));
        Draw.rect(context, px, py + HEADER_H - 5, pw, 5, Theme.bg(Theme.HEADER));

        switch (view) {
            case BROWSE -> renderBrowse(context, mouseX, mouseY);
            case DETAILS -> renderDetails(context, mouseX, mouseY);
            case PUBLISH -> renderPublish(context, mouseX, mouseY);
        }

        // header close / back (registered last so it wins over anything under it)
        int cx = px + pw - 22;
        boolean closeHover = Draw.inside(mouseX, mouseY, cx, py, 22, HEADER_H);
        Ui.icon(context, Ui.Tex.CLOSE, cx + 5, py + (HEADER_H - Ui.Tex.CLOSE.size) / 2, closeHover ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        pending.add(new Region(cx, py, 22, HEADER_H, true, this::close));

        regions.clear();
        regions.addAll(pending);
    }

    private void title(DrawContext context, String text, String sub) {
        Ui.icon(context, Ui.Tex.CAT_CLIENT, px + PAD, py + (HEADER_H - 10) / 2, Theme.accent());
        Ui.textBold(context, text, px + PAD + 15, Ui.middleY(py, HEADER_H), Theme.TEXT_BRIGHT);
        if (sub != null) {
            Ui.textRight(context, sub, px + pw - 28, py, HEADER_H, Theme.TEXT_FAINT);
        }
    }

    // ------------------------------------------------------------ drawing kit

    private void button(DrawContext context, int mouseX, int mouseY, String label, int x, int y, int w, int h,
                        boolean active, boolean enabled, Runnable action) {
        boolean hovered = enabled && Draw.inside(mouseX, mouseY, x, y, w, h);
        int fill = active ? Theme.accent() : (hovered ? Theme.ROW_HOVER : Theme.BADGE);
        int text = !enabled ? Theme.TEXT_FAINT : (active ? Theme.onAccent() : (hovered ? Theme.TEXT_BRIGHT : Theme.TEXT));
        Ui.roundRect(context, x, y, w, h, 3, fill);
        Ui.textCentered(context, Ui.trim(label, w - 6), x, y, w, h, text);
        pending.add(new Region(x, y, w, h, enabled, action));
    }

    private void field(DrawContext context, Field f, String hint, int x, int y, int w) {
        boolean focused = focus == f;
        Ui.roundRect(context, x, y, w, FIELD_H, 3, Theme.bg(Theme.SETTING_ROW));
        if (focused) {
            Draw.rect(context, x + 3, y + FIELD_H - 1, w - 6, 1, Theme.accent());
        }
        if (f.text.isEmpty() && !focused) {
            Ui.textMiddle(context, hint, x + 6, y, FIELD_H, Theme.TEXT_FAINT);
        } else {
            String shown = tail(f.text, w - 14);
            Ui.textMiddle(context, shown, x + 6, y, FIELD_H, Theme.TEXT_BRIGHT);
            if (focused && (System.currentTimeMillis() / 500) % 2 == 0) {
                Draw.rect(context, x + 6 + Ui.width(shown) + 1, y + 4, 1, FIELD_H - 8, Theme.TEXT_BRIGHT);
            }
        }
        pending.add(new Region(x, y, w, FIELD_H, true, () -> focus = f));
    }

    /** The end of a text that fits into maxWidth (so the cursor stays visible). */
    private static String tail(String text, int maxWidth) {
        String s = text;
        while (s.length() > 1 && Ui.width(s) > maxWidth) {
            s = s.substring(1);
        }
        return s;
    }

    private static List<String> wrap(String text, int maxWidth) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (Ui.width(candidate) > maxWidth && !line.isEmpty()) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (!line.isEmpty()) {
            lines.add(line.toString());
        }
        return lines;
    }

    private static String ago(long millis) {
        long seconds = Math.max(0, (System.currentTimeMillis() - millis) / 1000);
        if (seconds < 60) {
            return "just now";
        }
        if (seconds < 3600) {
            return seconds / 60 + "m ago";
        }
        if (seconds < 86400) {
            return seconds / 3600 + "h ago";
        }
        return seconds / 86400 + "d ago";
    }

    private void renderStatus(DrawContext context, int y) {
        if (System.currentTimeMillis() > statusUntil || status.isEmpty()) {
            if (loading > 0) {
                Ui.textCentered(context, "Loading...", px, y, pw, 12, Theme.TEXT_FAINT);
            }
            return;
        }
        Ui.textCentered(context, Ui.trim(status, pw - PAD * 2), px, y, pw, 12, statusError ? DISLIKE : Theme.TEXT);
    }

    // ----------------------------------------------------------------- browse

    private void renderBrowse(DrawContext context, int mouseX, int mouseY) {
        title(context, "Public Profiles", service.backendName());
        int x = px + PAD;
        int iw = pw - PAD * 2;
        int y = py + HEADER_H + 6;

        // search + publish
        int publishW = 70;
        field(context, search, "Search name, owner or tag...", x, y, iw - publishW - 4);
        button(context, mouseX, mouseY, "Publish", x + iw - publishW, y, publishW, FIELD_H, false, true, this::openPublish);
        y += FIELD_H + 4;

        // sort
        int gap = 4;
        int sw = (iw - gap * 2) / 3;
        PublicProfileSortMode[] modes = PublicProfileSortMode.values();
        for (int i = 0; i < modes.length; i++) {
            PublicProfileSortMode mode = modes[i];
            int bw = i == modes.length - 1 ? iw - (sw + gap) * 2 : sw;
            button(context, mouseX, mouseY, mode.displayName(), x + i * (sw + gap), y, bw, 18, sort == mode, true, () -> {
                sort = mode;
                queryDirty = true;
                queryAt = 0;
            });
        }
        y += 18 + 4;

        // tag chips
        int chipX = x;
        for (String tag : allTags) {
            int cw = Ui.width(tag) + 12;
            if (chipX + cw > x + iw) {
                break;
            }
            boolean on = activeTags.stream().anyMatch(t -> t.equalsIgnoreCase(tag));
            button(context, mouseX, mouseY, tag, chipX, y, cw, 14, on, true, () -> {
                if (!activeTags.removeIf(t -> t.equalsIgnoreCase(tag))) {
                    activeTags.add(tag);
                }
                queryDirty = true;
                queryAt = 0;
            });
            chipX += cw + 3;
        }
        if (!allTags.isEmpty()) {
            y += 14 + 4;
        }

        // list
        int listTop = y;
        int listBottom = py + ph - FOOTER_H;
        int rows = Math.max(1, (listBottom - listTop + CARD_GAP) / (CARD_H + CARD_GAP));
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, results.size() - rows)));
        if (results.isEmpty()) {
            Ui.textCentered(context, loading > 0 ? "Loading..." : "No public profiles found", px, listTop, pw, 24, Theme.TEXT_FAINT);
            Ui.textCentered(context, "Use Publish to share one of yours", px, listTop + 14, pw, 24, Theme.TEXT_FAINT);
        }
        for (int i = 0; i < rows && listScroll + i < results.size(); i++) {
            PublicProfile profile = results.get(listScroll + i);
            int cy = listTop + i * (CARD_H + CARD_GAP);
            boolean hovered = Draw.inside(mouseX, mouseY, x, cy, iw, CARD_H);
            Ui.roundRect(context, x, cy, iw, CARD_H, 3, Theme.bg(hovered ? Theme.ROW_HOVER : Theme.SETTING_ROW));
            String votes = "+" + profile.likes + "  -" + profile.dislikes;
            int voteW = Ui.width(votes);
            Ui.textBold(context, Ui.trim(profile.name, iw - voteW - PAD * 2 - 6), x + 8, cy + 2, Theme.TEXT_BRIGHT);
            Ui.textRight(context, votes, x + iw - 8, cy + 2, 12, profile.likes >= profile.dislikes ? LIKE : DISLIKE);
            Ui.textMiddle(context, Ui.trim("by " + profile.ownerDisplay() + "  -  v" + profile.version + "  -  "
                    + profile.downloads + " downloads", iw - 16), x + 8, cy + 14, 12, Theme.TEXT_DIM);
            String tags = profile.tags.isEmpty() ? "no tags" : String.join(", ", profile.tags);
            Ui.textMiddle(context, Ui.trim(tags, iw - 16), x + 8, cy + 25, 12, Theme.TEXT_FAINT);
            pending.add(new Region(x, cy, iw, CARD_H, true, () -> openDetails(profile.id)));
        }
        if (results.size() > rows) {
            int trackH = listBottom - listTop;
            int thumbH = Math.max(12, trackH * rows / results.size());
            int thumbY = listTop + (trackH - thumbH) * listScroll / Math.max(1, results.size() - rows);
            Draw.rect(context, x + iw + 3, thumbY, 2, thumbH, Draw.withAlpha(Theme.accent(), 0x80));
        }

        // footer: import by share code
        int fy = py + ph - FOOTER_H;
        renderStatus(context, fy + 2);
        int importW = 70;
        field(context, code, "Share code...", x, fy + 18, iw - importW - 4);
        button(context, mouseX, mouseY, "Import", x + iw - importW, fy + 18, importW, FIELD_H, false, !code.text.isEmpty(), this::importByCode);
    }

    private void importByCode() {
        String wanted = code.text.trim();
        async(service.findByShareCode(wanted), profile -> {
            if (profile == null) {
                flash("No profile with the code " + wanted, true);
            } else {
                code.text = "";
                focus = null;
                openDetails(profile.id);
            }
        });
    }

    // ---------------------------------------------------------------- details

    private void openDetails(long id) {
        async(service.get(id), profile -> {
            detail = profile;
            detailScroll = 0;
            replyTarget = -1;
            reviewField.text = "";
            replyField.text = "";
            focus = null;
            // pre-fill the viewer's own review
            for (PublicProfileReview review : profile.reviews) {
                if (service.viewerName().equalsIgnoreCase(review.author)) {
                    reviewField.text = review.message == null ? "" : review.message;
                    reviewLiked = review.liked;
                }
            }
            view = View.DETAILS;
        });
    }

    private boolean isOwner(PublicProfile profile) {
        return profile.ownerKey != null && profile.ownerKey.equalsIgnoreCase(service.viewerName());
    }

    private void backToBrowse() {
        view = View.BROWSE;
        focus = null;
        queryDirty = true;
        queryAt = 0;
        loadTags();
    }

    private void renderDetails(DrawContext context, int mouseX, int mouseY) {
        PublicProfile p = detail;
        title(context, Ui.trim(p.name, pw - 150), "v" + p.version);
        int x = px + PAD;
        int iw = pw - PAD * 2;

        int bodyTop = py + HEADER_H + 4;
        int bodyBottom = py + ph - 20;
        button(context, mouseX, mouseY, "< Back", x, bodyTop, 56, 18, false, true, this::backToBrowse);
        bodyTop += 22;
        renderStatus(context, py + ph - 16);

        context.enableScissor(px, bodyTop, px + pw, bodyBottom);
        int y = bodyTop - detailScroll;
        int top = y;

        Ui.textMiddle(context, "by " + p.ownerDisplay() + "  -  " + p.downloads + " downloads  -  updated " + ago(p.updatedMillis),
                x, y, 12, Theme.TEXT_DIM);
        y += 14;
        Ui.textMiddle(context, p.tags.isEmpty() ? "No tags" : "Tags: " + String.join(", ", p.tags), x, y, 12, Theme.TEXT_FAINT);
        y += 16;
        if (!p.description.isBlank()) {
            for (String line : wrap(p.description, iw)) {
                Ui.textMiddle(context, line, x, y, 12, Theme.TEXT);
                y += 12;
            }
            y += 4;
        }
        Ui.textBold(context, "+" + p.likes, x, y + 2, LIKE);
        Ui.textBold(context, "-" + p.dislikes, x + 40, y + 2, DISLIKE);
        y += 18;

        // share code
        Ui.textMiddle(context, "Share code", x, y, BTN_H, Theme.TEXT_DIM);
        Ui.textBold(context, p.shareCodeUpper(), x + 62, Ui.middleY(y, BTN_H), Theme.TEXT_BRIGHT);
        button(context, mouseX, mouseY, "Copy", x + iw - 56, y, 56, BTN_H, false, true, () -> clip(p));
        y += BTN_H + 6;

        // actions
        int half = (iw - 4) / 2;
        button(context, mouseX, mouseY, "Add to profiles", x, y, half, BTN_H, false, true, () -> use(p, false));
        button(context, mouseX, mouseY, "Add and load", x + half + 4, y, iw - half - 4, BTN_H, true, true, () -> use(p, true));
        y += BTN_H + 4;
        if (isOwner(p)) {
            int third = (iw - 8) / 3;
            button(context, mouseX, mouseY, "Update data", x, y, third, BTN_H, false, true, () -> updateFromCurrent(p));
            button(context, mouseX, mouseY, p.listedPublicly ? "Unlist" : "List", x + third + 4, y, third, BTN_H, false, true,
                    () -> async(service.setListing(p.id, !p.listedPublicly), updated -> {
                        detail = updated;
                        flash(updated.listedPublicly ? "Listed publicly" : "Hidden from the public list", false);
                    }));
            button(context, mouseX, mouseY, armed("unpublish") ? "Sure?" : "Delete", x + (third + 4) * 2, y, iw - (third + 4) * 2, BTN_H,
                    armed("unpublish"), true, () -> {
                        if (confirm("unpublish")) {
                            async(service.unpublish(p.id), ignored -> {
                                flash("Profile removed", false);
                                backToBrowse();
                            });
                        }
                    });
            y += BTN_H + 4;
        }
        y += 6;

        // reviews
        Ui.textBold(context, "Reviews (" + p.reviews.size() + ")", x, y + 2, Theme.TEXT_BRIGHT);
        y += 16;
        if (!isOwner(p)) {
            int lw = 60;
            button(context, mouseX, mouseY, "Like", x, y, lw, 18, reviewLiked, true, () -> reviewLiked = true);
            button(context, mouseX, mouseY, "Dislike", x + lw + 4, y, lw + 8, 18, !reviewLiked, true, () -> reviewLiked = false);
            y += 22;
            int postW = 56;
            field(context, reviewField, "Write a review (optional)...", x, y, iw - postW - 4);
            button(context, mouseX, mouseY, "Post", x + iw - postW, y, postW, FIELD_H, true, true, () -> postReview(p));
            y += FIELD_H + 8;
        }
        if (p.reviews.isEmpty()) {
            Ui.textMiddle(context, "No reviews yet", x, y, 14, Theme.TEXT_FAINT);
            y += 16;
        }
        for (PublicProfileReview review : p.reviews) {
            Ui.textBold(context, review.author, x, y + 1, Theme.TEXT);
            String verdict = review.liked ? "Liked" : "Disliked";
            Ui.textMiddle(context, verdict + "  -  v" + review.version + "  -  " + ago(review.createdMillis),
                    x + Ui.widthBold(review.author) + 8, y, 12, review.liked ? LIKE : DISLIKE);
            y += 13;
            if (review.message != null && !review.message.isBlank()) {
                for (String line : wrap(review.message, iw - 6)) {
                    Ui.textMiddle(context, line, x + 6, y, 12, Theme.TEXT_DIM);
                    y += 12;
                }
            }
            if (review.reply != null && !review.reply.isBlank()) {
                Draw.rect(context, x + 6, y, 1, 12 * wrap(review.reply, iw - 22).size(), Theme.accent());
                for (String line : wrap(review.reply, iw - 22)) {
                    Ui.textMiddle(context, line, x + 12, y, 12, Theme.TEXT);
                    y += 12;
                }
            }
            boolean mine = service.viewerName().equalsIgnoreCase(review.author);
            if (isOwner(p) || mine) {
                int bx = x + 6;
                if (isOwner(p)) {
                    button(context, mouseX, mouseY, "Reply", bx, y + 1, 44, 14, replyTarget == review.id, true, () -> {
                        replyTarget = replyTarget == review.id ? -1 : review.id;
                        replyField.text = review.reply == null ? "" : review.reply;
                        focus = replyTarget == -1 ? null : replyField;
                    });
                    bx += 48;
                }
                button(context, mouseX, mouseY, "Delete", bx, y + 1, 44, 14, false, true,
                        () -> async(service.deleteReview(p.id, review.id), updated -> detail = updated));
                y += 18;
            }
            if (replyTarget == review.id) {
                int sendW = 56;
                field(context, replyField, "Reply...", x + 6, y, iw - sendW - 10);
                button(context, mouseX, mouseY, "Send", x + iw - sendW, y, sendW, FIELD_H, true, true, () -> sendReply(p, review.id));
                y += FIELD_H + 4;
            }
            y += 6;
        }
        detailContent = y - top;
        context.disableScissor();

        // regions registered inside the body must not react outside of it
        clipRegions(bodyTop, bodyBottom);
    }

    /** Drops the part of the regions that lies outside of [top, bottom) so hidden controls cannot be clicked. */
    private void clipRegions(int top, int bottom) {
        for (int i = 0; i < pending.size(); i++) {
            Region r = pending.get(i);
            if (r.y() >= py + HEADER_H && r.y() + r.h() > bottom || r.y() < top && r.y() > py + HEADER_H + 24) {
                int ny = Math.max(r.y(), top);
                int nb = Math.min(r.y() + r.h(), bottom);
                pending.set(i, new Region(r.x(), ny, r.w(), Math.max(0, nb - ny), r.enabled(), r.action()));
            }
        }
    }

    private void clip(PublicProfile p) {
        mc().keyboard.setClipboard(p.shareCodeUpper());
        flash("Share code copied", false);
    }

    private void postReview(PublicProfile p) {
        async(service.review(p.id, reviewLiked, reviewField.text), updated -> {
            detail = updated;
            flash("Review saved", false);
        });
    }

    private void sendReply(PublicProfile p, long reviewId) {
        async(service.reply(p.id, reviewId, replyField.text), updated -> {
            detail = updated;
            replyTarget = -1;
            focus = null;
            flash("Reply saved", false);
        });
    }

    private void updateFromCurrent(PublicProfile p) {
        String data = StarGG.config().exportCurrent();
        async(service.update(p.id, data), updated -> {
            detail = updated;
            flash("Updated to your current settings (v" + updated.version + ")", false);
        });
    }

    private static String sanitizeName(String name) {
        String s = name.replaceAll("[^a-zA-Z0-9_\\- ]", "").trim();
        if (s.length() > ConfigManager.MAX_NAME_LENGTH) {
            s = s.substring(0, ConfigManager.MAX_NAME_LENGTH).trim();
        }
        return s.isEmpty() ? "Public" : s;
    }

    private void use(PublicProfile p, boolean load) {
        ConfigManager config = StarGG.config();
        String base = sanitizeName(p.name);
        String name = base;
        int n = 2;
        while (config.profileExists(name) || ConfigManager.DEFAULT_PROFILE.equalsIgnoreCase(name) || !ConfigManager.isValidName(name)) {
            String suffix = " " + n++;
            name = (base.length() + suffix.length() > ConfigManager.MAX_NAME_LENGTH
                    ? base.substring(0, ConfigManager.MAX_NAME_LENGTH - suffix.length()) : base) + suffix;
            if (n > 200) {
                flash("Could not find a free profile name", true);
                return;
            }
        }
        if (!config.importProfile(name, p.data)) {
            flash("That profile could not be imported", true);
            return;
        }
        final String added = name;
        async(service.recordDownload(p.id), updated -> {
            detail = updated;
            if (load && config.loadProfile(added)) {
                flash("Added and loaded " + added, false);
            } else {
                flash("Added as " + added, false);
            }
        });
    }

    // ---------------------------------------------------------------- publish

    private void openPublish() {
        sources = new ArrayList<>();
        sources.add("Current settings");
        for (String name : StarGG.config().listProfiles()) {
            if (!ConfigManager.DEFAULT_PROFILE.equalsIgnoreCase(name)) {
                sources.add(name);
            }
        }
        sourceIndex = 0;
        String active = StarGG.config().getActiveProfile();
        int found = sources.indexOf(active);
        if (found > 0) {
            sourceIndex = found;
        }
        pubName.text = sourceIndex == 0 ? "" : sources.get(sourceIndex);
        pubDesc.text = "";
        pubTags.text = "";
        pubListed = true;
        pubAnonymous = false;
        focus = null;
        view = View.PUBLISH;
    }

    private void renderPublish(DrawContext context, int mouseX, int mouseY) {
        title(context, "Publish a profile", service.backendName());
        int x = px + PAD;
        int iw = pw - PAD * 2;
        int y = py + HEADER_H + 8;

        Ui.textMiddle(context, "Source", x, y, BTN_H, Theme.TEXT_DIM);
        int arrow = 22;
        button(context, mouseX, mouseY, "<", x + 50, y, arrow, BTN_H, false, sources.size() > 1, () -> cycleSource(-1));
        Ui.roundRect(context, x + 50 + arrow + 2, y, iw - 50 - arrow * 2 - 4, BTN_H, 3, Theme.bg(Theme.SETTING_ROW));
        Ui.textCentered(context, Ui.trim(sources.get(sourceIndex), iw - 50 - arrow * 2 - 12), x + 50 + arrow + 2, y,
                iw - 50 - arrow * 2 - 4, BTN_H, Theme.TEXT_BRIGHT);
        button(context, mouseX, mouseY, ">", x + iw - arrow, y, arrow, BTN_H, false, sources.size() > 1, () -> cycleSource(1));
        y += BTN_H + 8;

        Ui.textMiddle(context, "Name", x, y, 12, Theme.TEXT_DIM);
        y += 13;
        field(context, pubName, "Name shown in the list...", x, y, iw);
        y += FIELD_H + 6;
        Ui.textMiddle(context, "Description", x, y, 12, Theme.TEXT_DIM);
        y += 13;
        field(context, pubDesc, "What is this profile for?", x, y, iw);
        y += FIELD_H + 6;
        Ui.textMiddle(context, "Tags (separate with commas)", x, y, 12, Theme.TEXT_DIM);
        y += 13;
        field(context, pubTags, "pvp, legit, 1.8 ...", x, y, iw);
        y += FIELD_H + 8;

        int half = (iw - 4) / 2;
        button(context, mouseX, mouseY, pubListed ? "Listed publicly: on" : "Listed publicly: off", x, y, half, BTN_H, pubListed, true,
                () -> pubListed = !pubListed);
        button(context, mouseX, mouseY, pubAnonymous ? "Hide my name: on" : "Hide my name: off", x + half + 4, y, iw - half - 4, BTN_H,
                pubAnonymous, true, () -> pubAnonymous = !pubAnonymous);
        y += BTN_H + 4;
        Ui.textCentered(context, pubListed ? "Everyone can find it. You also get a share code." : "Only people with the share code can open it.",
                px, y, pw, 12, Theme.TEXT_FAINT);

        renderStatus(context, py + ph - FOOTER_H + 4);
        int by = py + ph - 30;
        button(context, mouseX, mouseY, "Cancel", x, by, half, BTN_H, false, true, this::backToBrowse);
        button(context, mouseX, mouseY, "Publish", x + half + 4, by, iw - half - 4, BTN_H, true, !pubName.text.isBlank(), this::submitPublish);
    }

    private void cycleSource(int step) {
        sourceIndex = (sourceIndex + step + sources.size()) % sources.size();
        pubName.text = sourceIndex == 0 ? pubName.text : sources.get(sourceIndex);
    }

    private void submitPublish() {
        ConfigManager config = StarGG.config();
        String data = sourceIndex == 0 ? config.exportCurrent() : config.exportProfile(sources.get(sourceIndex));
        if (data == null) {
            flash("That profile could not be read", true);
            return;
        }
        List<String> tags = new ArrayList<>();
        for (String raw : pubTags.text.split(",")) {
            String tag = raw.trim().toLowerCase(Locale.ROOT);
            if (!tag.isEmpty() && tag.length() <= 16 && tags.stream().noneMatch(tag::equals) && tags.size() < 6) {
                tags.add(tag);
            }
        }
        async(service.publish(pubName.text.trim(), pubDesc.text.trim(), tags, data, pubListed, pubAnonymous), published -> {
            flash("Published. Share code: " + published.shareCodeUpper(), false);
            detail = published;
            detailScroll = 0;
            replyTarget = -1;
            view = View.DETAILS;
            loadTags();
        });
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            Field before = focus;
            focus = null;
            for (int i = regions.size() - 1; i >= 0; i--) {
                Region r = regions.get(i);
                if (r.h() > 0 && Draw.inside(click.x(), click.y(), r.x(), r.y(), r.w(), r.h())) {
                    if (r.enabled()) {
                        r.action().run();
                    } else {
                        focus = before;
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int step = (int) Math.signum(verticalAmount);
        if (view == View.BROWSE) {
            listScroll = Math.max(0, Math.min(listScroll - step, Math.max(0, results.size() - 1)));
        } else if (view == View.DETAILS) {
            int viewport = ph - HEADER_H - 46;
            detailScroll = Math.max(0, Math.min(detailScroll - step * 14, Math.max(0, detailContent - viewport)));
        }
        return true;
    }

    @Override
    public boolean charTyped(CharInput charInput) {
        if (focus == null) {
            return super.charTyped(charInput);
        }
        focus.append(charInput.codepoint());
        if (focus == search) {
            queryDirty = true;
            queryAt = System.currentTimeMillis() + 250;
        }
        return true;
    }

    private static boolean controlDown() {
        long window = mc().getWindow().getHandle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SUPER) == GLFW.GLFW_PRESS;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (focus != null) {
            Field f = focus;
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                focus = null;
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                if (f == code && !code.text.isEmpty()) {
                    importByCode();
                } else if (f == reviewField && detail != null) {
                    postReview(detail);
                } else if (f == replyField && detail != null && replyTarget != -1) {
                    sendReply(detail, replyTarget);
                }
                focus = null;
            } else if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!f.text.isEmpty()) {
                    f.text = f.text.substring(0, f.text.length() - 1);
                    if (f == search) {
                        queryDirty = true;
                        queryAt = System.currentTimeMillis() + 250;
                    }
                }
            } else if (key == GLFW.GLFW_KEY_V && controlDown()) {
                String clip = mc().keyboard.getClipboard();
                if (clip != null) {
                    clip.codePoints().forEach(f::append);
                    if (f == search) {
                        queryDirty = true;
                        queryAt = System.currentTimeMillis() + 250;
                    }
                }
            }
            return true; // typing must not trigger anything else
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (view != View.BROWSE) {
                backToBrowse();
            } else {
                close();
            }
            return true;
        }
        return super.keyPressed(input);
    }

    /** Closing goes back to the profiles screen this one is opened from. */
    @Override
    public void close() {
        mc().setScreen(new ProfilesScreen());
    }
}
