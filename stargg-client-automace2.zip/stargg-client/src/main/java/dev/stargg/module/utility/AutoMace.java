package dev.stargg.module.utility;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.setting.ModeSetting;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.setting.NumberSetting;
import dev.stargg.util.Icon;
import dev.stargg.util.FriendManager;
import dev.stargg.util.TargetFilters;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;

/** Cyemer-style automatic mace sequence, adapted to StarGG's module and rotation systems. */
public final class AutoMace extends Module {

    private static final String[] TARGET_OPTIONS = {
            "Players", "Mobs", "Peaceful", "Neutral", "Ignore naked", "Ignore invisible", "Ignore behind walls"
    };

    private final NumberSetting swingRange = add(new NumberSetting("Swing Range", 3.0, 2.5, 3.0, 0.1));
    private final NumberSetting aimRange = add(new NumberSetting("Aim Range", 15.0, 0.0, 15.0, 0.1));
    private final NumberSetting aimInAir = add(new NumberSetting("Aim In Air", 4.5, 0.0, 15.0, 0.1));
    private final BooleanSetting autoSwitch = add(new BooleanSetting("Auto Switch", true));
    private final BooleanSetting swapBack = add(new BooleanSetting("Swap Back", true));
    private final NumberSetting rotationSpeed = add(new NumberSetting("Aim Speed", 24.0, 0.0, 35.0, 0.5));
    /** 0 = only the speed cap limits the turn; higher values ease into the target with a gentler, curved approach. */
    private final NumberSetting aimSmoothing = add(new NumberSetting("Aim Smoothing", 0.5, 0.0, 0.95, 0.05));
    private final NumberSetting minFallDist = add(new NumberSetting("Min Fall Dist", 1.5, 0.0, 5.0, 0.1));
    private final NumberSetting cooldown = add(new NumberSetting("Cooldown (ms)", 500.0, 100.0, 2000.0, 10.0));
    private final NumberSetting maceSwapDelay = add(new NumberSetting("Mace Swap Delay (ms)", 1.0, 0.0, 100.0, 1.0));
    private final BooleanSetting stunSlam = add(new BooleanSetting("Stun Slam", true));
    private final BooleanSetting weaponOnly = add(new BooleanSetting("Weapon Only", false));
    private final ModeSetting aimMode = add(new ModeSetting("Aim Mode", "Strict", "Strict", "Loose", "Horizontal"));
    private final ModeSetting stopAim = add(new ModeSetting("Stop Aim", "Hitbox Edge", "Hitbox Edge", "Exact Center"));
    private final NumberSetting hitboxAccuracy = add(new NumberSetting("Hitbox Accuracy", 0.3, 0.0, 1.0, 0.05));
    private final BooleanSetting ignoreFriends = add(new BooleanSetting("Ignore Friends", true));
    /** Closest: nearest in range. FOV: best target inside a view cone. Straight: only what the crosshair points at. */
    private final ModeSetting targetMode = add(new ModeSetting("Target Mode", "Closest", "Closest", "FOV", "Straight"));
    private final NumberSetting targetFov = add(new NumberSetting("FOV", 90.0, 10.0, 360.0, 5.0));
    private final MultiSelectSetting targetFilter = add(new MultiSelectSetting("Target settings", TARGET_OPTIONS, "Players"));

    /** Smallest turn per tick (degrees) so the ease-out never stalls just short of the target. */
    private static final float MIN_AIM_STEP = 0.4F;
    /** Extra hitbox margin for the Straight target mode so a slightly off-centre crosshair still counts. */
    private static final double STRAIGHT_MARGIN = 0.3;

    private LivingEntity currentTarget;
    private int maceClicksLeft;
    private int originalSlot = -1;
    private int preSequenceSlot = -1;
    private long lastComboTime;
    private long axeHitTime;
    private int resetTimer;
    private double highestY;
    private boolean shouldAttackThisTick;
    private boolean shouldBreakShield;
    private boolean shouldMaceSmash;
    private int targetSlotForAttack = -1;
    private boolean executingAttack;
    private float assistedYaw;
    private float assistedPitch;
    private boolean rotationInitialized;

    public AutoMace() {
        super("AutoMace", "Automatically aims, swaps and performs mace smash sequences", Category.COMBAT);
        icon(Icon.AUTO_MACE);
        aimInAir.showWhen(() -> aimMode.is("Horizontal"));
        hitboxAccuracy.showWhen(() -> stopAim.is("Hitbox Edge"));
        targetFov.showWhen(() -> targetMode.is("FOV"));
    }

    @Override
    protected void onEnable() {
        // AutoMace 2.0 drives the same attack sequence, so only one of the two may run at a time.
        AutoMace2 upgraded = dev.stargg.StarGG.modules().get(AutoMace2.class);
        if (upgraded != null && upgraded.isEnabled()) upgraded.setEnabled(false);
        highestY = mc.player == null ? 0.0 : mc.player.getY();
        resetSequence();
        lastComboTime = 0L;
        rotationInitialized = false;
    }

    @Override
    protected void onDisable() {
        restorePreSequenceSlot();
        resetSequence();
        rotationInitialized = false;
    }

    /** Used by ModuleManager to avoid re-intercepting this module's own follow-up attack. */
    public boolean isExecutingAttack() {
        return executingAttack;
    }

    /**
     * Reports whether this module can currently perform its axe-then-mace shield-break sequence.
     * Triggerbot uses this to decide whether its shield check may be bypassed for this target.
     */
    public boolean canBreakShield(PlayerEntity target) {
        if (!isEnabled() || !stunSlam.on() || !autoSwitch.on()
                || mc.player == null || mc.world == null || target == null
                || !target.isAlive() || !target.isBlocking()) {
            return false;
        }
        if (!isValidTarget(target) || !isWithinTrackingRange(target)
                || (weaponOnly.on() && !isHoldingWeapon())) {
            return false;
        }
        if (findAxe() < 0 || findBestMace() < 0) {
            return false;
        }
        double manualFallDistance = Math.max(0.0, highestY - mc.player.getY());
        return mc.player.fallDistance >= minFallDist.getFloat()
                || manualFallDistance >= minFallDist.getDouble()
                || minFallDist.getDouble() <= 0.1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            abortSequence();
            return;
        }

        if (isInLiquidOrWeb()) {
            clearAim();
            return;
        }

        updateFallTracking();
        processPreparedAction();

        boolean isHoldingMace = mc.player.getMainHandStack().isOf(Items.MACE);
        int bestMace = findBestMace();
        boolean canUseMace = isHoldingMace || (autoSwitch.on() && bestMace >= 0);
        boolean horizontalWeaponAim = aimMode.is("Horizontal") && weaponOnly.on()
                && isInAirForHorizontalAssist() && isHoldingWeapon();

        if ((!canUseMace && !horizontalWeaponAim) || (weaponOnly.on() && !isHoldingWeapon())) {
            clearAim();
            return;
        }

        if (resetTimer > 0) {
            handleResetSequence();
            return;
        }
        if (maceClicksLeft > 0) {
            calculateMaceLogic();
            processPreparedAction();
            return;
        }
        if (System.currentTimeMillis() - lastComboTime < (long) cooldown.getDouble()) {
            clearAim();
            return;
        }

        currentTarget = findTarget();
        if (currentTarget == null || (aimMode.is("Horizontal") && !isTargetInHorizontalFov(currentTarget))) {
            clearAim();
            return;
        }

        double manualFallDistance = Math.max(0.0, highestY - mc.player.getY());
        boolean falling = mc.player.fallDistance >= minFallDist.getFloat()
                || manualFallDistance >= minFallDist.getDouble();
        if (!falling && minFallDist.getDouble() > 0.1) {
            clearAim();
            return;
        }

        AutoElytra autoElytra = dev.stargg.StarGG.modules().get(AutoElytra.class);
        if (autoElytra != null && autoElytra.isEnabled()) {
            // Speed-aware: while flying the swap has to start many blocks before the target is in reach.
            double preparationRange = Math.max(swingRange.getDouble() + 0.4,
                    autoElytra.getEffectivePreHitRange(currentTarget));
            if (mc.player.distanceTo(currentTarget) <= preparationRange) {
                autoElytra.onAutoMaceSync();
            }
        }

        if (shouldRotate()) {
            applyAimRotation(getAimPos(currentTarget));
        }

        if (stunSlam.on() && currentTarget.isBlocking()) {
            calculateStunSlam();
        } else {
            calculateDirectMaceLogic();
        }
        // Attack in the same tick. Waiting for the next tick lets a diving or gliding player move several blocks
        // and fall out of reach before the prepared attack is executed.
        processPreparedAction();
    }

    private boolean isInLiquidOrWeb() {
        if (mc.player == null || mc.world == null) return false;
        if (mc.player.isTouchingWater() || mc.player.isInLava() || mc.player.isClimbing()) return true;
        Box box = mc.player.getBoundingBox();
        int minX = MathHelper.floor(box.minX);
        int minY = MathHelper.floor(box.minY);
        int minZ = MathHelper.floor(box.minZ);
        int maxX = MathHelper.floor(box.maxX);
        int maxY = MathHelper.floor(box.maxY);
        int maxZ = MathHelper.floor(box.maxZ);
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (mc.world.getBlockState(new net.minecraft.util.math.BlockPos(x, y, z))
                            .isOf(net.minecraft.block.Blocks.COBWEB)) return true;
                }
            }
        }
        return false;
    }

    private void updateFallTracking() {
        if (mc.player.isOnGround()) {
            highestY = mc.player.getY();
        } else {
            highestY = Math.max(highestY, mc.player.getY());
        }
    }

    private void processPreparedAction() {
        if (shouldBreakShield) {
            executeShieldBreak();
        } else if (shouldMaceSmash) {
            executeMaceSmash();
        } else if (shouldAttackThisTick) {
            executeAttack();
        }
    }

    private void calculateStunSlam() {
        if (!isWithinTrackingRange(currentTarget)) {
            clearAim();
            return;
        }
        int axeSlot = findAxe();
        int maceSlot = findBestMace();
        if (axeSlot < 0 || maceSlot < 0 || !canExecuteAttack(currentTarget)) {
            return;
        }
        if (preSequenceSlot < 0) {
            preSequenceSlot = mc.player.getInventory().getSelectedSlot();
        }
        shouldBreakShield = true;
        targetSlotForAttack = axeSlot;
        originalSlot = maceSlot;
    }

    private void executeShieldBreak() {
        if (currentTarget == null || !canExecuteAttack(currentTarget) || !syncToAttackSlot()) {
            return;
        }
        if (performAttack(currentTarget)) {
            maceClicksLeft = 1;
            axeHitTime = System.currentTimeMillis();
            shouldBreakShield = false;
        } else {
            restorePreSequenceSlot();
            resetSequence();
        }
    }

    private void calculateMaceLogic() {
        if (currentTarget == null || !currentTarget.isAlive() || !isWithinTrackingRange(currentTarget)) {
            restorePreSequenceSlot();
            resetSequence();
            clearAim();
            return;
        }
        if (shouldRotate()) {
            applyAimRotation(getAimPos(currentTarget));
        }
        long sinceAxe = System.currentTimeMillis() - axeHitTime;
        if (sinceAxe < (long) maceSwapDelay.getDouble()) {
            return;
        }
        if (sinceAxe > 1500L) {
            restorePreSequenceSlot();
            resetSequence();
            clearAim();
            return;
        }
        if (canExecuteAttack(currentTarget)) {
            shouldMaceSmash = true;
            targetSlotForAttack = originalSlot;
        }
    }

    private void executeMaceSmash() {
        if (currentTarget == null || !canExecuteAttack(currentTarget) || !syncToAttackSlot()) {
            return;
        }
        if (performAttack(currentTarget)) {
            AutoElytra.notifyMaceHit();
            maceClicksLeft = 0;
            shouldMaceSmash = false;
            resetTimer = 8;
            lastComboTime = System.currentTimeMillis();
        } else {
            restorePreSequenceSlot();
            resetSequence();
        }
    }

    private void calculateDirectMaceLogic() {
        if (currentTarget == null || !currentTarget.isAlive() || !isWithinTrackingRange(currentTarget)) {
            clearAim();
            return;
        }
        int maceSlot = findBestMace();
        if (maceSlot < 0) {
            return;
        }
        if (shouldRotate()) {
            applyAimRotation(getAimPos(currentTarget));
        }
        if (canExecuteAttack(currentTarget)) {
            if (preSequenceSlot < 0) {
                preSequenceSlot = mc.player.getInventory().getSelectedSlot();
            }
            shouldAttackThisTick = true;
            targetSlotForAttack = maceSlot;
        }
    }

    private void executeAttack() {
        if (currentTarget == null || !canExecuteAttack(currentTarget) || !syncToAttackSlot()) {
            return;
        }
        if (performAttack(currentTarget)) {
            AutoElytra.notifyMaceHit();
            shouldAttackThisTick = false;
            lastComboTime = System.currentTimeMillis();
            resetTimer = 5;
        } else {
            restorePreSequenceSlot();
            resetSequence();
        }
    }

    private boolean performAttack(LivingEntity target) {
        if (mc.player == null || mc.interactionManager == null || target == null || !target.isAlive()) {
            return false;
        }
        executingAttack = true;
        try {
            mc.interactionManager.attackEntity(mc.player, target);
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        } finally {
            executingAttack = false;
        }
    }

    private void handleResetSequence() {
        resetTimer--;
        if (currentTarget != null && currentTarget.isAlive() && isWithinTrackingRange(currentTarget) && shouldRotate()) {
            applyAimRotation(getAimPos(currentTarget));
        }
        if (resetTimer <= 0) {
            restorePreSequenceSlot();
            clearAim();
        }
    }

    private boolean syncToAttackSlot() {
        if (mc.player == null) return false;
        if (autoSwitch.on() && targetSlotForAttack >= 0 && targetSlotForAttack <= 8) {
            if (mc.player.getInventory().getSelectedSlot() != targetSlotForAttack) {
                mc.player.getInventory().setSelectedSlot(targetSlotForAttack);
            }
        }
        return true;
    }

    private boolean isAutoElytraReadyForMaceAttack() {
        AutoElytra autoElytra = dev.stargg.StarGG.modules().get(AutoElytra.class);
        return autoElytra == null || !autoElytra.isEnabled() || autoElytra.isMaceAttackReady();
    }

    private boolean canExecuteAttack(LivingEntity target) {
        if (mc.player == null || mc.interactionManager == null || target == null || !target.isAlive()
                || mc.player.isUsingItem() || mc.player.getAttackCooldownProgress(0.5F) < 1.0F
                || !mc.player.canSee(target) || !isWithinLegitReach(target, Math.min(swingRange.getDouble(), 2.95))
                || !isAutoElytraReadyForMaceAttack()) {
            return false;
        }
        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() == target) {
            return true;
        }
        // Silent rotations are server-facing in StarGG, so the client crosshair can remain on the old angle.
        return rotationInitialized && isWithinTrackingRange(target) && isAimingAtTarget(target);
    }

    private boolean isAimingAtTarget(LivingEntity target) {
        Vec3d delta = getAimPos(target).subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, Math.max(horizontal, 1.0E-5)));
        float yawError = Math.abs(MathHelper.wrapDegrees(assistedYaw - yaw));
        float pitchError = aimMode.is("Horizontal") ? 0.0F : Math.abs(assistedPitch - pitch);
        return yawError <= 4.0F && pitchError <= 4.0F;
    }

    private boolean isWithinLegitReach(Entity target, double range) {
        Vec3d eye = mc.player.getEyePos();
        Box box = target.getBoundingBox();
        double x = MathHelper.clamp(eye.x, box.minX, box.maxX);
        double y = MathHelper.clamp(eye.y, box.minY, box.maxY);
        double z = MathHelper.clamp(eye.z, box.minZ, box.maxZ);
        return eye.squaredDistanceTo(x, y, z) <= range * range;
    }

    private boolean isWithinTrackingRange(LivingEntity target) {
        return mc.player != null && target != null && mc.player.distanceTo(target) <= getTrackingRange(target);
    }

    private double getTrackingRange(LivingEntity target) {
        if (aimMode.is("Horizontal") && isInAirForHorizontalAssist() && aimInAir.getDouble() > 0.0) {
            return Math.max(getBaseRange(), aimInAir.getDouble());
        }
        return getBaseRange();
    }

    private double getBaseRange() {
        return aimRange.getDouble() > 0.0 ? aimRange.getDouble() : swingRange.getDouble();
    }

    private boolean shouldRotate() {
        return aimRange.getDouble() > 0.0 || (aimMode.is("Horizontal") && aimInAir.getDouble() > 0.0);
    }

    private boolean isInAirForHorizontalAssist() {
        return mc.player != null && !mc.player.isOnGround() && mc.player.fallDistance > 0.0F;
    }

    private void applyAimRotation(Vec3d aimPosition) {
        if (mc.player == null || aimPosition == null) return;
        // Always continue from the real view angles so the assist blends with mouse movement instead of snapping the
        // camera back to an angle remembered from an earlier tick.
        assistedYaw = mc.player.getYaw();
        assistedPitch = mc.player.getPitch();
        rotationInitialized = true;
        if (shouldStopAim(currentTarget)) return;
        Vec3d eye = mc.player.getEyePos();
        Vec3d delta = aimPosition.subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, Math.max(horizontal, 1.0E-5)));
        if (aimMode.is("Horizontal")) {
            targetPitch = assistedPitch;
        }
        float yawDelta = MathHelper.wrapDegrees(targetYaw - assistedYaw);
        float pitchDelta = targetPitch - assistedPitch;
        float speed = rotationSpeed.getFloat();
        float ease = Math.max(0.05F, 1.0F - aimSmoothing.getFloat());
        assistedYaw += smoothStep(yawDelta, ease, speed);
        assistedPitch = MathHelper.clamp(assistedPitch + smoothStep(pitchDelta, ease, speed), -90.0F, 90.0F);
        mc.player.setYaw(assistedYaw);
        if (!aimMode.is("Horizontal")) mc.player.setPitch(assistedPitch);
    }

    /**
     * One tick of an ease-out turn: a fraction of the remaining angle (fast when far, slow when close), limited by
     * the Aim Speed cap, with a small floor so the turn still finishes, and never past the target angle.
     */
    private static float smoothStep(float delta, float ease, float maxStep) {
        float distance = Math.abs(delta);
        if (distance < 1.0E-4F || maxStep <= 0.0F) return 0.0F;
        float step = Math.max(distance * ease, MIN_AIM_STEP);
        step = Math.min(Math.min(step, maxStep), distance);
        return Math.copySign(step, delta);
    }

    private Vec3d getAimPos(Entity target) {
        Box box = target.getBoundingBox();
        return new Vec3d((box.minX + box.maxX) * 0.5,
                box.minY + target.getHeight() * 0.65,
                (box.minZ + box.maxZ) * 0.5);
    }

    private boolean isTargetInHorizontalFov(LivingEntity target) {
        Vec3d delta = target.getBoundingBox().getCenter().subtract(mc.player.getEyePos());
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float yawDiff = Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - targetYaw));
        return yawDiff <= 90.0F && mc.player.canSee(target);
    }

    private LivingEntity findTarget() {
        if (mc.world == null || mc.player == null) return null;
        double range = getBaseRange();
        var candidates = mc.world.getOtherEntities(mc.player, mc.player.getBoundingBox().expand(range),
                        entity -> entity instanceof LivingEntity)
                .stream()
                .filter(LivingEntity.class::isInstance)
                .map(LivingEntity.class::cast)
                .filter(this::isValidTarget)
                .filter(target -> mc.player.distanceTo(target) <= range);

        if (targetMode.is("Straight")) {
            // Only what the crosshair points at, along the whole aim range; nearest hit wins.
            Vec3d eye = mc.player.getEyePos();
            Vec3d end = eye.add(mc.player.getRotationVec(1.0F).multiply(range));
            return candidates
                    .filter(target -> target.getBoundingBox().expand(STRAIGHT_MARGIN).raycast(eye, end).isPresent())
                    .min(Comparator.comparingDouble(target -> mc.player.squaredDistanceTo(target)))
                    .orElse(null);
        }
        if (targetMode.is("FOV")) {
            // Inside the cone only, and the one closest to where the player is already looking.
            double halfFov = targetFov.getDouble() / 2.0;
            return candidates
                    .filter(target -> angleToTarget(target) <= halfFov)
                    .min(Comparator.comparingDouble(this::angleToTarget))
                    .orElse(null);
        }
        return candidates
                .min(Comparator.comparingDouble(target -> mc.player.squaredDistanceTo(target)))
                .orElse(null);
    }

    /** Angle in degrees between the player's view direction and the direction to the target's aim point. */
    private double angleToTarget(LivingEntity target) {
        Vec3d delta = getAimPos(target).subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, Math.max(horizontal, 1.0E-5)));
        double yawError = Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
        double pitchError = Math.abs(pitch - mc.player.getPitch());
        return Math.hypot(yawError, pitchError);
    }

    private boolean isValidTarget(LivingEntity target) {
        if (!TargetFilters.matches(target, targetFilter, mc)) return false;
        if (target instanceof PlayerEntity player) {
            if (player.isSpectator()) return false;
            if (ignoreFriends.on() && (FriendManager.getInstance().isFriend(player.getUuid())
                    || FriendManager.getInstance().isFriend(player.getName().getString()))) {
                return false;
            }
        }
        return true;
    }

    private boolean isHoldingWeapon() {
        if (mc.player == null) return false;
        ItemStack stack = mc.player.getMainHandStack();
        return stack.isOf(Items.MACE) || stack.isOf(Items.TRIDENT)
                || stack.getItem() instanceof AxeItem || stack.isIn(net.minecraft.registry.tag.ItemTags.SWORDS);
    }

    private boolean isTargetBlocking(LivingEntity target) {
        return target != null && target.isBlocking();
    }

    private int findBestMace() {
        if (mc.player == null || mc.world == null) return -1;
        RegistryEntry<Enchantment> density = mc.world.getRegistryManager()
                .getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(Enchantments.DENSITY);
        int bestSlot = -1;
        int maxDensity = -1;
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isOf(Items.MACE)) continue;
            int level = EnchantmentHelper.getLevel(density, stack);
            if (level > maxDensity) {
                maxDensity = level;
                bestSlot = slot;
            }
        }
        return bestSlot;
    }

    private int findAxe() {
        if (mc.player == null) return -1;
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() instanceof AxeItem) return slot;
        }
        return -1;
    }

    private boolean isTargetExactCenter(LivingEntity target) {
        Vec3d center = target.getBoundingBox().getCenter();
        Vec3d eye = mc.player.getEyePos();
        Vec3d diff = center.subtract(eye);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, Math.sqrt(diff.x * diff.x + diff.z * diff.z)));
        float yawDiff = Math.abs(MathHelper.wrapDegrees(assistedYaw - targetYaw));
        float pitchDiff = Math.abs(assistedPitch - targetPitch);
        return yawDiff <= 1.0F && (aimMode.is("Horizontal") || pitchDiff <= 1.0F);
    }

    private boolean shouldStopAim(LivingEntity target) {
        if (target == null || mc.player.distanceTo(target) > Math.min(swingRange.getDouble(), 2.95)) return false;
        if (stopAim.is("Exact Center")) return isTargetExactCenter(target);
        return isOnHitboxWithAccuracy(target);
    }

    private boolean isOnHitboxWithAccuracy(LivingEntity target) {
        if (!(mc.crosshairTarget instanceof EntityHitResult hit) || hit.getEntity() != target) return false;
        Vec3d eye = mc.player.getEyePos();
        Box box = target.getBoundingBox();
        Vec3d center = box.getCenter();
        Vec3d delta = center.subtract(eye);
        double dx = center.x - eye.x;
        double dz = center.z - eye.z;
        double horizontalDistance = Math.max(Math.sqrt(dx * dx + dz * dz), 0.001);
        float centerYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float centerPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontalDistance));
        double yawDiff = Math.abs(MathHelper.wrapDegrees(assistedYaw - centerYaw));
        double halfWidth = Math.max(box.maxX - box.minX, box.maxZ - box.minZ) * 0.5;
        double yawSpan = Math.toDegrees(Math.atan2(Math.max(halfWidth, 0.001), horizontalDistance));
        double yawInside = 1.0 - Math.min(1.0, yawDiff / Math.max(yawSpan, 0.001));
        double pitchInside = 1.0;
        if (!aimMode.is("Horizontal")) {
            double halfHeight = (box.maxY - box.minY) * 0.5;
            double pitchSpan = Math.toDegrees(Math.atan2(Math.max(halfHeight, 0.001), horizontalDistance));
            double pitchDiff = Math.abs(MathHelper.wrapDegrees(assistedPitch - centerPitch));
            pitchInside = 1.0 - Math.min(1.0, pitchDiff / Math.max(pitchSpan, 0.001));
        }
        return Math.min(yawInside, pitchInside) >= hitboxAccuracy.getDouble();
    }

    private void restorePreSequenceSlot() {
        if (swapBack.on() && autoSwitch.on() && mc.player != null && preSequenceSlot >= 0 && preSequenceSlot < 9) {
            mc.player.getInventory().setSelectedSlot(preSequenceSlot);
        }
        preSequenceSlot = -1;
    }

    private void clearAim() {
        currentTarget = null;
        maceClicksLeft = 0;
        shouldAttackThisTick = false;
        shouldBreakShield = false;
        shouldMaceSmash = false;
        targetSlotForAttack = -1;
        originalSlot = -1;
        rotationInitialized = false;
    }

    private void abortSequence() {
        restorePreSequenceSlot();
        clearAim();
        resetTimer = 0;
    }

    private void resetSequence() {
        maceClicksLeft = 0;
        originalSlot = -1;
        shouldAttackThisTick = false;
        shouldBreakShield = false;
        shouldMaceSmash = false;
        targetSlotForAttack = -1;
        resetTimer = 0;
    }
}
