package dev.stargg.module.hud;

import dev.stargg.util.Icon;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;

import java.util.List;

public final class Ping extends TextHudModule {

    public Ping() {
        super("Ping", "Latency to the server", 4, 40);
        icon(Icon.PING);
    }

    @Override
    protected List<String> buildLines() {
        ClientPlayNetworkHandler network = mc.getNetworkHandler();
        PlayerListEntry entry = network == null || mc.player == null
                ? null
                : network.getPlayerListEntry(mc.player.getUuid());
        return List.of(entry == null ? "Ping: --" : "Ping: " + entry.getLatency() + " ms");
    }
}
