package dev.stargg.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

import java.util.ArrayDeque;
import java.util.Deque;

/** Counts attack / use clicks per second by polling the vanilla key state once per frame. */
public final class ClickTracker {

    public static final int LEFT = 0;
    public static final int RIGHT = 1;

    private static final long WINDOW_MS = 1000;
    private static final Deque<Long>[] CLICKS = newDeques();
    private static final boolean[] DOWN = new boolean[2];

    private ClickTracker() {
    }

    @SuppressWarnings("unchecked")
    private static Deque<Long>[] newDeques() {
        return new Deque[]{new ArrayDeque<Long>(), new ArrayDeque<Long>()};
    }

    /** Call once per frame. */
    public static void update(MinecraftClient client) {
        long now = System.currentTimeMillis();
        // Uses the vanilla attack/use key state, so it works with touch controls and rebinds too.
        KeyBinding[] binds = {client.options.attackKey, client.options.useKey};
        for (int button = 0; button < 2; button++) {
            boolean pressed = client.currentScreen == null && binds[button].isPressed();
            if (pressed && !DOWN[button]) {
                CLICKS[button].addLast(now);
            }
            DOWN[button] = pressed;
            prune(CLICKS[button], now);
        }
    }

    public static int cps(int button) {
        prune(CLICKS[button], System.currentTimeMillis());
        return CLICKS[button].size();
    }

    public static boolean isDown(int button) {
        return DOWN[button];
    }

    private static void prune(Deque<Long> clicks, long now) {
        while (!clicks.isEmpty() && now - clicks.peekFirst() > WINDOW_MS) {
            clicks.removeFirst();
        }
    }
}
