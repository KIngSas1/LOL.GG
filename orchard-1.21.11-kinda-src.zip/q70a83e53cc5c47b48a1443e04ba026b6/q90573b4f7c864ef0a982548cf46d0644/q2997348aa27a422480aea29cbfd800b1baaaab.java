package q70a83e53cc5c47b48a1443e04ba026b6.q90573b4f7c864ef0a982548cf46d0644;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class q2997348aa27a422480aea29cbfd800b1baaaab {
   double a;
   double aa;
   q2997348aa27a422480aea29cbfd800b1babba ab;
   double ba;
   q2997348aa27a422480aea29cbfd800b1babba bb;

   private q2997348aa27a422480aea29cbfd800b1baaaab() {
   }
}
