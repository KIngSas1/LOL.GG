# Icons from textures.zip + back navigation

## Icons
All icons were built from the supplied texture pack: white glyphs resampled once per GUI scale (1 to 6), so they stay
crisp and are tinted at draw time like the old ones.

- **Replaced art** (same names and sizes, so every existing screen picks it up): search, gear, dots, close, refresh,
  the Central GUI profile and HUD editor nav icons, and the six category icons.
- **New icons** (`Ui.Tex`): EDIT, COPY, DUPLICATE, LOAD, SAVE, TRASH, ADD, PASTE, BACK, STAR, PROFILES, PUBLIC, UPLOAD,
  RESET, HIDE, EYE, LIKE, DISLIKE, INFO. SAVE is a floppy disk drawn for this project; the pack has none.
- **Buttons with icons**: Profiles screen (Load, Save, Rename, Delete, Duplicate, Copy, Paste, Create, Public
  profiles), Public profiles screen (Publish, Import, Back, Copy, Add, Add and load, Update, List/Unlist, Delete, Like,
  Dislike, Post, Reply, Send, Cancel) and the HUD editor window (Reset all, Done, favorite stars, Reset position).
  `Ui.iconLabel` draws icon + text and falls back to icon only when a button is too narrow.
- **Module icons** replaced where the pack has a good match: FPS, Ping, Coordinates, Compass, Clock, Keystrokes,
  ArmorStatus, PotionEffects, ModuleList, Fullbright, Zoom, Weather, Sprint, Click GUI, AimAssist, Triggerbot,
  ShieldBreaker, AutoMace and the six category icons. Kept: CPS, HurtCam, Watermark, AutoElytra, AutoPearl, PearlCatch.

## Back buttons
`ClickGuiModule.open()` opens the click GUI in the selected style from anywhere (it keeps its state).
- Profiles screen: back arrow in the header returns to the home GUI.
- Public profiles screen: header has back (one level up: details/publish to list, list to Profiles), home (the click
  GUI) and close.
- HUD editor: back arrow in the element window header returns to the home GUI.
ESC still closes everything.

## Not verified
Not compiled with Loom or run in game; the screens were type-checked against API stubs. Check how the icons look at
your GUI scale, in particular the small 10px ones.
