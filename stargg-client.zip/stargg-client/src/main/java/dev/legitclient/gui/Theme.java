package dev.legitclient.gui;

import dev.legitclient.module.client.ClickGuiModule;
import dev.legitclient.util.Draw;

/** Colors and sizes of the click GUI. Tweak the look here. */
public final class Theme {

    public static final int PANEL_WIDTH = 110;
    public static final int HEADER_HEIGHT = 20;
    public static final int MODULE_HEIGHT = 20;
    public static final int PADDING = 8;

    public static final int HEADER = 0xFF151515;
    public static final int ROW = 0xFF1A1A1A;
    public static final int ROW_HOVER = 0xFF222222;
    public static final int SETTING_ROW = 0xFF121212;
    public static final int SETTING_HOVER = 0xFF181818;
    public static final int TRACK = 0xFF2E2E2E;
    public static final int BADGE = 0xFF2B2B2B;
    public static final int DIVIDER = 0xFF0F0F0F;
    public static final int TEXT = 0xFFCFCFCF;
    public static final int TEXT_BRIGHT = 0xFFFFFFFF;
    public static final int TEXT_DIM = 0xFF8C8C8C;
    public static final int TEXT_FAINT = 0xFF5C5C5C;

    private Theme() {
    }

    public static int accent() {
        return ClickGuiModule.accent();
    }

    /** True when the accent is bright (white, yellow, ...), so text on top of it must be dark to stay readable. */
    public static boolean lightAccent() {
        return isLight(accent());
    }

    public static boolean isLight(int argb) {
        double luminance = (0.299 * ((argb >> 16) & 0xFF) + 0.587 * ((argb >> 8) & 0xFF) + 0.114 * (argb & 0xFF)) / 255.0;
        return luminance > 0.6;
    }

    /** Readable text/knob color on top of the accent color. */
    public static int onAccent() {
        return lightAccent() ? 0xFF141414 : 0xFFFFFFFF;
    }

    /** Applies the user's panel opacity to a background color. */
    public static int bg(int color) {
        return Draw.withAlpha(color, ClickGuiModule.panelAlpha());
    }

    /** Moves {@code value} toward {@code target}; snaps once it is close (used for all GUI animations). */
    public static float approach(float value, float target) {
        value += (target - value) * 0.3f;
        return Math.abs(target - value) < 0.01f ? target : value;
    }
}
