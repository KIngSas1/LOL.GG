package dev.stargg.module.hud;

import dev.stargg.gui.Theme;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Icon;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

/** STAR.GG watermark: the client logo, then "STAR" in white and ".GG" in the theme color, in the large bold font. */
public final class Watermark extends HudModule {

    private static final String STAR = "STAR";
    private static final String GG = ".GG";
    private static final int LOGO_GAP = 5;
    private static final int ROW_HEIGHT = 14;

    private final BooleanSetting logo = add(new BooleanSetting("Logo", true));
    private final BooleanSetting underline = add(new BooleanSetting("Accent line", true));

    public Watermark() {
        super("Watermark", "Shows the client logo and name", 4, 4, true);
        icon(Icon.WATERMARK);
        enabledByDefault();
    }

    private int logoWidth() {
        return logo.on() ? Ui.Tex.LOGO.size + LOGO_GAP : 0;
    }

    @Override
    protected int contentWidth() {
        return logoWidth() + Ui.widthTitle(STAR) + Ui.widthTitle(GG) + 2;
    }

    @Override
    protected int contentHeight() {
        return ROW_HEIGHT;
    }

    @Override
    protected void draw(DrawContext context, int x, int y) {
        int cursor = x + 1;
        if (logo.on()) {
            Ui.icon(context, Ui.Tex.LOGO, cursor, y + (ROW_HEIGHT - Ui.Tex.LOGO.size) / 2, 0xFFFFFFFF);
            cursor += logoWidth();
        }
        int textY = Ui.middleYTitle(y, ROW_HEIGHT);
        Ui.textTitle(context, STAR, cursor, textY, 0xFFFFFFFF, shadow.on());
        cursor += Ui.widthTitle(STAR);
        Ui.textTitle(context, GG, cursor, textY, Theme.accent(), shadow.on());

        if (underline.on() && background.on()) {
            // thin accent line along the bottom of the box, inset so it stays inside the rounded corners
            int pad = padding();
            Draw.rect(context, x - pad + 4, y + ROW_HEIGHT + pad - 1, contentWidth() + pad * 2 - 8, 1, Draw.withAlpha(Theme.accent(), 0xC0));
        }
    }
}
