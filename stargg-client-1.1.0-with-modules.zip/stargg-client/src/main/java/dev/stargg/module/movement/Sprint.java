package dev.stargg.module.movement;

import dev.stargg.module.Category;
import dev.stargg.module.Module;
import dev.stargg.setting.BooleanSetting;
import dev.stargg.util.Icon;

/** Keeps sprint enabled while the player moves forward, subject to vanilla rules. */
public final class Sprint extends Module {

    private final BooleanSetting cancelInvisible = add(new BooleanSetting("Cancel invisible", false));

    public Sprint() {
        super("Sprint", "Automatically holds sprint while moving forward", Category.MOVEMENT);
        icon(Icon.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.currentScreen != null) {
            return;
        }
        if (mc.options.forwardKey.isPressed() && (!cancelInvisible.on() || !mc.player.isInvisible())) {
            mc.options.sprintKey.setPressed(true);
        }
    }

    @Override
    protected void onDisable() {
        mc.options.sprintKey.setPressed(false);
    }
}
