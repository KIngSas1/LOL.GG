package dev.stargg.util;

import java.util.UUID;

/** A lightweight friend entry used by combat-target filters. */
public record Friend(String name, UUID uuid, long addedTime, String note) {
    public Friend(String name, UUID uuid) {
        this(name, uuid, System.currentTimeMillis(), "");
    }

    public Friend {
        name = name == null ? "" : name;
        note = note == null ? "" : note;
    }

    public String displayName() {
        return note.isBlank() ? name : note + " (" + name + ")";
    }
}
