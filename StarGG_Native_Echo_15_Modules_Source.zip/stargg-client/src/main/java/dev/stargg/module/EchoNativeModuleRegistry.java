package dev.stargg.module;

import dev.stargg.StarGG;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** Registers the 15 original Ww.json feature instances as regular STAR.GG modules. */
public final class EchoNativeModuleRegistry {

    private static final FeatureDefinition[] ENABLED_FEATURES = {
            new FeatureDefinition("hack.echo.a2", "Aim Assist"),
            new FeatureDefinition("hack.echo.ac", "Auto Mace"),
            new FeatureDefinition("hack.echo.g0", "Capes"),
            new FeatureDefinition("hack.echo.gm", "Echo Click GUI"),
            new FeatureDefinition("hack.echo.aW", "Jump Reset"),
            new FeatureDefinition("hack.echo.gA", "Mace Swap"),
            new FeatureDefinition("hack.echo.bO", "Move Fix"),
            new FeatureDefinition("hack.echo.cv", "No Jump Delay"),
            new FeatureDefinition("hack.echo.aQ", "Pot Refill"),
            new FeatureDefinition("hack.echo.ce", "Spear Assist"),
            new FeatureDefinition("hack.echo.ha", "Spear Lunge"),
            new FeatureDefinition("hack.echo.eI", "Spear Reach"),
            new FeatureDefinition("hack.echo.dg", "Sprint"),
            new FeatureDefinition("hack.echo.aP", "Targets"),
            new FeatureDefinition("hack.echo.b_", "Trigger Bot")
    };

    private static boolean registered;
    private static boolean registrationFailed;
    private static boolean waitingWarningLogged;

    private EchoNativeModuleRegistry() {
    }

    /**
     * Returns false while the nested Echo feature manager is still initializing. Registration is
     * all-or-nothing: if any original feature or option type is missing, no partial set is added.
     */
    public static boolean registerEnabledModules(ModuleManager manager) {
        if (registered) {
            return true;
        }
        if (registrationFailed) {
            return false;
        }
        try {
            ClassLoader loader = Thread.currentThread().getContextClassLoader();
            if (loader == null) loader = EchoNativeModuleRegistry.class.getClassLoader();
            Class<?> echoMain = Class.forName("hack.echo.o", false, loader);
            Field managerField = echoMain.getField("featureManager");
            Object echoManager = managerField.get(null);
            if (echoManager == null) return false;

            Method lookup = echoManager.getClass().getMethod("getFeatureByClass", Class.class);
            List<EchoNativeModule> nativeModules = new ArrayList<>();
            for (FeatureDefinition definition : ENABLED_FEATURES) {
                Class<?> featureClass = Class.forName(definition.className, true, loader);
                Object feature = lookup.invoke(echoManager, featureClass);
                if (feature == null) {
                    if (!waitingWarningLogged) {
                        waitingWarningLogged = true;
                        StarGG.LOGGER.info("Waiting for Echo's original feature registry to finish initializing");
                    }
                    return false;
                }
                Category category = categoryFor(feature);
                nativeModules.add(new EchoNativeModule(feature, definition.displayName, category));
            }

            // Validate names before mutating STAR.GG's manager. Echo Click GUI is renamed only
            // to distinguish it from STAR.GG's own native Click GUI module.
            for (EchoNativeModule module : nativeModules) {
                if (manager.byName(module.getName()) != null) {
                    throw new IllegalStateException("STAR.GG already contains a module named " + module.getName());
                }
            }
            for (EchoNativeModule module : nativeModules) {
                module.deactivateOriginalKeyPolling();
            }
            manager.registerExternalBatch(nativeModules);
            registered = true;
            StarGG.LOGGER.info("Registered {} original Echo features as native STAR.GG modules", nativeModules.size());
            return true;
        } catch (ClassNotFoundException exception) {
            // Fabric may not have loaded the nested mod's entrypoint yet. Retry on the next tick.
            return false;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            registrationFailed = true;
            StarGG.LOGGER.error("Could not register original Echo features in STAR.GG's native module manager; native Echo registration has been stopped", exception);
            return false;
        }
    }

    private static Category categoryFor(Object feature) throws ReflectiveOperationException {
        Object echoCategory = feature.getClass().getMethod("getCategory").invoke(feature);
        String name = echoCategory instanceof Enum<?> value ? value.name() : String.valueOf(echoCategory);
        return switch (name) {
            case "COMBAT" -> Category.COMBAT;
            case "MOVEMENT" -> Category.MOVEMENT;
            case "RENDER" -> Category.VISUAL;
            case "MACROS", "UTILITY" -> Category.UTILITY;
            case "INTERNALS" -> Category.CLIENT;
            default -> throw new IllegalStateException("No STAR.GG category mapping for Echo category " + name);
        };
    }

    private record FeatureDefinition(String className, String displayName) {
    }
}
