package dev.stargg.module;

import dev.stargg.util.Icon;
import dev.stargg.util.Ui;

/** The panels shown in the click GUI. Add an entry here to get a new panel. */
public enum Category {
    HUD("HUD", Icon.HUD, Ui.Tex.CAT_HUD),
    VISUAL("Visual", Icon.VISUAL, Ui.Tex.CAT_VISUAL),
    UTILITY("Utility", Icon.UTILITY, Ui.Tex.CAT_UTILITY),
    CLIENT("Client", Icon.CLIENT, Ui.Tex.CAT_CLIENT);

    private final String title;
    private final Icon icon;
    private final Ui.Tex tex;

    Category(String title, Icon icon, Ui.Tex tex) {
        this.title = title;
        this.icon = icon;
        this.tex = tex;
    }

    /** Monochrome icon used by the click GUI. */
    public Ui.Tex tex() {
        return tex;
    }

    public Icon icon() {
        return icon;
    }

    public String title() {
        return title;
    }
}
