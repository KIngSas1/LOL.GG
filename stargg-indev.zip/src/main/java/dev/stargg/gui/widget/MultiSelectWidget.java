package dev.stargg.gui.widget;

import dev.stargg.gui.Theme;
import dev.stargg.setting.MultiSelectSetting;
import dev.stargg.util.Draw;
import dev.stargg.util.Ui;
import net.minecraft.client.gui.DrawContext;

/** Compact vertical list of independently toggleable filter options. */
final class MultiSelectWidget extends SettingWidget {

    private static final int OPTION_H = 15;
    private static final int CHECK_SIZE = 10;
    private final MultiSelectSetting setting;

    MultiSelectWidget(MultiSelectSetting setting) {
        this.setting = setting;
    }

    @Override
    public int height() {
        return LINE + setting.getOptions().size() * OPTION_H + 2;
    }

    @Override
    public boolean isVisible() {
        return setting.isVisible();
    }

    @Override
    protected void renderContent(DrawContext context, int mouseX, int mouseY) {
        paintRow(context, hovered(mouseX, mouseY));
        label(context, setting.getName(), Theme.TEXT);

        int optionsTop = y + LINE;
        int boxX = x + Theme.PADDING;
        for (int i = 0; i < setting.getOptions().size(); i++) {
            String option = setting.getOptions().get(i);
            int rowY = optionsTop + i * OPTION_H;
            int boxY = rowY + (OPTION_H - CHECK_SIZE) / 2;
            boolean selected = setting.has(option);
            boolean over = Draw.inside(mouseX, mouseY, x + Theme.PADDING - 2, rowY,
                    w - Theme.PADDING * 2 + 4, OPTION_H);

            if (over) {
                Draw.rect(context, x + Theme.PADDING - 2, rowY,
                        w - Theme.PADDING * 2 + 4, OPTION_H, Theme.bg(Theme.SETTING_HOVER));
            }

            // A consistent 10px checkbox with a clear outline and a centered check glyph.
            Ui.roundRect(context, boxX, boxY, CHECK_SIZE, CHECK_SIZE, 2,
                    selected ? Theme.accent() : Theme.TRACK);
            if (selected) {
                Ui.textCentered(context, "✓", boxX, boxY, CHECK_SIZE, CHECK_SIZE, Theme.onAccent());
            } else {
                Draw.outline(context, boxX, boxY, CHECK_SIZE, CHECK_SIZE, Theme.TEXT_FAINT);
            }

            int labelX = boxX + CHECK_SIZE + 5;
            int labelWidth = Math.max(24, w - Theme.PADDING * 2 - CHECK_SIZE - 5);
            Ui.textMiddle(context, Ui.trim(option, labelWidth), labelX, rowY, OPTION_H,
                    selected ? Theme.TEXT_BRIGHT : Theme.TEXT_DIM);
        }
    }

    @Override
    public void click(double mouseX, double mouseY, int button) {
        if (button == 1) {
            setting.reset();
            return;
        }
        if (button != 0 || mouseY < y + LINE) {
            return;
        }
        int index = (int) ((mouseY - (y + LINE)) / OPTION_H);
        if (index >= 0 && index < setting.getOptions().size()) {
            setting.toggle(setting.getOptions().get(index));
        }
    }
}
