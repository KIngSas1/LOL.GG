package dev.legitclient.module.visual;

import dev.legitclient.module.BindMode;
import dev.legitclient.module.Category;
import dev.legitclient.module.Module;
import dev.legitclient.setting.BooleanSetting;
import dev.legitclient.setting.NumberSetting;
import dev.legitclient.util.Icon;
import org.lwjgl.glfw.GLFW;

/** Hold the key to zoom in. The FOV change is applied in {@code GameRendererMixin}. */
public final class Zoom extends Module {

    private static Zoom instance;

    private final NumberSetting factor = add(new NumberSetting("Factor", 4, 1.5, 10, 0.5));
    private final BooleanSetting smooth = add(new BooleanSetting("Smooth", true));

    private float current = 1f;

    public Zoom() {
        super("Zoom", "Zooms in while the key is held", Category.VISUAL);
        icon(Icon.ZOOM);
        defaultBind(GLFW.GLFW_KEY_C, BindMode.HOLD);
        instance = this;
    }

    /**
     * Divisor applied to the field of view. Called once per frame by the mixin,
     * so it also eases back to 1.0 after the module was switched off.
     */
    public static float fovDivisor() {
        if (instance == null) {
            return 1f;
        }
        float target = instance.isEnabled() ? instance.factor.getFloat() : 1f;
        if (instance.smooth.on()) {
            instance.current += (target - instance.current) * 0.25f;
            if (Math.abs(target - instance.current) < 0.005f) {
                instance.current = target;
            }
        } else {
            instance.current = target;
        }
        return instance.current;
    }
}
